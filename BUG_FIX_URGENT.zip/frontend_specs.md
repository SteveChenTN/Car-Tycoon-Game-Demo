# Frontend Specification & Refactoring Plan: AutoMogul

## 1. UI Layout & Responsiveness Standard (The CSS Fix)
**Objective:** Solve the "Overflow/No Scroll" and "Broken Layout on Resize" issues.

### 1.1 Global Layout Strategy (The Hybrid Responsive Model)
The app follows a "Fixed Shell, Fluid Body" model, strictly managing space for different viewports.

**Core Dimensions:**
- **Sidebar Width:** `260px` (Fixed on Desktop)
- **TopBar Height:** `60px` (Fixed)

**Responsive Breakpoints Strategy:**

1.  **Desktop (> 768px):**
    - **Layout:** Flex Row.
    - **Sidebar:** Visible, fixed `width: 260px`, `flex-shrink: 0`.
    - **Main Content:** `flex: 1` (Takes up `100vw - 260px`).
    - **Constraint:** Content children must use `min-width: 0` to prevent preventing the flex container from shrinking.

2.  **Mobile / Tablet (< 768px):**
    - **Layout:** Sidebar behaves as an **Overlay / Drawer**.
    - **Sidebar:** Hidden by default (`transform: translateX(-100%)`). Triggered by a "Hamburger Menu" button in TopBar.
    - **Main Content:** Takes full width (`width: 100%`).
    - **Experience:** On small screens, users focus on ONE thing at a time (e.g., viewing a chart). They open the drawer to switch contexts.

**Technical Implementation (Tailwind approach):**
- **Container:** `h-screen w-screen overflow-hidden flex flex-col md:flex-row`
- **Sidebar:** `w-[260px] h-full bg-gray-900 border-r border-gray-800 ... hidden md:block` (plus a mobile drawer component for small screens).
- **Main Area:** `flex-1 h-full overflow-hidden flex flex-col relative`

**Safety Net (Scroll Handling):**
- If a data table inside Main Content is wider than the viewport (e.g., a massive spreadsheet):
  - The **Page Container** must NOT scroll horizontally.
  - The **Table Container** MUST have `overflow-x: auto` (Local scroll).
  - This ensures the Sidebar and TopBar never scroll off-screen.

2. Backend Integration & Data Mapping
Objective: Connect specific frontend components to their backend logic counterparts.

2.1 The "Hot Start" Protocol
Action: On App Load, trigger GET /api/gamestate/full.

Payload: Response must include date, funds, current_research, unread_logs.

Logic: If backend returns null (no save), frontend MUST automatically trigger POST /api/gamestate/new to seed initial data. Never show empty charts.

2.2 Module Implementation Requirements
Refer to this map for component logic:

A. Engine Designer (Hardcore Mode)
Input: Sliders/Inputs for Bore (mm), Stroke (mm), Compression Ratio, Material (Cast Iron/Alu).

Interactive: Changing inputs uses a Debounced API Call (POST /api/engine/simulate) to fetch updated Torque/HP curves.

Action: "Save Engine" button calls POST /api/engine/create.

Constraint: Do not calculate Physics in JS. Display data returned from Python.

B. Production & Factory
View: List of Factories with Capacity and Efficiency.

Action: Sliders to adjust Quality Control Spend (Impacts backend logic: defect_rate).

Data: Fetch inventory_levels to show if we are overproducing.

C. Market & Reports
View: Sales charts grouped by Region.

Requirement: Frontend must not hardcode mock data. Use useEffect to fetch /api/market/report?month={currentMonth}.

Handling Empty State: If report is empty, show "Market data compiling..." or "No sales history".

3. The Log/Event System (Multi-language Support)
Objective: Scrolling log console with i18n support.

Data Structure: Backend sends logs in this JSON format:

JSON

{
  "id": 101,
  "timestamp": "1955-03-01",
  "type": "WARNING",
  "i18n_key": "EVENT_FACTORY_STRIKE",
  "params": { "location": "Detroit", "duration": 3 }
}
Frontend Logic:

Create a LogContext.

Maintain a buffer of last 50 logs.

Translation: Use a dictionary to map EVENT_FACTORY_STRIKE -> 工厂罢工爆发于 {location}，预计持续 {duration} 周.

UI: Stick to the bottom of the screen. Auto-scroll on new log.

4. Design Constraints (Visuals)
Theme: Dark Mode Industrial. Colors: #1a1a1a (Bg), #2d2d2d (Panel), #00ffcc (Accent/Charts).

Typography: Roboto Mono or JetBrains Mono for all numbers and tables.

Components: Use standard rounded-md buttons, but strictly high contrast.
## 5. Typography & Scaling Standards (The Density Rule)
**Objective:** maximize data visibility while maintaining readability across devices. 

**Core Philosophy:** - On **Desktop**, prefer **High Density** (Small fonts, more rows).
- On **Mobile**, prefer **Readability** (Larger fonts, fewer columns, touch-friendly).

### 5.1 Font Family Stack
- **UI/Labels:** `Inter`, `system-ui`, `-apple-system` (Clean, sans-serif).
- **Data/Numbers/Code:** `JetBrains Mono`, `Roboto Mono`, or `Fira Code` (Strict Monospace is mandatory for table alignment).

### 5.2 Responsive Size Scale (Tailwind Classes)
The app utilizes a "Mobile-First" scaling strategy but caps the maximum size to avoid looking like a "toy app".

| Element Type | Mobile (<768px) | Tablet/Desktop (>=768px) | Weight | Visual Goal |
| :--- | :--- | :--- | :--- | :--- |
| **Section Headers** | `text-lg` (18px) | `text-xl` (20px) | Bold | Clear separation, but compact. |
| **Body Copy** | `text-sm` (14px) | `text-sm` (14px) | Regular | Standard readability. |
| **Data Tables (The Core)** | `text-xs` (12px) | `text-sm` (14px) | **Mono** | Dense packing. On 4K screens, do NOT scale up to 16px; keep 14px to show more rows. |
| **Tooltips/Meta** | `text-[10px]` | `text-xs` (12px) | Light | Secondary info (e.g., "Year-over-Year change"). |
| **Input Fields** | `text-base` (16px)* | `text-sm` (14px) | Medium | *Crucial: Inputs must be 16px on Mobile to prevent iOS auto-zoom.* |

### 5.3 Dynamic Density (Line Height)
- **Data Rows:** Use `leading-tight` or `h-8` (32px rows) on Desktop for maximum vertical density.
- **Touch Targets:** On Mobile, all interactive elements (buttons, dropdowns) must have a minimum height of `44px` (touch safe area), regardless of font size.

### 5.4 Implementation Note
- Use `rem` units for all spacing to respect user's browser accessibility settings.
- **Forbidden:** Do not use `vw` (viewport width) based font sizing for body text, as it causes readability issues on ultra-wide monitors.