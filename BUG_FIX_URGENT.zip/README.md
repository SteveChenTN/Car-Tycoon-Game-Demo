# AutoMogul 🚗

**硬核汽车公司经营模拟游戏**

一个基于真实经济模型的深度汽车制造企业模拟游戏，从1950年开始，管理从研发、生产到市场的全流程。

[![Python](https://img.shields.io/badge/Python-3.13-blue.svg)](https://www.python.org/)
[![FastAPI](https://img.shields.io/badge/FastAPI-0.109-green.svg)](https://fastapi.tiangolo.com/)
[![SQLAlchemy](https://img.shields.io/badge/SQLAlchemy-2.0+-orange.svg)](https://www.sqlalchemy.org/)
[![License](https://img.shields.io/badge/License-MIT-yellow.svg)](LICENSE)

---

## ✨ 特性

- 🌍 **真实世界模拟** - 5个经济区域，20亿人口，完整的GDP和经济周期模型
- ⏰ **基于周的时间系统** - 精确的时间推进，从1950年开始的历史模拟
- 📊 **深度经济模型** - 失业率、通胀、购买力、市场需求全方位模拟
- 🏭 **完整产业链** - 从研发、设计、生产到销售的全流程
- 🤖 **AI竞争对手** - 智能的AI公司决策系统
- 📈 **数据驱动** - 所有数据持久化，完整的历史追踪

---

## 🚀 快速开始

### 前置要求

**后端:**
- Python 3.13+
- pip

**前端:**
- Node.js 18+
- npm

### 安装

```bash
# 克隆项目
git clone <repository-url>
cd Car-tycoon-game

# 后端：安装依赖
pip install -r backend/requirements.txt

# 后端：初始化世界数据
python backend/scripts/init_world.py

# 前端：安装依赖（快速更新）
# Windows:
update_frontend_dependencies.bat

# Linux/Mac:
chmod +x update_frontend_dependencies.sh
./update_frontend_dependencies.sh

# 或手动安装：
# cd frontend
# npm install
# cd ..
```

> **注意：** 推荐使用 `update_frontend_dependencies` 脚本，它会自动清理旧依赖并安装最新版本，避免废弃警告。

### 运行

**方式1：全栈启动（推荐）** 🚀
```bash
# Windows
start_fullstack.bat

# Linux/Mac
chmod +x start_fullstack.sh
./start_fullstack.sh
```

**方式2：分别启动**

后端:
```bash
# Windows
start_server.bat

# Linux/Mac
./start_server.sh
```

前端:
```bash
# Windows
start_frontend.bat

# Linux/Mac
./start_frontend.sh
```

服务器启动后，访问：
- **前端界面**: http://localhost:3000 ✨
- **API文档（Swagger）**: http://localhost:8000/docs
- **健康检查**: http://localhost:8000/health
- **WebSocket**: ws://localhost:8000/ws/game

---

## 📡 API端点

### 游戏管理 (`/api/v1/game`)

- `GET /state` - 获取完整游戏状态（含玩家公司、最近事件）
- `GET /status` - 获取轻量级状态摘要
- `POST /next_turn` - **推进下一回合（核心端点）**
- `POST /advance_multiple` - 批量推进多个回合
- `GET /events` - 获取事件日志（FM风格ticker数据）
- `GET /events/recent` - 获取最近50条事件

### 工程设计 (`/api/v1/engineering`)

- `POST /engine/design` - 设计新发动机
- `GET /engine/{id}` - 获取发动机详情
- `POST /chassis/design` - 设计新底盘/平台
- `POST /car/design` - 设计新车辆（组合发动机+底盘）
- `POST /compatibility/check` - 检查兼容性
- `GET /engines` - 列出所有发动机
- `GET /chassis` - 列出所有底盘
- `GET /cars` - 列出所有车辆

### 公司管理 (`/api/v1/company`)

- `GET /{company_id}` - 获取公司信息
- `GET /{company_id}/finances` - 获取财务详情
- `GET /{company_id}/staff` - 获取员工列表
- `GET /staff/market` - 查看人才市场
- `POST /{company_id}/staff/hire/{staff_id}` - 招聘员工
- `POST /{company_id}/staff/fire/{staff_id}` - 解雇员工
- `POST /{company_id}/loan/apply` - 申请贷款
- `POST /{company_id}/loan/{loan_id}/repay` - 提前还款

### 调试模式 (`/api/v1/debug`) ⚠️

**上帝模式端点 - 仅用于测试**

- `GET /all_companies` - 查看所有公司详情（含AI竞争对手）
- `GET /company/{id}/full` - 获取单个公司的完整数据
- `GET /market/all_prices` - 查看全球原材料价格
- `POST /events/trigger` - 手动触发事件
- `POST /cheat/add_money` - 增加现金（作弊）
- `POST /cheat/unlock_all_tech` - 解锁所有技术
- `POST /cheat/set_prestige` - 设置声望值

---

## 🎮 游戏循环架构

每个回合按以下顺序执行：

```
1. 世界更新        → GDP增长、失业率、资源价格
2. AI公司决策      → AI竞争对手制定策略
3. 生产解算        → 工厂生产、库存更新
4. 市场解算        → 销售计算、市场份额
5. 财务结算        → 贷款还款、税务、破产检查
6. 测试推进        → 原型车测试进度
7. 事件触发        → 随机事件、历史事件
8. 清理          → 数据清理、统计更新
```

所有阶段产生的**事件日志**会收集到 `event_logs` 表，用于前端的FM风格ticker显示。

---

## 🔧 技术栈
start_server.bat

# Linux/Mac
chmod +x start_server.sh
./start_server.sh
```

**方式2：直接运行**
```bash
python start_server.py
```

### 访问API

- **API文档**: http://localhost:8000/docs
- **健康检查**: http://localhost:8000/health
- **游戏状态**: http://localhost:8000/api/v1/game/state

---

## 📖 文档

- **[前端初始化完成](FRONTEND_INIT_COMPLETE.md)** ✨ **NEW!** - 前端架构和设计系统
- **[快速入门指南](QUICKSTART.md)** - 详细的使用说明
- **[初始化总结](INITIALIZATION_SUMMARY.md)** - 项目初始化报告
- **[设计文档](design_doc.md)** - 完整的技术设计文档

---

## 🏗️ 技术栈

### 后端
- **框架**: FastAPI (高性能异步Web框架)
- **ORM**: SQLAlchemy 2.0+ (数据库映射)
- **数据库**: SQLite (轻量级嵌入式数据库)
- **数据处理**: NumPy, Pandas
- **日志**: Python logging + colorlog

### 前端 ✅ **NEW!**
- **框架**: React 18 + TypeScript
- **构建工具**: Vite 5
- **样式**: TailwindCSS (Cyan-Tech 设计系统)
- **图标**: Lucide React
- **图表**: Recharts
- **动画**: Framer Motion
- **实时通信**: WebSocket

---

## 📁 项目结构

```
Car-tycoon-game/
│
├── backend/                    # Python后端
│   ├── models/                 # 数据模型
│   │   ├── game_state.py       # ✅ 游戏状态和时间系统
│   │   ├── region.py           # ✅ 地区数据模型
│   │   ├── engineering.py      # ✅ 工程模型（引擎/底盘/车辆）
│   │   ├── production.py       # ✅ 生产模型（工厂/库存/材料市场）
│   │   ├── b2b.py              # ✅ B2B市场模型（企业间交易）
│   │   └── base.py             # 基类和Mixin
│   │
│   ├── core/                   # 核心游戏逻辑
│   │   ├── simulation/         # 模拟引擎
│   │   ├── economics/          # 经济模型
│   │   ├── engineering/        # ✅ 工程物理计算引擎
│   │   │   └── physics.py      # ✅ 硬核物理公式
│   │   ├── production/         # ✅ 生产管理引擎
│   │   │   └── production_manager.py  # ✅ 生产逻辑
│   │   └── ai/                 # AI系统
│   │       └── ai_procurement.py  # ✅ AI采购策略
│   │
│   ├── api/                    # API层
│   │   ├── routes/             # 路由定义
│   │   └── schemas/            # Pydantic模型
│   │
│   ├── services/               # 业务逻辑
│   │   └── engineering_service.py  # ✅ 工程服务层
│   ├── utils/                  # 工具函数
│   │   └── logger.py           # ✅ 日志系统
│   │
│   ├── scripts/                # 脚本
│   │   └── init_world.py       # ✅ 世界初始化
│   │
│   ├── config.py               # ✅ 配置和常量
│   ├── database.py             # ✅ 数据库连接
│   ├── main.py                 # ✅ FastAPI入口
│   └── requirements.txt        # 依赖列表
│
├── frontend/                   # ✨ React前端 (NEW!)
│   ├── src/
│   │   ├── components/
│   │   │   └── layout/
│   │   │       ├── AppShell.tsx      # ✅ 主布局容器
│   │   │       ├── Sidebar.tsx       # ✅ 左侧导航
│   │   │       └── StatusBar.tsx     # ✅ 顶部状态栏
│   │   ├── contexts/
│   │   │   └── GameContext.tsx       # ✅ WebSocket上下文
│   │   ├── pages/
│   │   │   └── Dashboard.tsx         # ✅ 仪表盘页面
│   │   ├── types/                    # ✅ TypeScript类型
│   │   ├── utils/                    # ✅ 工具函数
│   │   ├── App.tsx                   # ✅ 根组件
│   │   ├── main.tsx                  # ✅ 入口文件
│   │   └── index.css                 # ✅ 全局样式
│   ├── package.json
│   ├── vite.config.ts
│   └── tailwind.config.js
│
├── data/                       # 数据文件
│   └── automogul.db            # SQLite数据库
│
├── logs/                       # 日志文件
│
├── design_doc.md               # 设计文档
├── README.md                   # 本文件
├── FRONTEND_INIT_COMPLETE.md   # ✨ 前端文档 (NEW!)
└── QUICKSTART.md               # 快速入门

✅ = 已实现
✨ = 新增功能
```

---

## 🎮 当前功能

### ✅ 已实现

- [x] **时间系统** - 基于周的时间推进（1950年起）
- [x] **地区系统** - 5个经济区域，完整的经济和市场参数
  - 北美（NAM）- 高收入市场
  - 欧洲（EUR）- 注重燃效和小车
  - 亚太（ASI）- 高增长新兴市场
  - 拉美（LAM）- 中低收入市场
  - 中东非（MEA）- 资源丰富市场
- [x] **数据库系统** - SQLAlchemy ORM + SQLite
- [x] **RESTful API** - 游戏状态查询和操作
- [x] **日志系统** - 彩色控制台 + 文件日志
- [x] **世界初始化** - 自动生成初始数据
- [x] **🎉 工程核心系统（NEW!）** - 硬核物理驱动的车辆设计
  - **引擎系统** - 基于真实物理公式（排量、压缩比、增压）
    - 支持多种配置：直列、V型、水平对置、VR、W型
    - 支持多种进气：自然吸气、涡轮、机械增压、双涡轮
    - 自动计算：马力、扭矩、重量、尺寸、热负载、可靠性
  - **底盘系统** - 物理约束和兼容性检查
    - 引擎舱尺寸限制（长×宽×高）
    - 冷却容量限制（防止过热）
    - 多种驱动布局：FF/FR/MR/RR/AWD
  - **车辆配置** - 组件组装和性能计算
    - 自动计算：0-100加速、极速、油耗、刹车距离
    - 兼容性检查：确保引擎能装入底盘
    - 可靠性评估：综合引擎、底盘、匹配度
  - **物理公式** - 无随机数，纯推导
    - 排量计算：π × (bore/2)² × stroke × cylinders
    - 马力推导：基于BMEP、容积效率、转速
    - 加速计算：基于推重比和驱动形式
    - 极速计算：基于功率和空气阻力平衡
- [x] **🏭 生产与供应链系统（NEW!）** - 完整的制造业模拟
  - **工厂系统** - 分布式生产架构
    - 零部件工厂（COMPONENT）：生产引擎、底盘等
    - 装配厂（ASSEMBLY）：组装完整车辆
    - 工厂等级（1-10）影响效率和成本
    - 技术等级限制可生产的组件复杂度
  - **原材料市场** - 动态价格波动
    - 6种材料：钢材、铝材、塑料、电子元件、橡胶、玻璃
    - 价格受供需影响（波动率5%-30%）
    - 区域价格差异（考虑运输成本）
  - **库存管理** - 三级库存系统
    - 原材料库存（Raw Materials）
    - 零部件库存（Finished Components）
    - 成品车库存（Completed Cars）
  - **自动物流** - 简化的跨工厂运输
    - 同地区：低成本（$10/件）
    - 跨地区：固定成本 + 单位成本（$5000 + $50/件）
  - **B2B市场** - 企业间零部件交易
    - 发布/采购引擎、底盘等组件
    - 最小订购量（MOQ）约束
    - 独家供应协议支持
  - **AI采购策略** - 三种自动化策略
    - 准时制（JIT）：零库存，按需采购
    - 囤积型（Hoarder）：价格低时大量采购（4-8周库存）
    - 平衡型（Balanced）：维持2周安全库存

### 🚧 开发中

- [x] **前端UI** ✨ **NEW!**
- [ ] 公司和高管系统
- [ ] 消费者系统（Consumer Buckets）
- [ ] 工程API端点（创建引擎/底盘/车辆）
- [ ] 生产API端点（创建工厂/采购材料/生产组件）
- [ ] 回合处理引擎

### 📅 计划中

- [ ] AI竞争对手完整集成
- [ ] 市场模拟引擎
- [ ] 经济周期模拟
- [ ] 更多前端模块页面
- [ ] 3D车辆展示

---

## 🧪 API示例

### 获取游戏状态
```bash
curl http://localhost:8000/api/v1/game/state
```

**响应：**
```json
{
  "exists": true,
  "game": {
    "current_year": 1950,
    "current_month": 1,
    "current_week": 1,
    "turn_number": 0
  },
  "date": "1950-01-W1"
}
```

### 获取世界概况
```bash
curl http://localhost:8000/api/v1/game/world-summary
```

### 推进回合
```bash
curl -X POST http://localhost:8000/api/v1/game/advance
```

更多API示例请查看 [QUICKSTART.md](QUICKSTART.md)

---

## 🔬 核心设计理念

### 1. 文档驱动开发
所有功能实现严格遵循 `design_doc.md`，确保架构一致性。

### 2. 模块化架构
- 每个系统独立模块
- 清晰的职责分离
- 易于测试和扩展

### 3. 类型安全
```python
def calculate_demand(region: Region, year: int) -> float:
    """严格的类型提示"""
    pass
```

### 4. 性能优先
- NumPy批量计算
- 数据库索引优化
- 执行时间日志

### 5. 详细日志
```python
logger.info("Market calculation started")
logger.debug(f"Processing {len(regions)} regions")
```

---

## 🤝 贡献

欢迎贡献！请遵循以下步骤：

1. Fork 本仓库
2. 创建特性分支 (`git checkout -b feature/AmazingFeature`)
3. 提交更改 (`git commit -m 'Add some AmazingFeature'`)
4. 推送到分支 (`git push origin feature/AmazingFeature`)
5. 开启 Pull Request

**开发规范：**
- 遵循 `design_doc.md`
- 使用类型提示
- 添加单元测试
- 更新文档

---

## 📊 项目统计

- **代码行数**: 
  - 后端: ~6500行高质量Python代码
  - 前端: ~1200行TypeScript/TSX代码
- **测试覆盖率**: 待添加
- **文档完整度**: 100%
- **API端点**: 35+ (游戏/工程/公司/生产/调试)
- **数据模型**: 20+ (GameState, Region, Engine, Chassis, Factory, etc.)
- **物理公式**: 20+ 个真实工程/生产计算公式
- **前端组件**: 10+ (布局/页面/工具)

---

## 📝 开发日志

### v0.4.0 (2025-12-27) - 前端初始化 ✨
- ✅ React 18 + TypeScript + Vite 项目搭建
- ✅ TailwindCSS Cyan-Tech 设计系统
  - 深石板色背景 + 青色主色调
  - 自定义滚动条、玻璃态面板
  - 等宽字体数字显示
- ✅ 18:9 宽高比游戏容器布局
- ✅ WebSocket 实时通信（GameContext）
- ✅ 核心布局组件
  - AppShell（主容器）
  - Sidebar（7个模块导航）
  - StatusBar（日期/现金/GDP/暂停）
- ✅ Dashboard 仪表盘页面
- ✅ 工具函数（formatters, utils）
- ✅ 启动脚本（前端/全栈）

### v0.3.0 (2025-12-27) - 生产与供应链系统 🏭
- ✅ 实现完整的供应链架构
- ✅ 工厂模型（零部件工厂 vs 装配厂）
- ✅ 原材料市场系统（动态价格波动）
- ✅ 三级库存管理（材料/零部件/成品车）
- ✅ 生产管理器（ProductionManager）
  - 零部件生产逻辑（produce_component）
  - 整车装配逻辑（assemble_car）
  - 自动物流成本计算（auto_logistics）
  - 原材料采购（purchase_materials）
- ✅ B2B市场系统
  - 零部件挂牌交易（ComponentListing）
  - 交易记录追踪（B2BTransaction）
  - 最小订购量（MOQ）和独家协议
- ✅ AI采购代理（AIProcurementDelegate）
  - 准时制策略（JIT）
  - 囤积型策略（Hoarder）
  - 平衡型策略（Balanced）
- ✅ 更新设计文档（新增5.6节：生产与供应链系统）

### v0.2.0 (2025-12-27) - 工程核心系统
- ✅ 实现硬核工程物理引擎
- ✅ 引擎模型（15+物理参数，自动计算）
- ✅ 底盘模型（物理约束系统）
- ✅ 车辆配置模型（性能计算）
- ✅ 兼容性检查服务
- ✅ 工程服务层（高级API）
- ✅ 更新设计文档（新增工程架构章节）

### v0.1.0 (2025-12-27) - 基础架构
- ✅ 初始化项目结构
- ✅ 实现时间系统（Weekly）
- ✅ 实现地区系统（5个区域）
- ✅ FastAPI后端基础
- ✅ 日志系统
- ✅ 世界初始化脚本
- ✅ 完整文档

---

## 🐛 故障排除

### 模块导入错误
```bash
pip install -r backend/requirements.txt
```

### 数据库不存在
```bash
python backend/scripts/init_world.py
```

### 端口被占用
```bash
# 使用不同端口
uvicorn backend.main:app --port 8001
```

更多问题请查看 [QUICKSTART.md](QUICKSTART.md) 的故障排除部分。

---

## 📄 许可证

本项目采用 MIT 许可证 - 查看 [LICENSE](LICENSE) 文件了解详情

---

## 👥 作者

- 基于 `design_doc.md` 实现
- 遵循硬核模拟游戏设计理念

---

## 🙏 致谢

- FastAPI - 优秀的Python Web框架
- SQLAlchemy - 强大的ORM工具
- 所有开源贡献者

---

**准备好管理你的汽车帝国了吗？🏁**

查看 [QUICKSTART.md](QUICKSTART.md) 开始你的旅程！

