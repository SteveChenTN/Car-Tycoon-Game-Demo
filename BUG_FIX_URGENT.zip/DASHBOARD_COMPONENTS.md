# Dashboard & Game Control Components

## 概述

这个更新实现了游戏的主仪表板和核心控制层，遵循 "Cyber-Industrial" 设计风格。

## 新增组件

### 1. GlobalTicker (`src/components/layout/GlobalTicker.tsx`)

**功能：** 全局事件滚动条，固定在屏幕底部

**特性：**
- 固定底部位置，高度 40px
- 滚动字幕动画展示最新事件
- 根据事件严重程度显示不同颜色：
  - `critical`: 红色 (rose-400) + 脉冲动画
  - `warning`: 琥珀色 (amber-400)
  - `info`: 青色 (cyan-400)
- 使用 Framer Motion 实现平滑进入/退出动画
- 渐变遮罩效果（左右两侧）
- 保留最新 20 条事件以提高性能

**使用方法：**
```tsx
import { GlobalTicker } from '@/components/layout/GlobalTicker';

<GlobalTicker events={eventHistory} />
```

---

### 2. NextTurnButton (`src/components/ui/NextTurnButton.tsx`)

**功能：** "长按推进回合" 交互按钮

**特性：**
- 圆形按钮（140px × 140px）
- **长按 1 秒** 触发 `/api/game/next_turn` API
- 进度环动画（SVG）- 从 0% 到 100% 填充
- 完成时白色闪光效果
- 空闲时脉冲动画
- 离线时自动禁用
- 处理中显示 "PROCESSING" 状态

**状态：**
- `idle`: 显示 "END MONTH"，脉冲边框
- `holding`: 进度环填充，显示百分比
- `processing`: 显示 "PROCESSING"
- `complete`: 白色闪光 → 重置

**使用方法：**
```tsx
import { NextTurnButton } from '@/components/ui/NextTurnButton';

<NextTurnButton 
  onTurnComplete={() => console.log('Turn complete!')}
  disabled={!isConnected}
/>
```

---

### 3. NetworkTopology (`src/components/ui/NetworkTopology.tsx`)

**功能：** 全球网络拓扑可视化（抽象 SVG）

**特性：**
- 响应式 SVG，自动适应容器
- 生成区域节点（圆形）和连接线
- 节点脉冲动画（活跃度可调）
- 连接线发光效果（使用 SVG filter）
- 网格背景（Blueprint 风格）
- 显示节点和连接数量统计

**Mock 数据：**
- 默认生成 6 个区域节点（NA, EU, AS, SA, AF, OC）
- 环形布局 + 随机交叉连接
- 可通过 props 传入真实数据

**使用方法：**
```tsx
import { NetworkTopology } from '@/components/ui/NetworkTopology';

// 使用 mock 数据
<NetworkTopology />

// 使用真实数据
<NetworkTopology nodes={customNodes} links={customLinks} />
```

---

### 4. FinancialTerminal (`src/components/ui/FinancialTerminal.tsx`)

**功能：** 财务数据终端

**特性：**
- 三个关键 KPI 指标：
  - 现金 (Cash) - 绿色
  - 净利润 (Net Profit) - 绿色（正）/ 红色（负）
  - 市场份额 (Market Share) - 青色
- 现金流趋势图（Recharts AreaChart）
- 绿色渐变表示利润
- 使用 `formatCurrency` 格式化货币
- 默认生成 12 个月的 mock 数据

**使用方法：**
```tsx
import { FinancialTerminal } from '@/components/ui/FinancialTerminal';

<FinancialTerminal 
  history={financialHistory}
  currentCash={750000}
  currentProfit={45000}
  marketShare={8.5}
/>
```

---

### 5. CompetitorRadar (`src/components/ui/CompetitorRadar.tsx`)

**功能：** 竞争对手雷达对比图

**特性：**
- 5 个维度对比：
  - Tech（技术水平）
  - Brand（品牌力）
  - Cash（资金）
  - Quality（质量评分）
  - Market（市场份额）
- 玩家公司（青色）vs AI 对手（红色）
- 显示优势/劣势统计
- 使用 Recharts RadarChart

**使用方法：**
```tsx
import { CompetitorRadar } from '@/components/ui/CompetitorRadar';

<CompetitorRadar 
  playerCompany={playerData}
  rivalCompany={topRivalData}
/>
```

---

## Dashboard 页面布局

**布局方式：** CSS Grid (Bento Box 风格)

**结构：** 12×12 网格

```
┌────────────────────────────────────────┐
│ Status Bar (12×1)                      │
├─────────────────────┬──────────────────┤
│ Network Topology    │ Financial        │
│ (7×7)              │ Terminal (5×7)   │
│                     │                  │
├──────────┬──────────┼──────────────────┤
│ Comp     │ Next     │ Quick Stats      │
│ Radar    │ Turn Btn │ (3×4)            │
│ (5×4)    │ (4×4)    │                  │
└──────────┴──────────┴──────────────────┘
```

**组件位置：**
1. **Status Bar** (顶部): 游戏状态、时间、最新事件
2. **Network Topology** (左上大): 主要视觉焦点
3. **Financial Terminal** (右上): 财务 KPI + 图表
4. **Competitor Radar** (左下): 对手分析
5. **Next Turn Button** (中下): 游戏控制
6. **Quick Stats** (右下): 快速统计

---

## GameContext 更新

**新增功能：**
- `eventHistory: EventLog[]` - 事件历史记录
- 自动保留最新 50 条事件
- WebSocket 收到 `event` 消息时自动更新历史

**使用方法：**
```tsx
const { gameState, latestEvent, eventHistory, isConnected } = useGameContext();
```

---

## AppShell 集成

**更新：**
- 引入 `GlobalTicker` 组件
- 主内容区域添加 `pb-10`（底部留 40px 给 Ticker）
- GlobalTicker 固定在最底部（`position: fixed`）

---

## 工具函数

**新增文件：** `src/utils/formatters.ts`

**函数：**
```typescript
formatCurrency(value: number): string  // $1.5M, $750K, $500
formatNumber(value: number): string    // 1,234,567
formatPercent(value: number): string   // 12.5%
formatDate(dateString: string): string // Jan 15, 2024
```

---

## 样式更新

**新增动画：** `animate-scroll`

```css
@keyframes scroll-left {
  0% { transform: translateX(0); }
  100% { transform: translateX(-50%); }
}
```

用于 GlobalTicker 的字幕滚动效果。

---

## Mock 数据策略

所有组件都内置了 **Fallback Mock Data**，确保在后端数据为空时 UI 不会崩溃：

- **NetworkTopology**: 自动生成 6 个区域节点
- **FinancialTerminal**: 生成 12 个月历史数据
- **CompetitorRadar**: 生成随机对比数据
- **Dashboard Quick Stats**: 显示随机统计数字

---

## 设计风格

**Cyber-Industrial 美学：**
- 细线条（thin borders）
- 单色字体（monospace）用于数字
- 高对比度（dark bg + cyan/amber/rose accent）
- 发光效果（glow filters on SVG）
- 脉冲动画（pulse on active elements）
- Blueprint 网格背景

**颜色系统：**
- Primary: Cyan (#06b6d4)
- Success: Emerald (#10b981)
- Warning: Amber (#fbbf24)
- Error: Rose (#f43f5e)
- Background: Slate 950/900

---

## API 集成点

### 1. Next Turn API

**Endpoint:** `POST /api/game/next_turn`

**触发：** 长按 NextTurnButton 1 秒

**响应：** 后端应该通过 WebSocket 广播更新的 `game_state` 和 `event` 消息

### 2. WebSocket 监听

**消息类型：**
- `game_state`: 更新游戏状态
- `event`: 添加到事件历史 + GlobalTicker

---

## 性能优化

1. **事件历史限制：** GameContext 只保留最新 50 条
2. **Ticker 显示限制：** GlobalTicker 只显示最新 20 条
3. **useMemo：** 图表数据使用 `useMemo` 缓存
4. **AnimatePresence：** Framer Motion 优化动画性能

---

## 下一步建议

1. **后端集成：**
   - 实现 `/api/game/next_turn` 端点
   - 确保 WebSocket 广播事件

2. **真实数据：**
   - 从后端获取 `FinancialSnapshot[]`
   - 获取玩家和竞争对手的 `Company` 数据
   - 生成真实的网络拓扑节点（基于工厂/市场位置）

3. **增强功能：**
   - 点击网络节点显示详情
   - 图表可交互（点击查看详细历史）
   - 事件点击跳转到相关模块

---

## 测试

1. 启动前端开发服务器：
   ```bash
   cd frontend
   npm run dev
   ```

2. 确保后端运行在 `localhost:8000`

3. 测试项目：
   - 检查 GlobalTicker 是否显示滚动事件
   - 长按 NextTurnButton 触发回合推进
   - 验证所有 mock 数据正常显示
   - 测试离线状态（关闭后端）

---

## 文件清单

**新增文件：**
```
frontend/src/
├── components/
│   ├── layout/
│   │   ├── GlobalTicker.tsx       (新增)
│   │   └── index.ts               (新增)
│   └── ui/
│       ├── NextTurnButton.tsx     (新增)
│       ├── NetworkTopology.tsx    (新增)
│       ├── FinancialTerminal.tsx  (新增)
│       ├── CompetitorRadar.tsx    (新增)
│       └── index.ts               (新增)
├── utils/
│   └── formatters.ts              (新增)
├── contexts/
│   └── GameContext.tsx            (更新)
├── pages/
│   └── Dashboard.tsx              (重写)
├── components/layout/
│   └── AppShell.tsx               (更新)
├── types/
│   └── index.ts                   (更新)
└── index.css                      (更新)
```

---

## 总结

✅ 完成了所有 4 个核心任务：
1. ✅ GlobalTicker - 底部新闻滚动条
2. ✅ NextTurnButton - 长按推进交互
3. ✅ NetworkTopology - SVG 网络拓扑可视化
4. ✅ Dashboard - Bento Box 布局 + 集成所有组件

**视觉效果：** 工业仪表板风格，动态动画，高科技感

**性能：** 优化良好，mock 数据完整，无 linter 错误

**可扩展性：** 所有组件支持传入真实数据，易于与后端集成

