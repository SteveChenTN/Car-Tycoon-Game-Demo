# 🚀 AutoMogul - 项目快速参考

## 一键启动

```bash
# Windows
start_fullstack.bat

# Linux/Mac
./start_fullstack.sh
```

访问: **http://localhost:3000** 🎮

---

## 项目架构

```
前端 (localhost:3000)
  ↓ WebSocket (ws://localhost:8000/ws/game)
  ↓ REST API (http://localhost:8000/api/v1/*)
后端 (localhost:8000)
  ↓
数据库 (data/automogul.db)
```

---

## 核心技术栈

| 层级 | 技术 |
|------|------|
| **前端** | React 18 + TypeScript + Vite |
| **样式** | TailwindCSS (Cyan-Tech 设计) |
| **后端** | FastAPI + Python 3.13 |
| **数据库** | SQLite + SQLAlchemy 2.0 |
| **实时** | WebSocket |

---

## 主要模块

### 前端 (7个页面)
1. 📊 **Dashboard** - 总览仪表盘 ✅
2. 🔧 **Design Studio** - 车辆设计工作室
3. 🏭 **Factory** - 工厂管理
4. 📈 **Market** - 市场分析
5. 👔 **Executive** - 高管管理
6. 🧪 **Research** - 研发中心
7. 📄 **Reports** - 报告中心

### 后端 (5大系统)
1. ⏰ **时间系统** - 周回合制 (1950+) ✅
2. 🌍 **地区系统** - 5个经济区 ✅
3. 🔧 **工程系统** - 引擎/底盘/车辆 ✅
4. 🏭 **生产系统** - 工厂/供应链 ✅
5. 💰 **经济系统** - 市场/财务 ✅

---

## 关键文件

| 文件 | 用途 |
|------|------|
| `start_fullstack.bat/sh` | 启动全栈 |
| `frontend/src/App.tsx` | 前端根组件 |
| `backend/main.py` | 后端入口 |
| `design_doc.md` | 完整设计文档 |
| `FRONTEND_INIT_COMPLETE.md` | 前端架构文档 |

---

## API 端点速查

### 游戏管理
```bash
GET  /api/v1/game/state       # 游戏状态
POST /api/v1/game/next_turn   # 推进回合
GET  /api/v1/game/events      # 事件日志
```

### 工程设计
```bash
POST /api/v1/engineering/engine/design   # 设计引擎
POST /api/v1/engineering/chassis/design  # 设计底盘
POST /api/v1/engineering/car/design      # 设计车辆
```

### 公司管理
```bash
GET  /api/v1/company/{id}              # 公司信息
GET  /api/v1/company/{id}/finances     # 财务详情
POST /api/v1/company/{id}/staff/hire   # 招聘员工
```

完整API文档: http://localhost:8000/docs

---

## 前端组件结构

```
src/
├── components/layout/
│   ├── AppShell.tsx     # 主容器 (18:9)
│   ├── Sidebar.tsx      # 左侧导航
│   └── StatusBar.tsx    # 顶部状态栏
├── pages/
│   └── Dashboard.tsx    # 仪表盘
├── contexts/
│   └── GameContext.tsx  # WebSocket上下文
├── types/
│   └── index.ts         # TypeScript类型
└── utils/
    └── formatters.ts    # 格式化工具
```

---

## 设计系统速查

### 颜色
- 主色: `text-cyan-400` / `bg-cyan-500`
- 背景: `bg-slate-950`
- 面板: `glass-panel` (玻璃态)
- 边框: `border-slate-800`

### 字体
- 数字: **必须** `font-mono`
- 文本: 系统无衬线
- 大小: `text-sm` (14px 基础)

### 布局
- 容器: `max-w-[1920px] aspect-[18/9]`
- 行高: `h-10` (40px 表格)
- 间距: `gap-4` / `p-4` (16px)

---

## 常用命令

### 后端
```bash
cd backend
python scripts/init_world.py     # 初始化数据
python main.py                    # 启动服务器
```

### 前端
```bash
cd frontend
npm install                       # 安装依赖
npm run dev                       # 开发模式
npm run build                     # 生产构建
```

---

## 数据库查询

```bash
# 进入SQLite控制台
sqlite3 data/automogul.db

# 常用查询
SELECT * FROM game_state;
SELECT * FROM regions;
SELECT * FROM companies;
SELECT * FROM engines;
```

---

## 开发流程

### 添加新页面
1. 在 `frontend/src/pages/` 创建组件
2. 在 `Sidebar.tsx` 添加导航项
3. 在 `App.tsx` 添加路由逻辑

### 添加新API端点
1. 在 `backend/api/routes/` 创建路由
2. 在 `backend/services/` 添加业务逻辑
3. 在 `main.py` 注册路由

### 添加新数据模型
1. 在 `backend/models/` 创建模型
2. 生成迁移: `alembic revision --autogenerate`
3. 应用迁移: `alembic upgrade head`

---

## 调试技巧

### 前端
- 浏览器控制台: `[GameProvider]` 日志
- React DevTools
- WebSocket 连接状态: 右下角指示器

### 后端
- 日志文件: `logs/automogul_YYYYMMDD.log`
- API文档: http://localhost:8000/docs
- 调试端点: `/api/v1/debug/*`

---

## 性能优化

### 前端
- 使用 `React.memo` 避免重渲染
- 虚拟滚动处理长列表
- 图片懒加载

### 后端
- NumPy 批量计算
- 数据库索引
- 查询优化 (避免 N+1)

---

## 常见问题

### Q: 前端连接不上后端？
A: 确保后端在 8000 端口运行，检查 WebSocket 连接日志

### Q: 数据库为空？
A: 运行 `python backend/scripts/init_world.py`

### Q: npm install 失败？
A: 确保 Node.js 18+，清除缓存 `npm cache clean --force`

### Q: 样式不生效？
A: TailwindCSS 需要重启开发服务器

---

## 贡献指南

1. 阅读 `design_doc.md`
2. 遵循现有代码风格
3. 添加类型提示 (Python/TypeScript)
4. 更新相关文档
5. 提交前测试

---

## 文档索引

| 文档 | 内容 |
|------|------|
| `README.md` | 项目总览 |
| `QUICKSTART.md` | 快速入门 |
| `design_doc.md` | 完整设计 |
| `FRONTEND_INIT_COMPLETE.md` | 前端架构 |
| `FRONTEND_VISUAL_GUIDE.md` | 视觉设计 |
| `INITIALIZATION_SUMMARY.md` | 初始化总结 |
| `BACKEND_COMPLETE.md` | 后端文档 |

---

## 下一步

- [ ] 实现更多前端页面
- [ ] 集成 Recharts 图表
- [ ] 添加 Framer Motion 动画
- [ ] 实现键盘快捷键
- [ ] 添加单元测试

---

**🎮 准备好开始了吗？运行 `start_fullstack.bat` 启动游戏！**

