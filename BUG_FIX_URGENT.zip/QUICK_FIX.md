# 快速参考：依赖更新

## 🚨 如果你看到 npm 废弃警告

```bash
# 一键修复（Windows）
.\update_frontend_dependencies.bat

# 一键修复（Linux/Mac）
./update_frontend_dependencies.sh
```

## 📦 更新了什么

- ESLint: 8 → 9
- Vite: 5 → 6
- TypeScript: 5.2 → 5.7
- React: 18.2 → 18.3
- 所有其他依赖更新到最新

## ✅ 更新后验证

```bash
cd frontend

# 应该没有废弃警告
npm install

# 应该能正常运行
npm run lint
npm run dev
npm run build
```

## 📝 相关文档

- `npm警告修复指南.md` - **新手看这个**
- `DEPENDENCY_UPDATE_CHECKLIST.md` - 验证清单
- `DEPENDENCY_COMPARISON.md` - 详细对比
- `frontend/DEPENDENCY_UPDATE.md` - 技术细节

## 🎯 关键信息

- **最低 Node.js 版本：** 18.0
- **更新耗时：** 3-5分钟
- **风险级别：** 极低
- **是否影响现有代码：** 否（完全兼容）

---
**更新日期：** 2025-12-27

