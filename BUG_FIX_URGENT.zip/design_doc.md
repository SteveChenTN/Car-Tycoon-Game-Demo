# AutoMogul: Hardcore Automobile Company Simulation

## Design Document v1.0

---

## Table of Contents

1. [Executive Summary](#1-executive-summary)
2. [Technical Architecture](#2-technical-architecture)
3. [Directory Structure](#3-directory-structure)
4. [Database Schema](#4-database-schema)
5. [Core Game Systems](#5-core-game-systems)
6. [Algorithm Specifications](#6-algorithm-specifications)
7. [API Specification](#7-api-specification)
8. [Data Structures for 3D Readiness](#8-data-structures-for-3d-readiness)
9. [Performance Considerations](#9-performance-considerations)

---

## 1. Executive Summary

**AutoMogul** is a turn-based hardcore automobile company simulation where players assume the role of CEO, managing every aspect of a car manufacturer—from R&D breakthroughs to supply chain logistics, from market positioning to executive team dynamics.

### Core Philosophy
- **Depth over Accessibility:** Every system interconnects; shortcuts have consequences
- **Emergent Narrative:** Stories emerge from systems, not scripts
- **Data-Driven Realism:** Economic models grounded in real industrial economics

### Target Experience
Players should feel the weight of decisions: launching a car isn't just clicking "produce"—it's years of R&D investment, supplier negotiations, factory retooling, marketing campaigns, and hoping your CTO's morale hasn't tanked enough to sabotage the project.

---

## 2. Technical Architecture

### 2.1 System Overview

```
┌─────────────────────────────────────────────────────────────────┐
│                     ELECTRON SHELL                              │
│  ┌───────────────────────────────────────────────────────────┐  │
│  │                   REACT FRONTEND                          │  │
│  │  ┌─────────────┐ ┌─────────────┐ ┌─────────────────────┐  │  │
│  │  │  Dashboard  │ │  Designer   │ │  Reports & Charts   │  │  │
│  │  │   Module    │ │   Module    │ │      Module         │  │  │
│  │  └─────────────┘ └─────────────┘ └─────────────────────┘  │  │
│  │                         │                                  │  │
│  │                    REST API Calls                          │  │
│  │                         ▼                                  │  │
│  └───────────────────────────────────────────────────────────┘  │
│                            │                                     │
│         ┌──────────────────┴──────────────────┐                 │
│         ▼                                      ▼                │
│  ┌─────────────────┐                  ┌─────────────────┐       │
│  │  Python Process │ ◄── IPC/HTTP ──► │  SQLite DB      │       │
│  │  (FastAPI)      │                  │  (SQLAlchemy)   │       │
│  │                 │                  │                 │       │
│  │  • Simulation   │                  │  • Game State   │       │
│  │  • AI Logic     │                  │  • Save/Load    │       │
│  │  • Market Calc  │                  │  • History      │       │
│  └─────────────────┘                  └─────────────────┘       │
└─────────────────────────────────────────────────────────────────┘
```

### 2.2 Turn Processing Pipeline

```
TURN START (Month N)
       │
       ▼
┌──────────────────┐
│ 1. World Update  │ ← GDP shifts, resource prices, random events
└────────┬─────────┘
         ▼
┌──────────────────┐
│ 2. AI Companies  │ ← CEO decisions, R&D progress, production orders
│    Process Turn  │
└────────┬─────────┘
         ▼
┌──────────────────┐
│ 3. Player Input  │ ← Awaits player commands (async)
│    Resolution    │
└────────┬─────────┘
         ▼
┌──────────────────┐
│ 4. Production    │ ← Factories produce, supply chain resolves
│    Resolution    │
└────────┬─────────┘
         ▼
┌──────────────────┐
│ 5. Market        │ ← Consumer buckets evaluate, sales resolve
│    Resolution    │
└────────┬─────────┘
         ▼
┌──────────────────┐
│ 6. Financial     │ ← Revenue, costs, loans, bankruptcy checks
│    Resolution    │
└────────┬─────────┘
         ▼
┌──────────────────┐
│ 7. Event Gen     │ ← News, CEO retirements, scandals, breakthroughs
└────────┬─────────┘
         ▼
    TURN END
```

---

## 3. Directory Structure

```
automogul/
│
├── backend/                          # Python FastAPI Backend
│   ├── __init__.py
│   ├── main.py                       # FastAPI application entry
│   ├── config.py                     # Game configuration constants
│   │
│   ├── api/                          # API Layer
│   │   ├── __init__.py
│   │   ├── routes/
│   │   │   ├── __init__.py
│   │   │   ├── game.py               # Save/Load/New game endpoints
│   │   │   ├── turn.py               # Turn processing endpoints
│   │   │   ├── company.py            # Company management endpoints
│   │   │   ├── market.py             # Market data endpoints
│   │   │   ├── engineering.py        # Car design endpoints
│   │   │   ├── production.py         # Factory/supply chain endpoints
│   │   │   └── reports.py            # Analytics/reports endpoints
│   │   ├── schemas/                  # Pydantic request/response models
│   │   │   ├── __init__.py
│   │   │   ├── game.py
│   │   │   ├── company.py
│   │   │   ├── vehicle.py
│   │   │   ├── market.py
│   │   │   └── common.py
│   │   └── dependencies.py           # FastAPI dependencies
│   │
│   ├── core/                         # Core Game Logic
│   │   ├── __init__.py
│   │   ├── simulation/
│   │   │   ├── __init__.py
│   │   │   ├── world_engine.py       # Macro world simulation
│   │   │   ├── market_engine.py      # Demand/supply resolution
│   │   │   ├── production_engine.py  # Factory simulation
│   │   │   ├── finance_engine.py     # Financial calculations
│   │   │   └── event_engine.py       # Random event generation
│   │   │
│   │   ├── ai/
│   │   │   ├── __init__.py
│   │   │   ├── ceo_brain.py          # AI CEO decision making
│   │   │   ├── personality.py        # CEO personality matrices
│   │   │   ├── executive_ai.py       # C-suite AI behavior
│   │   │   ├── strategy_planner.py   # Long-term AI planning
│   │   │   └── nlp_directive.py      # Natural language parsing
│   │   │
│   │   ├── economics/
│   │   │   ├── __init__.py
│   │   │   ├── gdp_model.py          # GDP/purchasing power model
│   │   │   ├── supply_chain.py       # Raw material pricing
│   │   │   ├── used_car_market.py    # Second-hand market model
│   │   │   └── utility_model.py      # Consumer utility calculations
│   │   │
│   │   ├── engineering/
│   │   │   ├── __init__.py
│   │   │   ├── tech_tree.py          # Technology research system
│   │   │   ├── car_designer.py       # Vehicle design logic
│   │   │   ├── part_catalog.py       # Parts/components system
│   │   │   ├── reverse_engineer.py   # Reverse engineering system
│   │   │   └── platform_system.py    # Shared platform logic
│   │   │
│   │   └── management/
│   │       ├── __init__.py
│   │       ├── delegation.py         # KPI/directive system
│   │       ├── hr_system.py          # Hire/fire, morale, loyalty
│   │       └── org_structure.py      # Organizational inertia
│   │
│   ├── models/                       # SQLAlchemy ORM Models
│   │   ├── __init__.py
│   │   ├── base.py                   # Base model class
│   │   ├── game_state.py             # Game metadata
│   │   ├── company.py                # Companies, executives
│   │   ├── vehicle.py                # Cars, trims, platforms
│   │   ├── parts.py                  # Components, suppliers
│   │   ├── region.py                 # Regions, demographics
│   │   ├── market.py                 # Sales, inventory, used cars
│   │   ├── technology.py             # Tech tree, research
│   │   ├── factory.py                # Production facilities
│   │   └── events.py                 # Historical events log
│   │
│   ├── services/                     # Business Logic Services
│   │   ├── __init__.py
│   │   ├── game_service.py
│   │   ├── turn_service.py
│   │   ├── company_service.py
│   │   ├── market_service.py
│   │   └── design_service.py
│   │
│   ├── utils/
│   │   ├── __init__.py
│   │   ├── math_helpers.py           # Statistical/math utilities
│   │   ├── clustering.py             # Consumer bucket algorithms
│   │   └── validators.py
│   │
│   ├── data/                         # Static Game Data
│   │   ├── initial_world.json        # Starting world state
│   │   ├── tech_tree.json            # Technology definitions
│   │   ├── part_definitions.json     # Component specifications
│   │   ├── region_templates.json     # Region archetypes
│   │   ├── ceo_names.json            # Name generation data
│   │   └── event_templates.json      # Event definitions
│   │
│   ├── tests/
│   │   ├── __init__.py
│   │   ├── test_market_engine.py
│   │   ├── test_utility_model.py
│   │   ├── test_ai_ceo.py
│   │   └── conftest.py
│   │
│   └── requirements.txt
│
├── frontend/                         # React + Vite Frontend
│   ├── package.json
│   ├── vite.config.ts
│   ├── tsconfig.json
│   ├── index.html
│   │
│   ├── src/
│   │   ├── main.tsx                  # React entry point
│   │   ├── App.tsx                   # Root component
│   │   │
│   │   ├── api/                      # API Client Layer
│   │   │   ├── client.ts             # Axios/fetch wrapper
│   │   │   ├── endpoints.ts          # API endpoint definitions
│   │   │   └── types.ts              # TypeScript API types
│   │   │
│   │   ├── stores/                   # State Management (Zustand)
│   │   │   ├── gameStore.ts          # Game state
│   │   │   ├── uiStore.ts            # UI state
│   │   │   └── cacheStore.ts         # Data caching
│   │   │
│   │   ├── components/
│   │   │   ├── common/               # Reusable UI components
│   │   │   │   ├── BlueprintPanel.tsx
│   │   │   │   ├── DataGrid.tsx
│   │   │   │   ├── GaugeCluster.tsx
│   │   │   │   ├── TechnicalChart.tsx
│   │   │   │   └── CADButton.tsx
│   │   │   │
│   │   │   ├── dashboard/            # Main dashboard views
│   │   │   │   ├── WorldMap.tsx
│   │   │   │   ├── CompanyOverview.tsx
│   │   │   │   ├── FinancialSummary.tsx
│   │   │   │   └── NewsTicker.tsx
│   │   │   │
│   │   │   ├── designer/             # Vehicle design interface
│   │   │   │   ├── CarDesigner.tsx
│   │   │   │   ├── SpecSliders.tsx
│   │   │   │   ├── DirectiveInput.tsx
│   │   │   │   ├── BlueprintView.tsx
│   │   │   │   └── PartSelector.tsx
│   │   │   │
│   │   │   ├── production/           # Factory management
│   │   │   │   ├── FactoryView.tsx
│   │   │   │   ├── SupplyChain.tsx
│   │   │   │   └── ProductionQueue.tsx
│   │   │   │
│   │   │   ├── market/               # Market analysis
│   │   │   │   ├── MarketAnalysis.tsx
│   │   │   │   ├── CompetitorMatrix.tsx
│   │   │   │   ├── DemandHeatmap.tsx
│   │   │   │   └── UsedCarTracker.tsx
│   │   │   │
│   │   │   ├── management/           # HR/Executive management
│   │   │   │   ├── ExecutiveBoard.tsx
│   │   │   │   ├── KPIEditor.tsx
│   │   │   │   ├── PhilosophyPanel.tsx
│   │   │   │   └── OrgChart.tsx
│   │   │   │
│   │   │   └── research/             # R&D/Tech tree
│   │   │       ├── TechTree.tsx
│   │   │       ├── ResearchLab.tsx
│   │   │       └── BreakthroughLog.tsx
│   │   │
│   │   ├── pages/                    # Route pages
│   │   │   ├── MainMenu.tsx
│   │   │   ├── GameView.tsx
│   │   │   ├── DesignStudio.tsx
│   │   │   ├── FactoryFloor.tsx
│   │   │   ├── MarketCenter.tsx
│   │   │   ├── ExecutiveSuite.tsx
│   │   │   ├── ResearchCenter.tsx
│   │   │   └── Reports.tsx
│   │   │
│   │   ├── styles/
│   │   │   ├── globals.css           # Global styles
│   │   │   ├── blueprint.css         # CAD/Blueprint theme
│   │   │   ├── variables.css         # CSS custom properties
│   │   │   └── components/           # Component-specific styles
│   │   │
│   │   ├── hooks/                    # Custom React hooks
│   │   │   ├── useGameState.ts
│   │   │   ├── usePolling.ts
│   │   │   └── useKeyboardShortcuts.ts
│   │   │
│   │   ├── utils/
│   │   │   ├── formatters.ts         # Number/date formatting
│   │   │   ├── calculations.ts       # Client-side calculations
│   │   │   └── constants.ts
│   │   │
│   │   └── assets/
│   │       ├── icons/                # SVG icons
│   │       ├── fonts/                # Technical fonts
│   │       └── textures/             # Blueprint textures
│   │
│   └── electron/                     # Electron wrapper
│       ├── main.ts                   # Electron main process
│       ├── preload.ts                # Preload script
│       └── ipc.ts                    # IPC handlers
│
├── shared/                           # Shared type definitions
│   └── types/
│       ├── game.d.ts
│       ├── vehicle.d.ts
│       └── market.d.ts
│
├── saves/                            # Save game directory
│   └── .gitkeep
│
├── docs/                             # Documentation
│   ├── api_reference.md
│   ├── game_mechanics.md
│   └── modding_guide.md
│
├── scripts/
│   ├── start_dev.py                  # Development launcher
│   ├── build_release.py              # Production build
│   └── seed_database.py              # Initial data seeding
│
├── .gitignore
├── README.md
└── design_doc.md                     # This document
```

---

## 4. Database Schema

### 4.1 Entity Relationship Diagram (Conceptual)

```
┌─────────────┐       ┌──────────────┐       ┌─────────────┐
│   REGION    │◄──────│   COMPANY    │───────►│  EXECUTIVE  │
└──────┬──────┘       └──────┬───────┘       └─────────────┘
       │                     │
       │              ┌──────┴───────┐
       │              │              │
       ▼              ▼              ▼
┌─────────────┐ ┌───────────┐ ┌───────────────┐
│CONSUMER_    │ │  VEHICLE  │ │   FACTORY     │
│BUCKET       │ │  MODEL    │ └───────┬───────┘
└──────┬──────┘ └─────┬─────┘         │
       │              │               │
       │              ▼               ▼
       │        ┌───────────┐   ┌───────────┐
       │        │VEHICLE_   │   │PRODUCTION_│
       │        │TRIM       │   │LINE       │
       │        └─────┬─────┘   └───────────┘
       │              │
       ▼              ▼
┌─────────────────────────────┐
│       SALES_RECORD          │
└─────────────────────────────┘
              │
              ▼
┌─────────────────────────────┐
│     USED_CAR_INVENTORY      │
└─────────────────────────────┘
```

### 4.2 SQL Table Definitions

```sql
-- ============================================================
-- WORLD & REGIONS
-- ============================================================

CREATE TABLE game_state (
    id INTEGER PRIMARY KEY,
    save_name TEXT NOT NULL,
    current_year INTEGER NOT NULL DEFAULT 1950,
    current_month INTEGER NOT NULL DEFAULT 1,
    current_week INTEGER NOT NULL DEFAULT 1,
    turn_number INTEGER NOT NULL DEFAULT 0,
    difficulty TEXT NOT NULL DEFAULT 'normal',
    simulation_speed TEXT NOT NULL DEFAULT 'monthly',
    random_seed INTEGER,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE regions (
    id INTEGER PRIMARY KEY,
    game_id INTEGER NOT NULL REFERENCES game_state(id) ON DELETE CASCADE,
    code TEXT NOT NULL,                           -- 'NAM', 'EUR', 'ASI', etc.
    name TEXT NOT NULL,
    
    -- Economic Indicators
    population BIGINT NOT NULL,
    gdp_per_capita REAL NOT NULL,                 -- Current GDP per capita
    gdp_growth_rate REAL NOT NULL DEFAULT 0.02,   -- Annual growth rate
    purchasing_power_index REAL NOT NULL,         -- Relative to baseline
    inflation_rate REAL NOT NULL DEFAULT 0.03,
    unemployment_rate REAL NOT NULL DEFAULT 0.05,
    
    -- Market Characteristics
    car_ownership_rate REAL NOT NULL,             -- Cars per 1000 people
    avg_vehicle_age REAL NOT NULL,                -- Average fleet age in years
    annual_sales_potential INTEGER NOT NULL,      -- Max addressable market
    
    -- Infrastructure & Environment
    infrastructure_quality REAL NOT NULL,         -- 0-1: affects rugged vs city
    road_quality REAL NOT NULL,                   -- 0-1: affects suspension needs
    fuel_price REAL NOT NULL,                     -- Per liter in game currency
    electricity_price REAL NOT NULL,              -- For EV calculations
    
    -- Policy & Regulation
    import_tariff_rate REAL NOT NULL DEFAULT 0.0,
    emission_standard TEXT NOT NULL,              -- 'NONE', 'EURO1', 'EURO2', etc.
    safety_standard TEXT NOT NULL,                -- 'BASIC', 'MODERATE', 'STRICT'
    corporate_tax_rate REAL NOT NULL,
    ev_subsidy_rate REAL NOT NULL DEFAULT 0.0,
    
    -- Resource Availability (for factories)
    steel_availability REAL NOT NULL,             -- 0-1
    aluminum_availability REAL NOT NULL,
    rare_earth_availability REAL NOT NULL,
    labor_cost_index REAL NOT NULL,               -- Relative to baseline
    skilled_labor_availability REAL NOT NULL,
    
    -- Cultural Preferences (base modifiers)
    pref_size_small REAL NOT NULL DEFAULT 0.33,
    pref_size_medium REAL NOT NULL DEFAULT 0.34,
    pref_size_large REAL NOT NULL DEFAULT 0.33,
    pref_sporty REAL NOT NULL DEFAULT 0.2,
    pref_luxury REAL NOT NULL DEFAULT 0.15,
    pref_economy REAL NOT NULL DEFAULT 0.4,
    pref_utility REAL NOT NULL DEFAULT 0.25,
    brand_loyalty_factor REAL NOT NULL DEFAULT 0.5, -- How much brand matters
    
    UNIQUE(game_id, code)
);

CREATE INDEX idx_regions_game ON regions(game_id);

-- ============================================================
-- COMPANIES & EXECUTIVES
-- ============================================================

CREATE TABLE companies (
    id INTEGER PRIMARY KEY,
    game_id INTEGER NOT NULL REFERENCES game_state(id) ON DELETE CASCADE,
    
    name TEXT NOT NULL,
    short_name TEXT NOT NULL,                     -- 3-4 letter code
    founded_year INTEGER NOT NULL,
    headquarters_region_id INTEGER REFERENCES regions(id),
    is_player_controlled BOOLEAN NOT NULL DEFAULT FALSE,
    is_bankrupt BOOLEAN NOT NULL DEFAULT FALSE,
    
    -- Financial State
    cash_balance REAL NOT NULL DEFAULT 10000000,
    total_debt REAL NOT NULL DEFAULT 0,
    credit_rating TEXT NOT NULL DEFAULT 'BBB',    -- AAA to D
    stock_price REAL,                             -- NULL if private
    shares_outstanding INTEGER,
    
    -- Company Metrics
    brand_prestige REAL NOT NULL DEFAULT 50,      -- 0-100
    brand_reliability REAL NOT NULL DEFAULT 50,   -- 0-100 (built over time)
    brand_innovation REAL NOT NULL DEFAULT 50,    -- 0-100
    brand_value REAL NOT NULL DEFAULT 50,         -- 0-100 (perceived value)
    
    -- Organizational Properties
    employee_count INTEGER NOT NULL DEFAULT 1000,
    avg_employee_morale REAL NOT NULL DEFAULT 70, -- 0-100
    organizational_inertia REAL NOT NULL,         -- Derived from size
    bureaucracy_level REAL NOT NULL DEFAULT 0.3,  -- 0-1: affects decision speed
    
    -- AI-Only Fields (NULL for player)
    ceo_id INTEGER REFERENCES executives(id),
    company_philosophy TEXT,                      -- JSON: AI strategic tendencies
    
    UNIQUE(game_id, short_name)
);

CREATE TABLE executives (
    id INTEGER PRIMARY KEY,
    game_id INTEGER NOT NULL REFERENCES game_state(id) ON DELETE CASCADE,
    company_id INTEGER REFERENCES companies(id) ON DELETE SET NULL,
    
    first_name TEXT NOT NULL,
    last_name TEXT NOT NULL,
    birth_year INTEGER NOT NULL,
    nationality_region_id INTEGER REFERENCES regions(id),
    
    role TEXT NOT NULL,                           -- 'CEO', 'CTO', 'CFO', 'COO', 'CMO'
    hire_date_turn INTEGER NOT NULL,
    salary REAL NOT NULL,
    contract_end_turn INTEGER,
    
    -- Personality Matrix (0-100)
    aggression REAL NOT NULL DEFAULT 50,
    innovation REAL NOT NULL DEFAULT 50,
    risk_tolerance REAL NOT NULL DEFAULT 50,
    loyalty REAL NOT NULL DEFAULT 50,
    
    -- Performance Metrics
    competence REAL NOT NULL DEFAULT 50,          -- 0-100: affects execution quality
    experience_years INTEGER NOT NULL DEFAULT 0,
    morale REAL NOT NULL DEFAULT 70,              -- 0-100
    current_loyalty REAL NOT NULL DEFAULT 70,     -- To current company
    
    -- Track Record (JSON)
    career_history TEXT,                          -- Previous positions
    notable_achievements TEXT,                    -- Array of achievement codes
    notable_failures TEXT,
    
    -- State
    is_available BOOLEAN NOT NULL DEFAULT TRUE,   -- On job market?
    is_retired BOOLEAN NOT NULL DEFAULT FALSE
);

CREATE INDEX idx_executives_company ON executives(company_id);
CREATE INDEX idx_executives_available ON executives(is_available) WHERE is_available = TRUE;

-- ============================================================
-- VEHICLES & PARTS
-- ============================================================

CREATE TABLE vehicle_platforms (
    id INTEGER PRIMARY KEY,
    company_id INTEGER NOT NULL REFERENCES companies(id) ON DELETE CASCADE,
    
    name TEXT NOT NULL,
    code TEXT NOT NULL,                           -- Internal platform code
    development_start_turn INTEGER NOT NULL,
    development_complete_turn INTEGER,
    
    -- Platform Specs (define what vehicles can be built)
    min_wheelbase_mm INTEGER NOT NULL,
    max_wheelbase_mm INTEGER NOT NULL,
    supported_drivetrains TEXT NOT NULL,          -- JSON array: ['FWD', 'RWD', 'AWD']
    supported_body_styles TEXT NOT NULL,          -- JSON array
    max_engine_displacement_cc INTEGER,
    supports_electric BOOLEAN NOT NULL DEFAULT FALSE,
    supports_hybrid BOOLEAN NOT NULL DEFAULT FALSE,
    
    -- Costs
    development_cost REAL NOT NULL,
    per_unit_cost REAL NOT NULL,                  -- Added to each vehicle
    
    -- Quality
    rigidity_rating REAL NOT NULL,                -- Affects handling
    safety_rating_base REAL NOT NULL,
    weight_base_kg INTEGER NOT NULL,
    
    is_active BOOLEAN NOT NULL DEFAULT TRUE,
    
    UNIQUE(company_id, code)
);

CREATE TABLE vehicle_models (
    id INTEGER PRIMARY KEY,
    company_id INTEGER NOT NULL REFERENCES companies(id) ON DELETE CASCADE,
    platform_id INTEGER REFERENCES vehicle_platforms(id),
    
    name TEXT NOT NULL,
    model_code TEXT NOT NULL,
    generation INTEGER NOT NULL DEFAULT 1,
    
    -- Development
    design_start_turn INTEGER NOT NULL,
    design_complete_turn INTEGER,
    production_start_turn INTEGER,
    production_end_turn INTEGER,
    
    -- Classification
    body_style TEXT NOT NULL,                     -- 'SEDAN', 'COUPE', 'SUV', 'TRUCK', etc.
    segment TEXT NOT NULL,                        -- 'SUBCOMPACT', 'COMPACT', 'MIDSIZE', 'FULLSIZE'
    market_position TEXT NOT NULL,                -- 'ECONOMY', 'MAINSTREAM', 'PREMIUM', 'LUXURY'
    
    -- Core Dimensions
    length_mm INTEGER NOT NULL,
    width_mm INTEGER NOT NULL,
    height_mm INTEGER NOT NULL,
    wheelbase_mm INTEGER NOT NULL,
    curb_weight_kg INTEGER NOT NULL,
    cargo_volume_liters INTEGER NOT NULL,
    seating_capacity INTEGER NOT NULL,
    
    -- Target Specs (from design directive)
    target_reliability REAL,
    target_performance REAL,
    target_efficiency REAL,
    target_comfort REAL,
    target_safety REAL,
    target_price_point REAL,
    
    -- Calculated Overall Scores (updated after trim specs finalized)
    overall_quality_score REAL,
    overall_reliability_score REAL,
    development_cost_total REAL,
    
    -- Design Origin
    designed_via TEXT NOT NULL,                   -- 'MANUAL', 'DIRECTIVE', 'AI'
    design_directive_text TEXT,                   -- Original NL directive if applicable
    
    is_active BOOLEAN NOT NULL DEFAULT FALSE,
    
    UNIQUE(company_id, model_code, generation)
);

CREATE TABLE vehicle_trims (
    id INTEGER PRIMARY KEY,
    model_id INTEGER NOT NULL REFERENCES vehicle_models(id) ON DELETE CASCADE,
    
    name TEXT NOT NULL,                           -- 'Base', 'Sport', 'Luxury', etc.
    trim_code TEXT NOT NULL,
    
    -- Powertrain
    engine_id INTEGER REFERENCES parts(id),
    transmission_id INTEGER REFERENCES parts(id),
    drivetrain TEXT NOT NULL,                     -- 'FWD', 'RWD', 'AWD'
    
    -- Performance Specs (calculated from parts)
    horsepower INTEGER NOT NULL,
    torque_nm INTEGER NOT NULL,
    zero_to_sixty_sec REAL NOT NULL,
    top_speed_kph INTEGER NOT NULL,
    fuel_economy_l_100km REAL NOT NULL,
    co2_emissions_g_km INTEGER NOT NULL,
    
    -- Features & Equipment (JSON arrays of part IDs)
    suspension_id INTEGER REFERENCES parts(id),
    brake_system_id INTEGER REFERENCES parts(id),
    interior_package_id INTEGER REFERENCES parts(id),
    safety_package_id INTEGER REFERENCES parts(id),
    infotainment_id INTEGER REFERENCES parts(id),
    optional_features TEXT,                       -- JSON array of part IDs
    
    -- Calculated Scores (0-100)
    performance_score REAL NOT NULL,
    comfort_score REAL NOT NULL,
    safety_score REAL NOT NULL,
    technology_score REAL NOT NULL,
    prestige_score REAL NOT NULL,
    reliability_score REAL NOT NULL,
    
    -- Pricing
    manufacturing_cost REAL NOT NULL,
    msrp REAL NOT NULL,
    dealer_margin_percent REAL NOT NULL DEFAULT 0.08,
    
    -- Production
    is_in_production BOOLEAN NOT NULL DEFAULT FALSE,
    monthly_production_target INTEGER,
    
    UNIQUE(model_id, trim_code)
);

CREATE INDEX idx_trims_model ON vehicle_trims(model_id);
CREATE INDEX idx_trims_production ON vehicle_trims(is_in_production) WHERE is_in_production = TRUE;

CREATE TABLE parts (
    id INTEGER PRIMARY KEY,
    game_id INTEGER NOT NULL REFERENCES game_state(id) ON DELETE CASCADE,
    
    category TEXT NOT NULL,                       -- 'ENGINE', 'TRANSMISSION', 'SUSPENSION', etc.
    subcategory TEXT,                             -- 'I4', 'V6', 'V8', 'ELECTRIC', etc.
    name TEXT NOT NULL,
    part_code TEXT NOT NULL,
    
    -- Ownership
    designer_company_id INTEGER REFERENCES companies(id), -- NULL = generic/supplier
    is_proprietary BOOLEAN NOT NULL DEFAULT FALSE,
    can_license BOOLEAN NOT NULL DEFAULT TRUE,
    license_fee_per_unit REAL,
    
    -- Specifications (JSON - varies by category)
    specifications TEXT NOT NULL,                 -- Category-specific specs
    
    -- For Engines specifically
    displacement_cc INTEGER,
    cylinder_count INTEGER,
    aspiration TEXT,                              -- 'NA', 'TURBO', 'SUPERCHARGED', 'TWINTURBO'
    fuel_type TEXT,                               -- 'GASOLINE', 'DIESEL', 'ELECTRIC', 'HYBRID'
    max_horsepower INTEGER,
    max_torque INTEGER,
    
    -- Quality & Cost
    quality_rating REAL NOT NULL,                 -- 0-100
    reliability_rating REAL NOT NULL,             -- 0-100
    manufacturing_cost REAL NOT NULL,
    weight_kg REAL NOT NULL,
    
    -- Tech Requirements
    required_tech_level INTEGER NOT NULL DEFAULT 0,
    required_technologies TEXT,                   -- JSON array of tech IDs
    
    -- Development
    development_cost REAL,
    development_months INTEGER,
    developed_turn INTEGER,
    
    is_available BOOLEAN NOT NULL DEFAULT TRUE,
    
    UNIQUE(game_id, part_code)
);

CREATE INDEX idx_parts_category ON parts(category);
CREATE INDEX idx_parts_designer ON parts(designer_company_id);

CREATE TABLE part_suppliers (
    id INTEGER PRIMARY KEY,
    game_id INTEGER NOT NULL REFERENCES game_state(id) ON DELETE CASCADE,
    
    name TEXT NOT NULL,
    headquarters_region_id INTEGER REFERENCES regions(id),
    specialty TEXT NOT NULL,                      -- Part category they specialize in
    
    quality_rating REAL NOT NULL,                 -- 0-100
    reliability_rating REAL NOT NULL,             -- Delivery reliability
    capacity INTEGER NOT NULL,                    -- Monthly units
    
    base_cost_modifier REAL NOT NULL DEFAULT 1.0, -- Multiplier on part costs
    lead_time_weeks INTEGER NOT NULL DEFAULT 4,
    
    -- Relationship tracking per company
    -- (handled in separate junction table)
    
    is_active BOOLEAN NOT NULL DEFAULT TRUE
);

CREATE TABLE company_supplier_relations (
    company_id INTEGER NOT NULL REFERENCES companies(id) ON DELETE CASCADE,
    supplier_id INTEGER NOT NULL REFERENCES part_suppliers(id) ON DELETE CASCADE,
    
    relationship_score REAL NOT NULL DEFAULT 50,  -- 0-100
    contracted_volume INTEGER,                    -- Monthly units
    contract_price_modifier REAL NOT NULL DEFAULT 1.0,
    contract_end_turn INTEGER,
    
    PRIMARY KEY (company_id, supplier_id)
);

-- ============================================================
-- TECHNOLOGY & RESEARCH
-- ============================================================

CREATE TABLE technologies (
    id INTEGER PRIMARY KEY,
    game_id INTEGER NOT NULL REFERENCES game_state(id) ON DELETE CASCADE,
    
    tech_code TEXT NOT NULL,
    name TEXT NOT NULL,
    category TEXT NOT NULL,                       -- 'ENGINE', 'CHASSIS', 'SAFETY', 'ELECTRONICS'
    
    description TEXT,
    
    -- Prerequisites
    prerequisite_techs TEXT,                      -- JSON array of tech_codes
    min_year INTEGER NOT NULL,                    -- Earliest possible discovery
    
    -- Research Parameters
    base_research_cost REAL NOT NULL,             -- Total investment needed
    base_research_months INTEGER NOT NULL,
    difficulty REAL NOT NULL,                     -- Affects breakthrough probability
    
    -- Effects when unlocked
    unlocks_parts TEXT,                           -- JSON array of part_codes
    unlocks_features TEXT,                        -- JSON array of feature codes
    stat_modifiers TEXT,                          -- JSON: {"reliability": 1.05, "efficiency": 1.1}
    
    UNIQUE(game_id, tech_code)
);

CREATE TABLE company_research (
    id INTEGER PRIMARY KEY,
    company_id INTEGER NOT NULL REFERENCES companies(id) ON DELETE CASCADE,
    technology_id INTEGER NOT NULL REFERENCES technologies(id) ON DELETE CASCADE,
    
    status TEXT NOT NULL DEFAULT 'LOCKED',        -- 'LOCKED', 'AVAILABLE', 'RESEARCHING', 'COMPLETE'
    
    research_invested REAL NOT NULL DEFAULT 0,
    research_started_turn INTEGER,
    research_completed_turn INTEGER,
    
    -- Breakthrough tracking
    monthly_investment REAL NOT NULL DEFAULT 0,
    breakthrough_progress REAL NOT NULL DEFAULT 0, -- 0-1, probabilistic
    breakthrough_attempts INTEGER NOT NULL DEFAULT 0,
    
    assigned_engineers INTEGER NOT NULL DEFAULT 0,
    
    UNIQUE(company_id, technology_id)
);

-- ============================================================
-- FACTORIES & PRODUCTION
-- ============================================================

CREATE TABLE factories (
    id INTEGER PRIMARY KEY,
    company_id INTEGER NOT NULL REFERENCES companies(id) ON DELETE CASCADE,
    region_id INTEGER NOT NULL REFERENCES regions(id),
    
    name TEXT NOT NULL,
    factory_type TEXT NOT NULL,                   -- 'ASSEMBLY', 'ENGINE', 'STAMPING', 'FULL'
    
    -- Capacity
    max_monthly_capacity INTEGER NOT NULL,
    current_utilization REAL NOT NULL DEFAULT 0,  -- 0-1
    
    -- Workforce
    worker_count INTEGER NOT NULL,
    worker_skill_level REAL NOT NULL DEFAULT 50,  -- 0-100
    worker_morale REAL NOT NULL DEFAULT 70,       -- 0-100
    automation_level REAL NOT NULL DEFAULT 0.2,   -- 0-1
    
    -- Quality & Efficiency
    quality_rating REAL NOT NULL DEFAULT 50,      -- 0-100: affects defect rate
    efficiency_rating REAL NOT NULL DEFAULT 50,   -- 0-100: affects cost
    
    -- Costs
    fixed_monthly_cost REAL NOT NULL,
    variable_cost_per_unit REAL NOT NULL,
    
    -- State
    construction_complete_turn INTEGER,
    last_major_upgrade_turn INTEGER,
    is_operational BOOLEAN NOT NULL DEFAULT TRUE,
    
    UNIQUE(company_id, name)
);

CREATE TABLE production_lines (
    id INTEGER PRIMARY KEY,
    factory_id INTEGER NOT NULL REFERENCES factories(id) ON DELETE CASCADE,
    vehicle_trim_id INTEGER REFERENCES vehicle_trims(id),
    
    name TEXT NOT NULL,
    line_type TEXT NOT NULL,                      -- 'FLEXIBLE', 'DEDICATED'
    
    -- Capacity (subset of factory capacity)
    max_monthly_capacity INTEGER NOT NULL,
    current_monthly_target INTEGER NOT NULL DEFAULT 0,
    
    -- Tooling
    current_tooling_for_model_id INTEGER REFERENCES vehicle_models(id),
    retooling_cost REAL,
    retooling_months_remaining INTEGER DEFAULT 0,
    
    -- Performance
    actual_output_last_month INTEGER DEFAULT 0,
    defect_rate REAL NOT NULL DEFAULT 0.02,       -- 0-1
    
    is_active BOOLEAN NOT NULL DEFAULT TRUE
);

CREATE TABLE production_orders (
    id INTEGER PRIMARY KEY,
    production_line_id INTEGER NOT NULL REFERENCES production_lines(id),
    vehicle_trim_id INTEGER NOT NULL REFERENCES vehicle_trims(id),
    
    order_turn INTEGER NOT NULL,
    quantity_ordered INTEGER NOT NULL,
    quantity_produced INTEGER NOT NULL DEFAULT 0,
    quantity_defective INTEGER NOT NULL DEFAULT 0,
    
    status TEXT NOT NULL DEFAULT 'PENDING',       -- 'PENDING', 'IN_PROGRESS', 'COMPLETE', 'CANCELLED'
    
    estimated_completion_turn INTEGER,
    actual_completion_turn INTEGER,
    
    unit_cost_actual REAL
);

-- ============================================================
-- MARKET & SALES
-- ============================================================

CREATE TABLE consumer_buckets (
    id INTEGER PRIMARY KEY,
    region_id INTEGER NOT NULL REFERENCES regions(id) ON DELETE CASCADE,
    
    bucket_code TEXT NOT NULL,
    name TEXT NOT NULL,                           -- 'Young Urban Professional', etc.
    
    -- Demographics
    population_count INTEGER NOT NULL,
    avg_income REAL NOT NULL,
    avg_age REAL NOT NULL,
    
    -- Purchase Behavior
    purchase_frequency_years REAL NOT NULL,       -- Avg years between purchases
    price_sensitivity REAL NOT NULL,              -- 0-1: higher = more sensitive
    brand_loyalty REAL NOT NULL,                  -- 0-1
    early_adopter_score REAL NOT NULL,            -- 0-1: willingness to try new
    
    -- Utility Weights (must sum to 1.0)
    weight_price REAL NOT NULL,
    weight_performance REAL NOT NULL,
    weight_comfort REAL NOT NULL,
    weight_reliability REAL NOT NULL,
    weight_safety REAL NOT NULL,
    weight_prestige REAL NOT NULL,
    weight_efficiency REAL NOT NULL,
    weight_practicality REAL NOT NULL,
    
    -- Preferences
    preferred_body_styles TEXT NOT NULL,          -- JSON array
    preferred_size TEXT NOT NULL,                 -- 'SMALL', 'MEDIUM', 'LARGE', 'ANY'
    min_acceptable_utility REAL NOT NULL,         -- Threshold to buy new
    
    -- Dynamic State
    current_demand INTEGER NOT NULL,              -- Units wanting to buy this turn
    satisfied_demand INTEGER NOT NULL DEFAULT 0,  -- Units that bought
    
    UNIQUE(region_id, bucket_code)
);

CREATE INDEX idx_buckets_region ON consumer_buckets(region_id);

CREATE TABLE vehicle_inventory (
    id INTEGER PRIMARY KEY,
    vehicle_trim_id INTEGER NOT NULL REFERENCES vehicle_trims(id),
    region_id INTEGER NOT NULL REFERENCES regions(id),
    
    quantity_new INTEGER NOT NULL DEFAULT 0,
    quantity_in_transit INTEGER NOT NULL DEFAULT 0,
    
    -- Pricing
    current_msrp REAL NOT NULL,
    current_discount_percent REAL NOT NULL DEFAULT 0,
    
    -- Age tracking (for calculating holding costs)
    avg_days_in_inventory REAL NOT NULL DEFAULT 0,
    
    UNIQUE(vehicle_trim_id, region_id)
);

CREATE TABLE sales_history (
    id INTEGER PRIMARY KEY,
    
    turn_number INTEGER NOT NULL,
    vehicle_trim_id INTEGER NOT NULL REFERENCES vehicle_trims(id),
    region_id INTEGER NOT NULL REFERENCES regions(id),
    consumer_bucket_id INTEGER REFERENCES consumer_buckets(id),
    
    -- Sales Data
    units_sold INTEGER NOT NULL,
    revenue_total REAL NOT NULL,
    avg_transaction_price REAL NOT NULL,
    avg_discount_percent REAL NOT NULL,
    
    -- Competitive Context
    market_share_percent REAL,
    segment_rank INTEGER,
    
    -- Profitability
    gross_profit_total REAL NOT NULL,
    gross_margin_percent REAL NOT NULL
);

CREATE INDEX idx_sales_turn ON sales_history(turn_number);
CREATE INDEX idx_sales_trim ON sales_history(vehicle_trim_id);
CREATE INDEX idx_sales_region ON sales_history(region_id);
CREATE INDEX idx_sales_composite ON sales_history(turn_number, region_id, vehicle_trim_id);

CREATE TABLE used_car_inventory (
    id INTEGER PRIMARY KEY,
    original_trim_id INTEGER NOT NULL REFERENCES vehicle_trims(id),
    region_id INTEGER NOT NULL REFERENCES regions(id),
    
    -- Cohort tracking (by age)
    age_years INTEGER NOT NULL,                   -- 1, 2, 3, ... 15+
    quantity INTEGER NOT NULL,
    
    -- Condition distribution within cohort
    condition_excellent_pct REAL NOT NULL DEFAULT 0.2,
    condition_good_pct REAL NOT NULL DEFAULT 0.5,
    condition_fair_pct REAL NOT NULL DEFAULT 0.25,
    condition_poor_pct REAL NOT NULL DEFAULT 0.05,
    
    -- Pricing
    avg_asking_price REAL NOT NULL,
    avg_transaction_price REAL NOT NULL,
    
    -- Depreciation
    depreciation_rate REAL NOT NULL,              -- Annual rate for this cohort
    
    UNIQUE(original_trim_id, region_id, age_years)
);

CREATE TABLE used_car_sales (
    id INTEGER PRIMARY KEY,
    
    turn_number INTEGER NOT NULL,
    region_id INTEGER NOT NULL REFERENCES regions(id),
    original_trim_id INTEGER NOT NULL REFERENCES vehicle_trims(id),
    age_years INTEGER NOT NULL,
    
    units_sold INTEGER NOT NULL,
    avg_price REAL NOT NULL,
    
    -- Who bought (tracks competition with new cars)
    buyer_bucket_id INTEGER REFERENCES consumer_buckets(id)
);

-- ============================================================
-- EVENTS & HISTORY
-- ============================================================

CREATE TABLE game_events (
    id INTEGER PRIMARY KEY,
    game_id INTEGER NOT NULL REFERENCES game_state(id) ON DELETE CASCADE,
    
    turn_number INTEGER NOT NULL,
    event_type TEXT NOT NULL,                     -- 'ECONOMIC', 'COMPANY', 'TECHNOLOGY', 'SCANDAL'
    severity TEXT NOT NULL,                       -- 'MINOR', 'MODERATE', 'MAJOR', 'CRITICAL'
    
    headline TEXT NOT NULL,
    description TEXT NOT NULL,
    
    -- Affected entities
    affected_company_id INTEGER REFERENCES companies(id),
    affected_region_id INTEGER REFERENCES regions(id),
    affected_technology_id INTEGER REFERENCES technologies(id),
    
    -- Effects (JSON)
    immediate_effects TEXT,                       -- Applied this turn
    ongoing_effects TEXT,                         -- Applied each turn
    duration_turns INTEGER,                       -- How long ongoing effects last
    
    is_player_visible BOOLEAN NOT NULL DEFAULT TRUE,
    is_acknowledged BOOLEAN NOT NULL DEFAULT FALSE
);

CREATE INDEX idx_events_turn ON game_events(turn_number);
CREATE INDEX idx_events_type ON game_events(event_type);

CREATE TABLE company_financials_history (
    id INTEGER PRIMARY KEY,
    company_id INTEGER NOT NULL REFERENCES companies(id) ON DELETE CASCADE,
    turn_number INTEGER NOT NULL,
    
    -- Income Statement
    revenue_vehicles REAL NOT NULL DEFAULT 0,
    revenue_licensing REAL NOT NULL DEFAULT 0,
    revenue_other REAL NOT NULL DEFAULT 0,
    
    cost_manufacturing REAL NOT NULL DEFAULT 0,
    cost_materials REAL NOT NULL DEFAULT 0,
    cost_labor REAL NOT NULL DEFAULT 0,
    cost_rd REAL NOT NULL DEFAULT 0,
    cost_marketing REAL NOT NULL DEFAULT 0,
    cost_admin REAL NOT NULL DEFAULT 0,
    cost_depreciation REAL NOT NULL DEFAULT 0,
    cost_interest REAL NOT NULL DEFAULT 0,
    
    gross_profit REAL NOT NULL DEFAULT 0,
    operating_profit REAL NOT NULL DEFAULT 0,
    net_income REAL NOT NULL DEFAULT 0,
    
    -- Balance Sheet Snapshot
    cash_end REAL NOT NULL DEFAULT 0,
    inventory_value REAL NOT NULL DEFAULT 0,
    total_assets REAL NOT NULL DEFAULT 0,
    total_liabilities REAL NOT NULL DEFAULT 0,
    shareholder_equity REAL NOT NULL DEFAULT 0,
    
    -- Key Metrics
    units_sold INTEGER NOT NULL DEFAULT 0,
    units_produced INTEGER NOT NULL DEFAULT 0,
    market_share_global REAL,
    
    UNIQUE(company_id, turn_number)
);

CREATE INDEX idx_financials_company_turn ON company_financials_history(company_id, turn_number);

-- ============================================================
-- PLAYER MANAGEMENT SYSTEM
-- ============================================================

CREATE TABLE company_directives (
    id INTEGER PRIMARY KEY,
    company_id INTEGER NOT NULL REFERENCES companies(id) ON DELETE CASCADE,
    
    directive_type TEXT NOT NULL,                 -- 'PHILOSOPHY', 'KPI', 'NATURAL_LANGUAGE', 'SPECIFIC'
    category TEXT,                                -- 'DESIGN', 'PRODUCTION', 'MARKETING', 'RD', 'HR'
    
    -- For NL directives
    original_text TEXT,
    parsed_parameters TEXT,                       -- JSON: parsed intent
    
    -- For KPI directives
    kpi_metric TEXT,                              -- 'MARKET_SHARE', 'PROFIT_MARGIN', etc.
    kpi_target_value REAL,
    kpi_deadline_turn INTEGER,
    
    -- For philosophy directives
    philosophy_key TEXT,                          -- 'QUALITY_VS_QUANTITY', 'INNOVATION_VS_RELIABILITY'
    philosophy_value REAL,                        -- 0-1 scale
    
    -- Assignment
    assigned_executive_id INTEGER REFERENCES executives(id),
    
    -- Status
    status TEXT NOT NULL DEFAULT 'ACTIVE',        -- 'ACTIVE', 'COMPLETED', 'FAILED', 'CANCELLED'
    created_turn INTEGER NOT NULL,
    deadline_turn INTEGER,
    
    -- Execution tracking
    progress_percent REAL NOT NULL DEFAULT 0,
    execution_quality REAL,                       -- 0-1: how well executed
    
    notes TEXT                                    -- Feedback from AI/executives
);

CREATE INDEX idx_directives_company ON company_directives(company_id);
CREATE INDEX idx_directives_status ON company_directives(status);

-- ============================================================
-- 3D-READY DATA STRUCTURES
-- ============================================================

CREATE TABLE vehicle_visual_specs (
    id INTEGER PRIMARY KEY,
    model_id INTEGER NOT NULL REFERENCES vehicle_models(id) ON DELETE CASCADE,
    
    -- Body proportions (normalized 0-1, for procedural generation)
    hood_length_ratio REAL NOT NULL,
    cabin_length_ratio REAL NOT NULL,
    trunk_length_ratio REAL NOT NULL,
    
    front_overhang_ratio REAL NOT NULL,
    rear_overhang_ratio REAL NOT NULL,
    
    beltline_height_ratio REAL NOT NULL,
    greenhouse_height_ratio REAL NOT NULL,
    
    -- Styling parameters
    front_fascia_style TEXT,                      -- 'AGGRESSIVE', 'CONSERVATIVE', 'ELEGANT', etc.
    rear_fascia_style TEXT,
    side_profile_style TEXT,
    
    -- Detailed geometry hints (for future 3D)
    grille_style TEXT,
    headlight_shape TEXT,
    taillight_shape TEXT,
    wheel_arch_style TEXT,
    roofline_style TEXT,
    
    -- Color and material definitions
    available_colors TEXT,                        -- JSON array
    available_materials TEXT,                     -- JSON: interior/exterior materials
    
    UNIQUE(model_id)
);

CREATE TABLE part_visual_specs (
    id INTEGER PRIMARY KEY,
    part_id INTEGER NOT NULL REFERENCES parts(id) ON DELETE CASCADE,
    
    -- Physical dimensions (mm)
    length_mm REAL,
    width_mm REAL,
    height_mm REAL,
    
    -- Mounting points (JSON: array of {x, y, z, type})
    mounting_points TEXT,
    
    -- Visual style hints
    visual_style TEXT,
    material_primary TEXT,
    material_finish TEXT,
    
    UNIQUE(part_id)
);

-- ============================================================
-- INDEXES FOR PERFORMANCE
-- ============================================================

CREATE INDEX idx_vehicles_company ON vehicle_models(company_id);
CREATE INDEX idx_vehicles_active ON vehicle_models(is_active) WHERE is_active = TRUE;
CREATE INDEX idx_vehicles_segment ON vehicle_models(segment, market_position);

CREATE INDEX idx_factories_company ON factories(company_id);
CREATE INDEX idx_factories_region ON factories(region_id);

CREATE INDEX idx_research_status ON company_research(status);

-- ============================================================
-- VIEWS FOR COMMON QUERIES
-- ============================================================

CREATE VIEW v_active_vehicles AS
SELECT 
    vm.id AS model_id,
    vm.name AS model_name,
    c.id AS company_id,
    c.name AS company_name,
    vt.id AS trim_id,
    vt.name AS trim_name,
    vt.msrp,
    vt.performance_score,
    vt.comfort_score,
    vt.safety_score,
    vt.reliability_score,
    vm.segment,
    vm.body_style,
    vm.market_position
FROM vehicle_models vm
JOIN companies c ON vm.company_id = c.id
JOIN vehicle_trims vt ON vt.model_id = vm.id
WHERE vm.is_active = TRUE 
  AND vt.is_in_production = TRUE;

CREATE VIEW v_market_summary AS
SELECT 
    r.id AS region_id,
    r.name AS region_name,
    r.population,
    r.gdp_per_capita,
    SUM(cb.population_count) AS total_consumers,
    SUM(cb.current_demand) AS total_demand,
    SUM(cb.satisfied_demand) AS satisfied_demand
FROM regions r
JOIN consumer_buckets cb ON cb.region_id = r.id
GROUP BY r.id, r.name, r.population, r.gdp_per_capita;
```

---

## 5. Core Game Systems

### 5.1 The World (Macro Economy)

#### 5.1.1 Regional Economic Model

Each region operates as a semi-independent economic unit with interconnected variables:

```
┌─────────────────────────────────────────────────────────────┐
│                    REGIONAL ECONOMY                         │
│                                                             │
│   GDP Growth ──────┬──────► Purchasing Power               │
│       ▲            │              │                         │
│       │            │              ▼                         │
│   Investment ◄─────┼────── Consumer Demand                  │
│       │            │              │                         │
│       │            │              ▼                         │
│       │            └──────► Car Sales ───► Used Car Supply  │
│       │                          │                          │
│       └──────────────────────────┘                          │
│                                                             │
│   External Shocks: Oil prices, Trade wars, Recessions      │
└─────────────────────────────────────────────────────────────┘
```

**Regional Traits:**
- **Infrastructure Level (0-1):** Affects preference for rugged vs. city vehicles
- **Fuel Price Index:** Directly impacts fuel efficiency utility weight
- **Urbanization Rate:** Affects preferred vehicle size
- **Income Distribution (Gini):** Shapes consumer bucket populations

#### 5.1.2 Economic Cycles

The simulation includes realistic economic cycles:

- **Business Cycles:** 7-12 year periods of expansion/contraction
- **Sector Shocks:** Random events affecting specific industries
- **Commodity Cycles:** Steel, aluminum, rare earth price fluctuations
- **Currency Effects:** Exchange rates affect import/export competitiveness

### 5.2 The Market (Demand System)

#### 5.2.1 Consumer Bucket Architecture

Instead of simulating individuals, consumers are aggregated into **buckets** based on cluster analysis of:

- Income bracket
- Age cohort
- Geographic sub-region
- Lifestyle preferences
- Current vehicle ownership

**Bucket Properties:**
```python
class ConsumerBucket:
    population: int           # Number of consumers in bucket
    utility_weights: dict     # {attribute: weight} - must sum to 1.0
    min_utility_threshold: float  # Won't buy if utility below this
    price_ceiling: float      # Maximum they can spend
    brand_preferences: dict   # {company_id: affinity_score}
    purchase_intent: float    # Probability of buying this period
```

#### 5.2.2 The Utility Threshold Model

Every potential buyer calculates **utility** for each available vehicle:

```
U(vehicle, buyer) = Σ(weight_i × normalized_score_i) × brand_modifier × price_modifier
```

**Decision Logic:**
1. Calculate utility for all available vehicles (new + used)
2. If max(utility) < threshold → NO PURCHASE (buyer walks/waits)
3. If max(utility) >= threshold → Purchase highest utility option
4. Probabilistic element added for realism (logit choice model)

#### 5.2.3 Used Car Market Competition

Used cars directly compete with new vehicles:

```
┌─────────────────────────────────────────────────────────────────┐
│                     MARKET RESOLUTION                           │
│                                                                 │
│   Consumer Bucket wants to buy                                  │
│           │                                                     │
│           ▼                                                     │
│   ┌───────────────────────────────────────────┐                │
│   │  Evaluate ALL options:                    │                │
│   │    • New vehicles in price range          │                │
│   │    • Used vehicles (1-15 years old)       │                │
│   │    • "Walk away" option (utility = 0)     │                │
│   └───────────────────────────────────────────┘                │
│           │                                                     │
│           ▼                                                     │
│   If USED CAR wins → New car loses sale                        │
│   If NEW CAR wins → Used car inventory unchanged               │
│   If WALK wins → Both lose, pent-up demand increases           │
│                                                                 │
└─────────────────────────────────────────────────────────────────┘
```

**Used Car Depreciation Model:**
- Year 1: 20-25% depreciation
- Years 2-5: 10-15% annual
- Years 6-10: 5-8% annual
- Years 11+: 3-5% annual (floor value)

Reliability reputation affects depreciation curves significantly.

### 5.3 Competition (AI System)

#### 5.3.1 CEO Personality Matrix

Every AI CEO has four core traits (0-100 scale):

| Trait | Low Score | High Score |
|-------|-----------|------------|
| **Aggression** | Price maintains, slow expansion | Price wars, rapid growth |
| **Innovation** | Proven tech, reliability focus | Bleeding edge, first-mover |
| **Risk Tolerance** | Conservative debt, safe bets | Leveraged growth, big gambles |
| **Loyalty** | Quick to fire, restructure | Stable teams, long tenures |

**Decision Examples:**
- High Aggression + High Risk → Launch ambitious new model, undercut competitors
- Low Innovation + High Loyalty → Reliable iterative updates, stable workforce
- High Innovation + Low Loyalty → Constant R&D pivots, high executive turnover

#### 5.3.2 Organizational Inertia

Large companies react slower than small ones:

```python
reaction_time = base_time × (1 + log(employee_count / 1000)) × bureaucracy_level
decision_quality = base_quality × (competence / (1 + bureaucracy_level))
```

**Effects:**
- Large companies take 2-3x longer to pivot strategy
- New model development takes longer at scale
- But: economies of scale reduce unit costs

#### 5.3.3 CEO Lifecycle

AI CEOs have realistic careers:

- **Tenure:** 5-15 years average
- **Retirement:** Age 60-70, probabilistic
- **Firing:** Poor performance triggers board review
- **Succession:** Internal promotion or external hire (changes company strategy)

**CEO Transition Effects:**
- New CEO imposes their personality on company
- 6-12 month "adjustment period" with reduced effectiveness
- Strategic direction shifts based on new personality

### 5.4 Player Management (CEO Role)

#### 5.4.1 Delegation System

Players can manage at multiple levels of abstraction:

**Level 1: Philosophy (Broadest)**
```
"Quality over Quantity"
"Innovation Leader"
"Cost Leadership"
"Regional Focus: Asia"
```

**Level 2: KPI Directives**
```
{
    "metric": "MARKET_SHARE_ASIA",
    "target": 0.15,
    "deadline": "1965-Q4",
    "priority": "HIGH"
}
```

**Level 3: Natural Language Directives**
```
"Build a cheap sports car for the Asian market under $15,000"
"Cut production costs by 10% without affecting quality"
"Develop an electric vehicle platform within 5 years"
```

**Level 4: Manual Control**
Direct specification of all vehicle parameters, production numbers, pricing, etc.

#### 5.4.2 AI Executive Behavior

Hired executives interpret and execute directives:

**Execution Quality Factors:**
- Competence score
- Morale level
- Loyalty to company
- Clarity of directive
- Available resources

**Loyalty/Morale System:**
- Low morale → Slower execution, more errors
- Low loyalty → May leave for competitors, leak secrets
- Very low morale → Sabotage (subtle quality issues)

**Morale Modifiers:**
- Salary vs. market rate
- Success of recent projects
- Company performance
- Relationship with CEO (player decisions)
- Industry conditions

### 5.5 Engineering & Technology

#### 5.5.1 Technology Tree Structure

```
                        ┌─────────────────────┐
                        │   BASIC RESEARCH    │
                        └──────────┬──────────┘
                                   │
            ┌──────────────────────┼──────────────────────┐
            │                      │                      │
            ▼                      ▼                      ▼
    ┌───────────────┐     ┌───────────────┐     ┌───────────────┐
    │   POWERTRAIN  │     │    CHASSIS    │     │  ELECTRONICS  │
    └───────┬───────┘     └───────┬───────┘     └───────┬───────┘
            │                     │                     │
    ┌───────┴───────┐     ┌───────┴───────┐     ┌───────┴───────┐
    │               │     │               │     │               │
    ▼               ▼     ▼               ▼     ▼               ▼
 ┌──────┐       ┌──────┐ ┌──────┐     ┌──────┐ ┌──────┐     ┌──────┐
 │Engine│       │Trans │ │Susp. │     │Safety│ │Info- │     │Driver│
 │ Tech │       │ Tech │ │ Tech │     │ Tech │ │tain- │     │Assist│
 └──┬───┘       └──┬───┘ └──┬───┘     └──┬───┘ │ment  │     │ Tech │
    │              │        │            │     └──────┘     └──────┘
    ▼              ▼        ▼            ▼
 ┌──────┐     ┌──────┐  ┌──────┐    ┌──────┐
 │Turbo │     │ DCT  │  │Active│    │ ABS  │
 │charge│     │      │  │Susp. │    │ ESC  │
 └──────┘     └──────┘  └──────┘    └──────┘
    │              │
    ▼              ▼
 ┌──────┐     ┌──────┐
 │Hybrid│     │ CVT  │
 │System│     │      │
 └──────┘     └──────┘
    │
    ▼
 ┌──────┐
 │Full  │
 │ EV   │
 └──────┘
```

#### 5.5.2 Research Probability Model

R&D investment doesn't guarantee success:

```python
breakthrough_probability = base_prob × research_intensity × random_factor

where:
    research_intensity = monthly_investment / optimal_investment
    random_factor = random(0.5, 1.5)  # Genius moments or dead ends
```

**Investment Effects:**
- Below optimal: Low probability, extended timeline
- At optimal: Standard probability, normal timeline
- Above optimal: Diminishing returns, wastes money
- Way above optimal: Slight probability boost, major cost waste

#### 5.5.3 Car Design System

Three input methods, all producing the same underlying data structure:

**Method A: Natural Language Directive**
```
Input: "Build a compact SUV for families, prioritizing safety and fuel economy"

Parsed to:
{
    "body_style": "SUV",
    "segment": "COMPACT",
    "priorities": ["SAFETY", "EFFICIENCY"],
    "target_market": "FAMILIES"
}
```

**Method B: Slider Interface**
```
Performance   [====------] 40%
Comfort       [======----] 60%
Safety        [========--] 80%
Efficiency    [=======---] 70%
Cost Target   [$25,000 - $35,000]
```

**Method C: Detailed Engineering**
```
Platform: Compact FWD Platform v2
Engine: 2.0L I4 Turbo (Part #ENG-2024-001)
Transmission: 6-Speed Auto (Part #TRN-2024-003)
Suspension: MacPherson Front / Torsion Rear
...full specification...
```

#### 5.5.4 Reverse Engineering

Players can acquire competitor vehicles and reverse-engineer technology:

**Process:**
1. Purchase competitor vehicle (cost: MSRP + acquisition)
2. Assign engineering team (takes 3-6 months)
3. Learn technologies used (partial knowledge gain)
4. Can apply learnings to own designs (with penalty for imperfect understanding)

**Limitations:**
- Cannot perfectly replicate proprietary tech
- Learned tech has 70-90% effectiveness of original
- Ethical penalty if discovered (brand reputation hit)

#### 5.5.5 Engineering Core: Component-Based Architecture

**Philosophy: Hardcore Physics-Driven Design**

The engineering system is built on physical constraints and derived calculations, NOT random numbers. Every performance metric flows from fundamental parameters.

#### 5.5.5.1 Procedural Vehicle Body System (v1.4)

**Paradigm Shift: Continuous Parameters vs. Preset Templates**

Instead of selecting from pre-defined car body templates (e.g., "Compact Sedan", "Mid-Size SUV"), the game now supports **continuous geometric parameters**. This allows for truly procedural vehicle design where every millimeter matters.

**Core Concept:**
- **Input**: Continuous physical dimensions (wheelbase, overhangs, heights, widths)
- **Output**: Automatically calculated weight, cost, space constraints, aerodynamics
- **Constraint**: These parameters define the "White Body" (Body-In-White / BIW)

**Material Database:**

```python
MATERIALS = {
    "STEEL": {
        density: 7850 kg/m³,
        cost_per_m²: $25,
        strength_multiplier: 1.0,
        tech_level_required: 1
    },
    "ALUMINUM": {
        density: 2700 kg/m³ (65% lighter),
        cost_per_m²: $75 (3x more expensive),
        strength_multiplier: 0.85 (needs more thickness),
        tech_level_required: 4
    },
    "CARBON": {
        density: 1600 kg/m³ (80% lighter),
        cost_per_m²: $450 (18x more expensive),
        strength_multiplier: 1.5 (stronger, can be thinner),
        tech_level_required: 8
    },
    "HSS": {  // High Strength Steel
        density: 7850 kg/m³,
        cost_per_m²: $40,
        strength_multiplier: 1.3,
        tech_level_required: 6
    }
}
```

**Physics Calculations:**

1. **Surface Area Calculation:**
   ```
   S ≈ 2 × (L×W + L×H + W×H) × 1.12
   // 1.12 = curvature factor (real cars have ~12% more surface area than rectangular box)
   ```

2. **BIW Weight Calculation:**
   ```
   Weight = Surface Area × Effective Thickness × Density × Structural Factor × Tech Optimization
   
   Where:
   - Effective Thickness = Base Thickness / Strength Multiplier
   - Structural Factor = 1.3 (accounts for pillars, beams, reinforcements)
   - Tech Optimization = 1.0 - (tech_level - 1) × 0.022  // Tech 10 = 20% weight saving
   ```

3. **BIW Cost Calculation:**
   ```
   Cost = Material Cost + Tooling Cost + Assembly Cost
   
   Material Cost = Surface Area × Material Price per m²
   Tooling Cost = Base ($5000) + Surface Area × Welding Rate ($30/m²)
   Assembly Cost = (20 + Surface Area × 2.0) hours × $50/hour
   ```

4. **Engine Bay Volume (CRITICAL CONSTRAINT!):**
   ```
   // For FF/FR (Front Engine):
   Bay Length = Front Overhang + 10% Wheelbase
   Bay Width = Body Width × 0.85  // Leave space for wheel arches
   Bay Height = Bonnet Height × 0.8  // Leave clearance for hood
   
   // For MR (Mid Engine):
   Bay Length = Wheelbase × 0.25
   Bay Width = Body Width × 0.7
   Bay Height = Roof Height × 0.6
   
   // For RR (Rear Engine):
   Bay Length = Rear Overhang + 5% Wheelbase
   Bay Width = Body Width × 0.8
   Bay Height = Roof Height × 0.5
   ```

5. **Cabin Volume (Affects Comfort):**
   ```
   Cabin Volume = (Wheelbase × 0.7) × (Width × 0.9) × (Roof Height × 0.6)
   // 70% of wheelbase for passengers, 90% width (minus door panels), 60% height (minus floor/ceiling)
   ```

6. **Drag Coefficient Calculation:**
   ```
   Base Cd = {
       SEDAN: 0.35,
       COUPE: 0.32,
       HATCHBACK: 0.36,
       SUV: 0.42,
       TRUCK: 0.48
   }
   
   Ratio Penalty = (if length/width < 2.5 or > 3.5): +0.02-0.03
   Height Penalty = (roof_height - 1300mm) / 1000 × 0.02
   Tech Improvement = (tech_level - 1) × 0.006  // Tech 10 = -0.05 Cd
   
   Final Cd = Base Cd + Penalties - Tech Improvement
   ```

**Engine Fit Validation:**

The system now validates whether a chosen engine can physically fit into the engine bay:

```python
def validate_engine_fit(engine_dimensions, body_stats, layout):
    # 1. Dimensional Check (5% clearance required)
    if engine.length_mm × 1.05 > bay_length_mm:
        return INCOMPATIBLE, "Engine too long"
    
    if engine.width_mm × 1.05 > bay_width_mm:
        return INCOMPATIBLE, "Engine too wide"
    
    if engine.height_mm × 1.05 > bay_height_mm:
        return INCOMPATIBLE, "Engine too tall"
    
    # 2. Cooling Capacity Check
    required_cooling_kw = engine.thermal_load × 2.0
    if required_cooling_kw > chassis.max_cooling_capacity_kw:
        return INCOMPATIBLE, "Insufficient cooling capacity"
    
    # 3. Tightness Warnings
    if any(dimension_usage > 95%):
        return WARNING, "Very tight fit, difficult maintenance"
    
    return COMPATIBLE
```

**Database Integration:**

The `Chassis` model now stores procedural parameters:

```sql
CREATE TABLE chassis (
    ...
    -- Geometric Parameters (NEW)
    wheelbase_mm INTEGER,
    track_front_mm INTEGER,
    track_rear_mm INTEGER,
    
    -- Engine Bay Constraints (CALCULATED)
    engine_bay_length_mm REAL,
    engine_bay_width_mm REAL,
    engine_bay_height_mm REAL,
    max_cooling_capacity_kw REAL,
    
    -- Material & Weight (CALCULATED)
    material VARCHAR(20),  -- STEEL/ALUMINUM/CARBON/HSS
    weight_kg REAL,        -- Calculated from surface area & material
    ...
);
```

**Usage Example:**

```python
from backend.services.engineering_service import EngineeringService
from backend.core.engineering.chassis_math import BodyDimensions

# Create a compact sedan with aluminum body
chassis, body_stats = EngineeringService.create_procedural_body_chassis(
    db=db,
    game_id=1,
    company_id=1,
    name="Compact Platform Alpha",
    code="PLAT_COMPACT_001",
    # Geometry
    wheelbase_mm=2650,
    track_width_mm=1540,
    front_overhang_mm=850,
    rear_overhang_mm=900,
    bonnet_height_mm=700,
    roof_height_mm=1450,
    width_mm=1780,
    # Material
    panel_material="ALUMINUM",
    body_style="SEDAN",
    layout="FF",
    tech_level=6
)

# Results:
# - BIW Weight: ~220 kg (vs ~330 kg for steel)
# - BIW Cost: ~$12,000 (vs ~$8,000 for steel)
# - Engine Bay Volume: 185 liters
# - Drag Coefficient: 0.33
# - Cabin Volume: 2,450 liters

# Validate engine fit
engine = db.query(Engine).filter_by(code="ENG_2.0T_I4").first()
is_compatible, message = EngineeringService.validate_engine_fits_procedural_body(
    engine, chassis
)
# Result: True, "✓ 完全兼容"
```

**Trade-offs Enforced:**

- **Lightweight Materials**: Lower weight → Better performance & fuel economy, BUT much higher cost
- **Large Engine Bay**: Can fit bigger engines → Better performance, BUT longer front overhang → Worse handling
- **Low Roof Height**: Lower drag → Better top speed & fuel economy, BUT less cabin volume → Lower comfort
- **Wide Body**: More cabin space → Better comfort, BUT higher frontal area → Higher drag → Lower top speed

**Implementation Modules:**

- `backend/core/engineering/chassis_math.py`: Physics calculator (NEW)
- `backend/services/engineering_service.py`: Integration with existing engine/chassis systems (UPDATED)
- `backend/models/engineering.py`: Database models (EXTENDED)

---

#### Original 5.5.5 Content (Engine/Chassis System)

**Component Hierarchy:**
```
CarTrim (Final Product)
    ├── Engine (Power Unit)
    │   ├── Physical Parameters (Input)
    │   │   ├── Bore × Stroke × Cylinders → Displacement
    │   │   ├── Configuration (Inline/V/Boxer) → Dimensions
    │   │   ├── Compression Ratio → Efficiency
    │   │   ├── Induction (NA/Turbo) → Power Multiplier
    │   │   └── Material → Weight & Reliability
    │   └── Derived Attributes (Calculated)
    │       ├── Horsepower (from displacement, RPM, VE, BMEP)
    │       ├── Torque (from displacement, BMEP)
    │       ├── Dimensions L×W×H (from config & cylinders)
    │       ├── Weight (from displacement & material)
    │       ├── Thermal Load (from specific output & boost)
    │       ├── Reliability (from thermal load & stress)
    │       └── Fuel Efficiency (from BSFC & compression)
    │
    ├── Chassis (Platform)
    │   ├── Physical Constraints
    │   │   ├── Engine Bay Dimensions (L×W×H limits)
    │   │   ├── Cooling Capacity (max thermal load)
    │   │   ├── Wheelbase & Track Width
    │   │   └── Material (Steel/Aluminum/Carbon)
    │   └── Structural Properties
    │       ├── Rigidity Rating → Handling
    │       ├── Crash Test Rating → Safety
    │       └── Weight (from material & size)
    │
    └── Body (Aerodynamics & Packaging)
        ├── Body Style (Sedan/SUV/Coupe)
        ├── Drag Coefficient → Top Speed & Fuel Economy
        ├── Frontal Area → Air Resistance
        └── Weight → Total Mass
```

**Key Physics Formulas Implemented:**

1. **Displacement Calculation:**
   ```
   V = π × (bore/2)² × stroke × cylinders
   ```

2. **Horsepower Derivation:**
   ```
   HP = (BMEP × Displacement × RPM × VE × Tech_Factor) / 120 × 1.341
   where:
     BMEP = Brake Mean Effective Pressure (bar)
     VE = Volumetric Efficiency (affected by valvetrain & induction)
   ```

3. **Engine Dimensions:**
   - **Inline**: Length = stroke × 1.5 × cylinders, narrow width
   - **V-Configuration**: Length = stroke × 1.5 × (cylinders/2), width × 2.2
   - **Boxer**: Shortest length, widest width × 3.0, lowest height × 0.6
   - **Turbo**: +15% length, +25% height

4. **Thermal Load:**
   ```
   Thermal = (HP/Displacement) × 0.3 + Boost × 8.0 + (CR - 8.0) × 2.0
   ```

5. **Reliability Score:**
   ```
   Reliability = Base(Tech_Level) - Output_Penalty - Thermal_Penalty + Material_Bonus
   where:
     Output_Penalty increases sharply above 80 HP/L (NA) or 120 HP/L (Turbo)
     Thermal_Penalty increases above 30 thermal load
   ```

6. **0-100 km/h Acceleration:**
   ```
   t = (140 / Power_to_Weight) × Drivetrain_Factor × Grip_Factor / 1000
   ```

7. **Top Speed:**
   ```
   v_max = (2 × Power / (ρ × Cd × A))^(1/3)
   where:
     ρ = air density (1.225 kg/m³)
     Cd = drag coefficient
     A = frontal area (m²)
   ```

**Compatibility System:**

Before a CarTrim can be created, the system checks:

1. **Dimensional Fit:**
   - Engine Length ≤ Chassis Engine Bay Length (with 5% clearance)
   - Engine Width ≤ Chassis Engine Bay Width
   - Engine Height ≤ Chassis Engine Bay Height

2. **Thermal Compatibility:**
   - Engine Thermal Load × 2 ≤ Chassis Cooling Capacity (kW)

3. **Warnings:**
   - If cooling capacity > 90% utilized → "Warning: Cooling near limit"
   - If dimensions tight → "Warning: Tight fit, difficult maintenance"

**Trade-offs Enforced:**

- **High Power → High Heat → Low Reliability** (unless high tech level)
- **Large Displacement → Heavy → Slow Acceleration** (unless powerful)
- **Turbocharging → More Power BUT more heat, complexity, cost**
- **Aluminum Block → Lighter BUT more expensive**
- **High Compression → Better Efficiency BUT requires premium fuel**

**Database Schema (New Tables):**

```sql
-- Replaces generic 'parts' table for engines
CREATE TABLE engines (
    id INTEGER PRIMARY KEY,
    game_id INTEGER REFERENCES game_state(id),
    company_id INTEGER REFERENCES companies(id),
    
    -- Input Parameters
    bore_mm REAL NOT NULL,
    stroke_mm REAL NOT NULL,
    cylinder_count INTEGER NOT NULL,
    configuration TEXT NOT NULL,  -- INLINE/V/BOXER/VR/W
    compression_ratio REAL NOT NULL,
    induction_type TEXT NOT NULL,  -- NA/TURBO/SUPERCHARGED/TWINTURBO
    boost_pressure_bar REAL DEFAULT 0,
    material TEXT NOT NULL,  -- CAST_IRON/ALUMINUM/MAGNESIUM
    valvetrain TEXT NOT NULL,  -- OHV/SOHC/DOHC/VARIABLE
    fuel_type TEXT NOT NULL,  -- GASOLINE/DIESEL/E85/LPG
    tech_level INTEGER NOT NULL,
    
    -- Calculated Outputs (DO NOT SET MANUALLY)
    displacement_cc INTEGER NOT NULL,
    max_horsepower INTEGER NOT NULL,
    max_torque_nm INTEGER NOT NULL,
    redline_rpm INTEGER NOT NULL,
    weight_kg REAL NOT NULL,
    length_mm REAL NOT NULL,
    width_mm REAL NOT NULL,
    height_mm REAL NOT NULL,
    thermal_load REAL NOT NULL,
    specific_output REAL NOT NULL,
    reliability_base_score REAL NOT NULL,
    fuel_efficiency_rating REAL NOT NULL,
    bsfc_g_kwh REAL NOT NULL,
    manufacturing_cost REAL NOT NULL,
    
    -- Metadata
    name TEXT NOT NULL,
    code TEXT UNIQUE NOT NULL,
    development_cost REAL DEFAULT 0,
    is_proprietary BOOLEAN DEFAULT FALSE,
    is_available BOOLEAN DEFAULT TRUE
);

CREATE TABLE chassis (
    id INTEGER PRIMARY KEY,
    game_id INTEGER REFERENCES game_state(id),
    company_id INTEGER REFERENCES companies(id),
    
    -- Dimensions & Layout
    wheelbase_mm INTEGER NOT NULL,
    track_front_mm INTEGER NOT NULL,
    track_rear_mm INTEGER NOT NULL,
    layout TEXT NOT NULL,  -- FF/FR/MR/RR/AWD
    
    -- Engine Bay Constraints (CRITICAL)
    engine_bay_length_mm REAL NOT NULL,
    engine_bay_width_mm REAL NOT NULL,
    engine_bay_height_mm REAL NOT NULL,
    max_cooling_capacity_kw REAL NOT NULL,
    
    -- Structure
    material TEXT NOT NULL,  -- STEEL/ALUMINUM/CARBON
    rigidity_rating REAL NOT NULL,
    weight_kg REAL NOT NULL,
    crash_test_rating REAL NOT NULL,
    tech_level INTEGER NOT NULL,
    
    -- Costs
    manufacturing_cost REAL NOT NULL,
    development_cost REAL DEFAULT 0,
    
    -- Metadata
    name TEXT NOT NULL,
    code TEXT UNIQUE NOT NULL,
    is_available BOOLEAN DEFAULT TRUE
);

CREATE TABLE car_trims (
    id INTEGER PRIMARY KEY,
    game_id INTEGER REFERENCES game_state(id),
    company_id INTEGER REFERENCES companies(id),
    
    -- Component References
    engine_id INTEGER REFERENCES engines(id) NOT NULL,
    chassis_id INTEGER REFERENCES chassis(id) NOT NULL,
    
    -- Body
    body_style TEXT NOT NULL,  -- SEDAN/COUPE/SUV/WAGON/HATCHBACK/CONVERTIBLE/TRUCK
    body_weight_kg REAL NOT NULL,
    drag_coefficient REAL NOT NULL,
    frontal_area_sqm REAL NOT NULL,
    seating_capacity INTEGER NOT NULL,
    cargo_volume_liters INTEGER NOT NULL,
    
    -- Calculated Performance (from physics engine)
    total_weight_kg REAL NOT NULL,
    power_to_weight_ratio REAL NOT NULL,
    zero_to_hundred_kph_sec REAL NOT NULL,
    top_speed_kph REAL NOT NULL,
    quarter_mile_sec REAL NOT NULL,
    braking_100_0_meters REAL NOT NULL,
    lateral_g_force REAL NOT NULL,
    fuel_economy_l_100km REAL NOT NULL,
    final_reliability_score REAL NOT NULL,
    
    -- Market
    segment TEXT NOT NULL,
    manufacturing_cost REAL NOT NULL,
    msrp REAL NOT NULL,
    
    -- Compatibility Check Results
    compatibility_status TEXT NOT NULL,  -- COMPATIBLE/INCOMPATIBLE/WARNING
    compatibility_notes TEXT,
    
    -- Production
    is_in_production BOOLEAN DEFAULT FALSE,
    
    -- Metadata
    name TEXT NOT NULL,
    model_name TEXT NOT NULL,
    trim_code TEXT UNIQUE NOT NULL
);
```

**Implementation Modules:**

- `backend/models/engineering.py`: SQLAlchemy ORM models
- `backend/core/engineering/physics.py`: EngineeringCalculator class with all formulas
- `backend/services/engineering_service.py`: High-level API for creating engines, chassis, trims

**Example Usage:**

```python
from backend.services.engineering_service import EngineeringService

# Create a 2.0L Turbo I4
engine = EngineeringService.create_engine_with_calculations(
    db=db,
    game_id=1,
    company_id=1,
    name="EcoBoost 2.0T",
    code="ENG_2024_001",
    bore_mm=87.5,
    stroke_mm=83.1,
    cylinder_count=4,
    configuration="INLINE",
    compression_ratio=9.5,
    induction_type="TURBO",
    boost_pressure_bar=1.2,
    material="ALUMINUM",
    valvetrain="DOHC",
    fuel_type="GASOLINE",
    tech_level=7
)
# Result: 240 HP, 350 Nm, 150 kg, reliability 78/100

# Create a compact FWD chassis
chassis = EngineeringService.create_chassis(
    db=db,
    game_id=1,
    company_id=1,
    name="C-Platform",
    code="CHS_2024_001",
    wheelbase_mm=2700,
    layout="FF",
    engine_bay_length_mm=800,
    engine_bay_width_mm=700,
    engine_bay_height_mm=600,
    max_cooling_capacity_kw=100,
    material="STEEL",
    tech_level=5
)

# Check compatibility
is_compatible, message, details = EngineeringService.check_compatibility(
    db=db,
    engine_id=engine.id,
    chassis_id=chassis.id
)
# Result: True, "完全兼容"

# Assemble final car
car_trim, msg = EngineeringService.create_car_trim(
    db=db,
    game_id=1,
    company_id=1,
    name="Sport",
    model_name="Fusion",
    trim_code="FUSION_SPORT_2024",
    engine_id=engine.id,
    chassis_id=chassis.id,
    body_style="SEDAN",
    body_weight_kg=400,
    drag_coefficient=0.28,
    segment="MIDSIZE",
    msrp=32000
)
# Result: 0-100 in 6.8s, 230 km/h top speed, 7.2 L/100km
```

---

### 5.6 Production & Supply Chain System

#### 5.6.1 System Architecture

**Core Philosophy:**
- **Distributed Production:** Separate Component Factories (Engines, Transmissions) from Final Assembly Plants
- **Simplified Logistics:** Transport between owned factories is automated (abstracted as cost + time delay)
- **Strategic Sourcing:** Raw material prices fluctuate based on global/regional economic conditions
- **B2B Marketplace:** Players can buy/sell components from/to AI competitors

**Production Flow:**

```
┌─────────────────────────────────────────────────────────────────┐
│                     PRODUCTION PIPELINE                         │
└─────────────────────────────────────────────────────────────────┘

  ┌──────────────┐
  │ Raw Material │  ← Steel, Aluminum, Plastic, Electronics
  │   Markets    │  ← Prices fluctuate weekly/monthly
  └──────┬───────┘
         │ Purchase
         ▼
  ┌──────────────────┐
  │  COMPONENT       │  Factory Type: COMPONENT
  │  FACTORY         │  Produces: Engines, Chassis, Transmissions
  │                  │  Inputs: Raw Materials
  │  Level 1-10      │  Outputs: Finished Components
  └──────┬───────────┘
         │ Transfer (Inter-factory Logistics)
         │ OR Sell to B2B Market
         ▼
  ┌──────────────────┐
  │  ASSEMBLY        │  Factory Type: ASSEMBLY
  │  PLANT           │  Produces: Complete Vehicles
  │                  │  Inputs: Components + Body Materials
  │  Level 1-10      │  Outputs: Completed Cars (ready for sale)
  └──────┬───────────┘
         │
         ▼
  ┌──────────────────┐
  │  Dealer Network  │  (Future: Distribution system)
  │  & Direct Sales  │
  └──────────────────┘
```

#### 5.6.2 Factory Model

**Database Schema:**

```sql
CREATE TABLE factories (
    id INTEGER PRIMARY KEY,
    game_id INTEGER REFERENCES game_state(id),
    company_id INTEGER,  -- Owner company
    name TEXT NOT NULL,
    
    -- Type & Capacity
    factory_type TEXT NOT NULL,  -- COMPONENT / ASSEMBLY
    level INTEGER NOT NULL,  -- 1-10, affects efficiency & tech capability
    capacity_units_per_month INTEGER NOT NULL,
    current_utilization_rate REAL,  -- 0.0 - 1.0
    
    -- Location (affects logistics & labor costs)
    region_id INTEGER REFERENCES regions(id),
    
    -- Economics
    efficiency_score REAL NOT NULL,  -- 0-100, affects actual output
    labor_cost_per_unit REAL NOT NULL,
    overhead_cost_per_month REAL NOT NULL,
    
    -- Technology
    tech_level INTEGER NOT NULL,  -- Cannot produce components > this tech level
    
    -- Status
    is_operational BOOLEAN DEFAULT TRUE,
    construction_completed_turn INTEGER
);
```

**Factory Attributes:**

| Attribute | Impact |
|-----------|--------|
| **Level (1-10)** | Higher = Better efficiency (-2% cost/level), Higher tech cap |
| **Efficiency Score (0-100)** | Actual capacity = nominal × (efficiency/100) |
| **Region** | Affects labor costs, logistics costs, and material availability |
| **Tech Level** | Cannot produce Engine/Chassis with tech_level > factory tech_level |

**Capacity Calculation:**

```python
effective_monthly_capacity = (
    capacity_units_per_month 
    × (efficiency_score / 100.0)
    × (1.0 if is_operational else 0.0)
)
```

#### 5.6.3 Material Market System

Raw materials have **dynamic pricing** influenced by:

1. **Global Supply/Demand:** Economic cycles affect steel/aluminum demand across all industries
2. **Regional Variations:** Shipping costs create price differentials
3. **Random Shocks:** Mining strikes, tariffs, natural disasters

**Material Types:**
- **STEEL:** High-volume, low-volatility (±5-10%)
- **ALUMINUM:** Medium-volume, medium-volatility (±10-20%)
- **PLASTIC:** Derived from oil prices, high-volatility (±15-30%)
- **ELECTRONICS:** Tech-dependent, moderate-volatility (±8-15%)
- **RUBBER:** Commodity-linked, moderate-volatility (±10-18%)
- **GLASS:** Stable, low-volatility (±5%)

**Database Schema:**

```sql
CREATE TABLE material_market (
    id INTEGER PRIMARY KEY,
    game_id INTEGER REFERENCES game_state(id),
    region_id INTEGER REFERENCES regions(id),  -- NULL = global price
    
    material_type TEXT NOT NULL,  -- STEEL / ALUMINUM / PLASTIC / etc.
    current_price_per_kg REAL NOT NULL,
    historical_avg_price REAL NOT NULL,  -- Rolling 12-month average
    price_volatility REAL NOT NULL,  -- 0.0-1.0 volatility index
    
    supply_level REAL NOT NULL,  -- 0.0-2.0, 1.0 = normal
    last_update_turn INTEGER NOT NULL
);
```

#### 5.6.4 Inventory Management

Each factory maintains **three inventory categories**:

```sql
CREATE TABLE inventories (
    id INTEGER PRIMARY KEY,
    game_id INTEGER REFERENCES game_state(id),
    factory_id INTEGER REFERENCES factories(id),
    
    -- Stored as JSON for flexibility
    raw_materials JSON,  -- {"STEEL": 50000, "ALUMINUM": 10000, ...} (kg)
    finished_components JSON,  -- {"engine_123": 150, "chassis_456": 80, ...} (units)
    completed_cars JSON,  -- {"trim_101": 500, "trim_102": 300, ...} (vehicles)
    
    total_inventory_value REAL,  -- Cached for financial reporting
    last_valuation_turn INTEGER
);
```

**Inventory Valuation:**
- **Raw Materials:** Current market price × quantity
- **Finished Components:** Manufacturing cost × quantity
- **Completed Cars:** Full production cost × quantity

**Carrying Costs:**
- ~2-5% annual inventory value (storage, insurance, obsolescence)
- High inventory = Lower JIT risk but higher capital tie-up
- Low inventory = Capital efficient but supply chain risk

#### 5.6.5 Production Processes

**A. Component Production (Engines/Chassis):**

```python
def produce_component(factory, blueprint, quantity):
    # 1. Validate factory type
    assert factory.factory_type == "COMPONENT"
    
    # 2. Check technology capability
    if factory.tech_level < blueprint.tech_level:
        raise InsufficientTechError()
    
    # 3. Calculate material requirements
    materials_needed = calculate_material_requirements(blueprint, quantity)
    # Example: Engine(150kg Aluminum, 50kg Steel, 2kg Electronics) × 500 units
    
    # 4. Check inventory
    inventory = get_factory_inventory(factory)
    for material, amount in materials_needed.items():
        if inventory.get_material(material) < amount:
            raise InsufficientMaterialsError(material)
    
    # 5. Deduct materials
    for material, amount in materials_needed.items():
        inventory.deduct_material(material, amount)
    
    # 6. Add finished components
    inventory.add_component(blueprint.id, quantity)
    
    # 7. Calculate costs
    labor_cost = factory.labor_cost_per_unit × quantity
    efficiency_factor = 1.0 - (factory.level - 1) * 0.02  # Better efficiency at higher levels
    total_cost = (blueprint.manufacturing_cost * quantity + labor_cost) * efficiency_factor
    
    # 8. Update utilization
    factory.current_utilization_rate = quantity / factory.get_effective_capacity()
    
    return total_cost
```

**B. Vehicle Assembly:**

```python
def assemble_car(assembly_factory, car_trim, quantity, component_source_factory=None):
    # 1. Validate factory type
    assert assembly_factory.factory_type == "ASSEMBLY"
    
    # 2. Check component availability
    if component_source_factory:
        # Inter-factory transfer
        component_inventory = get_factory_inventory(component_source_factory)
        logistics_cost = calculate_logistics_cost(
            component_source_factory, 
            assembly_factory, 
            quantity
        )
    else:
        # Use local inventory OR purchase from B2B market
        component_inventory = get_factory_inventory(assembly_factory)
        logistics_cost = 0
    
    # 3. Check component stock
    required_components = {
        "engine": car_trim.engine_id,
        "chassis": car_trim.chassis_id,
        # Additional components in future versions
    }
    
    for comp_type, comp_id in required_components.items():
        if component_inventory.get_component(comp_id) < quantity:
            raise InsufficientComponentsError(comp_type, comp_id)
    
    # 4. Check body materials (steel, glass, plastics for body assembly)
    body_materials_needed = calculate_body_materials(car_trim, quantity)
    assembly_inventory = get_factory_inventory(assembly_factory)
    
    for material, amount in body_materials_needed.items():
        if assembly_inventory.get_material(material) < amount:
            raise InsufficientMaterialsError(material)
    
    # 5. Deduct components and materials
    for comp_type, comp_id in required_components.items():
        component_inventory.deduct_component(comp_id, quantity)
    
    for material, amount in body_materials_needed.items():
        assembly_inventory.deduct_material(material, amount)
    
    # 6. Add completed cars
    assembly_inventory.add_car(car_trim.id, quantity)
    
    # 7. Calculate total cost
    labor_cost = assembly_factory.labor_cost_per_unit × quantity
    efficiency_factor = 1.0 - (assembly_factory.level - 1) * 0.02
    total_cost = (
        (car_trim.manufacturing_cost * quantity + labor_cost) * efficiency_factor
        + logistics_cost
    )
    
    return total_cost
```

#### 5.6.6 Automated Logistics

**Simplification for MVP:**
- No manual route planning required
- Inter-factory transfers are **instant** (abstracted as cost + time delay)
- Costs scale with distance and quantity

**Cost Model:**

```python
def auto_logistics(source_factory, dest_factory, quantity):
    """
    Calculate automated logistics cost.
    
    MVP Simplification:
    - Same region: Low cost ($10/unit)
    - Different region: Fixed base cost + per-unit cost
    """
    if source_factory.region_id == dest_factory.region_id:
        # Same region: Simple trucking
        return 10.0 * quantity
    else:
        # Cross-region: Rail/ship + trucking
        base_cost = 5000.0  # Setup cost
        per_unit_cost = 50.0  # Shipping per unit
        return base_cost + per_unit_cost * quantity
```

**Future Enhancements (Post-MVP):**
- Actual time delays (components arrive 1-2 turns later)
- Regional infrastructure quality affects costs
- Shipping disruptions (strikes, weather)
- Optimization mini-game (route selection)

#### 5.6.7 B2B Component Marketplace

**Concept:**
Players and AI companies can **trade components** (Engines, Chassis, Transmissions) on a B2B marketplace.

**Use Cases:**
1. **Specialization:** Company A makes great engines, sells to Company B
2. **Temporary Shortages:** Player's engine factory is at capacity, buy from competitor
3. **Technology Access:** AI company sells outdated engine designs cheaply
4. **Strategic Play:** Player undercuts market to gain market share

**Database Schema:**

```sql
CREATE TABLE b2b_component_listings (
    id INTEGER PRIMARY KEY,
    game_id INTEGER REFERENCES game_state(id),
    seller_company_id INTEGER,
    
    component_type TEXT NOT NULL,  -- ENGINE / CHASSIS / TRANSMISSION
    component_id INTEGER NOT NULL,  -- References engines.id, chassis.id, etc.
    
    unit_price REAL NOT NULL,
    min_order_quantity INTEGER NOT NULL,  -- MOQ (Minimum Order Quantity)
    available_quantity INTEGER,  -- NULL = unlimited
    
    is_active BOOLEAN DEFAULT TRUE,
    is_exclusive BOOLEAN DEFAULT FALSE,  -- TRUE = only specific buyer
    exclusive_buyer_company_id INTEGER,
    
    lead_time_weeks INTEGER DEFAULT 4,  -- Delivery time
    
    total_sold_quantity INTEGER DEFAULT 0,
    last_sale_turn INTEGER
);

CREATE TABLE b2b_transactions (
    id INTEGER PRIMARY KEY,
    game_id INTEGER REFERENCES game_state(id),
    listing_id INTEGER REFERENCES b2b_component_listings(id),
    
    buyer_company_id INTEGER NOT NULL,
    seller_company_id INTEGER NOT NULL,
    
    component_type TEXT NOT NULL,
    component_id INTEGER NOT NULL,
    quantity INTEGER NOT NULL,
    
    unit_price REAL NOT NULL,
    total_amount REAL NOT NULL,
    
    delivery_factory_id INTEGER REFERENCES factories(id),
    transaction_turn INTEGER NOT NULL,
    expected_delivery_turn INTEGER NOT NULL,
    actual_delivery_turn INTEGER,
    
    status TEXT NOT NULL  -- PENDING / DELIVERED / CANCELLED
);
```

**Pricing Dynamics:**
- **Cost-Plus:** Seller's manufacturing cost + margin (20-50%)
- **Market Competition:** Multiple sellers drive prices down
- **Technology Premium:** Higher tech_level commands higher prices
- **Volume Discounts:** Large orders may negotiate lower unit prices (future)

#### 5.6.8 AI Procurement Strategies

AI companies (and optionally player-delegated factories) use **procurement policies** to automate material purchasing:

**1. Just-In-Time (JIT):**
- **Philosophy:** Zero inventory, buy only what's needed this period
- **Pros:** Minimal capital tie-up, low carrying costs
- **Cons:** Vulnerable to price spikes and supply shortages
- **AI Personality:** Risk-tolerant, cash-constrained companies

**2. Hoarder:**
- **Philosophy:** Buy heavily when prices drop below 90% of historical average
- **Target Inventory:** 4-8 weeks of production needs
- **Pros:** Protected from price increases and shortages
- **Cons:** High capital requirements, risk of being stuck with expensive inventory if prices fall
- **AI Personality:** Conservative, cash-rich companies

**3. Balanced:**
- **Philosophy:** Maintain 2-week safety stock, opportunistically increase to 3 weeks when cheap
- **Pros:** Balanced risk and capital efficiency
- **Cons:** No strong advantage in either direction
- **AI Personality:** Default strategy for most AI companies

**Implementation:**

```python
class AIProcurementDelegate:
    def run_procurement_policy(factory, policy_type, planned_production, game_turn):
        if policy_type == "JUST_IN_TIME":
            return execute_jit_policy(factory, planned_production)
        elif policy_type == "HOARDER":
            return execute_hoarder_policy(factory, planned_production)
        elif policy_type == "BALANCED":
            return execute_balanced_policy(factory, planned_production)
```

**Decision Logic Example (Hoarder):**

```python
def execute_hoarder_policy(factory, planned_production):
    material_needs = calculate_weekly_material_needs(planned_production)
    
    for material_type, weekly_need in material_needs.items():
        current_stock = get_inventory(factory, material_type)
        market_price = get_material_market(factory.region, material_type)
        
        # Check if price is attractive
        if market_price.is_below_average(threshold=0.90):
            target_stock = weekly_need * 8  # 8 weeks when cheap
        elif market_price.is_below_average(threshold=0.95):
            target_stock = weekly_need * 6
        else:
            target_stock = weekly_need * 4  # Minimum 4 weeks
        
        shortage = target_stock - current_stock
        if shortage > 0:
            purchase_materials(factory, material_type, shortage)
```

#### 5.6.9 Implementation Modules

**Backend Structure:**

```
backend/
├── models/
│   ├── production.py        # Factory, MaterialMarket, Inventory models
│   └── b2b.py               # ComponentListing, B2BTransaction models
│
├── core/
│   ├── production/
│   │   └── production_manager.py  # ProductionManager class
│   │                                # - produce_component()
│   │                                # - assemble_car()
│   │                                # - auto_logistics()
│   │                                # - purchase_materials()
│   │
│   └── ai/
│       └── ai_procurement.py       # AIProcurementDelegate class
│                                    # - run_procurement_policy()
│                                    # - execute_jit_policy()
│                                    # - execute_hoarder_policy()
│                                    # - execute_balanced_policy()
│
├── services/
│   └── production_service.py       # High-level production API
│
└── api/
    └── routes/
        └── production.py            # REST endpoints
```

**Key Classes:**

1. **ProductionManager:** Core production logic
   - Material requirements calculation
   - Component/vehicle production execution
   - Inventory management
   - Inter-factory logistics

2. **AIProcurementDelegate:** Automated procurement for AI companies
   - Strategy execution (JIT/Hoarder/Balanced)
   - Price trend analysis
   - Batch processing for turn resolution

3. **MaterialMarketSimulator:** (Future) Price fluctuation engine
   - Supply/demand modeling
   - Random shock generation
   - Regional price differentials

---

## 6. Algorithm Specifications

### 6.1 Utility Calculation Algorithm

```python
def calculate_vehicle_utility(
    vehicle: VehicleTrim,
    buyer: ConsumerBucket,
    market_context: MarketContext
) -> float:
    """
    Calculate the utility score a consumer bucket assigns to a vehicle.
    
    Returns a normalized utility score (0-1), where:
    - 0 = Completely unsuitable
    - 1 = Perfect match
    - buyer.min_utility_threshold = Minimum to consider purchase
    """
    
    # ==========================================
    # STEP 1: Check hard constraints
    # ==========================================
    
    # Price ceiling check
    effective_price = vehicle.msrp * (1 - vehicle.current_discount)
    if effective_price > buyer.price_ceiling:
        return 0.0
    
    # Body style compatibility
    if vehicle.body_style not in buyer.preferred_body_styles:
        body_style_penalty = 0.3  # Can still buy, but reduced utility
    else:
        body_style_penalty = 0.0
    
    # ==========================================
    # STEP 2: Calculate attribute scores (0-1)
    # ==========================================
    
    scores = {}
    
    # Performance Score
    # Normalized against segment benchmarks
    segment_perf_benchmark = market_context.get_segment_benchmark(
        vehicle.segment, 'performance'
    )
    scores['performance'] = min(1.0, vehicle.performance_score / segment_perf_benchmark)
    
    # Comfort Score
    segment_comfort_benchmark = market_context.get_segment_benchmark(
        vehicle.segment, 'comfort'
    )
    scores['comfort'] = min(1.0, vehicle.comfort_score / segment_comfort_benchmark)
    
    # Safety Score
    # Absolute scale, not relative to segment
    scores['safety'] = vehicle.safety_score / 100.0
    
    # Reliability Score
    # Combines vehicle reliability with brand reputation
    brand_reliability = vehicle.company.brand_reliability / 100.0
    vehicle_reliability = vehicle.reliability_score / 100.0
    scores['reliability'] = 0.6 * vehicle_reliability + 0.4 * brand_reliability
    
    # Prestige Score
    # Brand prestige modified by vehicle's market position
    brand_prestige = vehicle.company.brand_prestige / 100.0
    position_modifier = {
        'ECONOMY': 0.6,
        'MAINSTREAM': 0.8,
        'PREMIUM': 1.0,
        'LUXURY': 1.2
    }[vehicle.market_position]
    scores['prestige'] = min(1.0, brand_prestige * position_modifier)
    
    # Efficiency Score
    # Based on fuel economy relative to segment
    segment_efficiency_benchmark = market_context.get_segment_benchmark(
        vehicle.segment, 'fuel_economy'
    )
    # Lower L/100km is better, so invert
    scores['efficiency'] = min(1.0, segment_efficiency_benchmark / vehicle.fuel_economy)
    
    # Practicality Score
    # Cargo space + seating relative to needs
    cargo_score = min(1.0, vehicle.cargo_volume / buyer.cargo_need)
    seating_score = 1.0 if vehicle.seating >= buyer.min_seating else 0.5
    scores['practicality'] = 0.6 * cargo_score + 0.4 * seating_score
    
    # Price Score (inverse - lower price = higher score)
    # Normalized against buyer's budget range
    budget_midpoint = (buyer.price_ceiling + buyer.price_floor) / 2
    price_score = 1.0 - (effective_price - buyer.price_floor) / (buyer.price_ceiling - buyer.price_floor)
    scores['price'] = max(0.0, min(1.0, price_score))
    
    # ==========================================
    # STEP 3: Apply buyer's utility weights
    # ==========================================
    
    weighted_sum = 0.0
    for attribute, weight in buyer.utility_weights.items():
        weighted_sum += weight * scores.get(attribute, 0.5)
    
    # ==========================================
    # STEP 4: Apply modifiers
    # ==========================================
    
    # Brand affinity modifier
    brand_affinity = buyer.brand_preferences.get(vehicle.company.id, 0.5)
    brand_modifier = 0.8 + 0.4 * brand_affinity  # Range: 0.8 to 1.2
    
    # Novelty modifier (new models get boost for early adopters)
    if vehicle.months_since_launch < 12:
        novelty_bonus = 0.1 * buyer.early_adopter_score
    else:
        novelty_bonus = 0.0
    
    # Apply body style penalty
    style_modifier = 1.0 - body_style_penalty
    
    # ==========================================
    # STEP 5: Calculate final utility
    # ==========================================
    
    final_utility = weighted_sum * brand_modifier * style_modifier + novelty_bonus
    
    # Clamp to valid range
    return max(0.0, min(1.0, final_utility))


def calculate_used_car_utility(
    used_car: UsedCarListing,
    buyer: ConsumerBucket,
    market_context: MarketContext
) -> float:
    """
    Calculate utility for a used car, applying depreciation adjustments.
    """
    
    # Start with the original vehicle's utility
    base_utility = calculate_vehicle_utility(
        used_car.original_trim,
        buyer,
        market_context
    )
    
    # Apply age-based degradation
    reliability_degradation = 1.0 - (used_car.age_years * 0.03)  # 3% per year
    reliability_degradation = max(0.4, reliability_degradation)  # Floor at 40%
    
    # Condition modifier
    condition_modifiers = {
        'EXCELLENT': 1.0,
        'GOOD': 0.9,
        'FAIR': 0.75,
        'POOR': 0.5
    }
    condition_modifier = condition_modifiers[used_car.condition]
    
    # Technology obsolescence (older tech = less desirable)
    tech_obsolescence = 1.0 - (used_car.age_years * 0.02)  # 2% per year
    tech_obsolescence = max(0.5, tech_obsolescence)
    
    # Price advantage (used cars are cheaper)
    price_advantage = used_car.price / used_car.original_trim.msrp
    price_utility_boost = (1.0 - price_advantage) * buyer.price_sensitivity
    
    # Final used car utility
    adjusted_utility = (
        base_utility 
        * reliability_degradation 
        * condition_modifier 
        * tech_obsolescence
        + price_utility_boost
    )
    
    return max(0.0, min(1.0, adjusted_utility))
```

### 6.2 Market Resolution Algorithm

```python
def resolve_market_turn(
    region: Region,
    game_state: GameState
) -> MarketResolutionResult:
    """
    Main market resolution loop for a single region in a single turn.
    
    This is the core economic engine that determines:
    - Which vehicles sell
    - At what prices
    - To which consumer segments
    - What happens to unsold inventory
    """
    
    result = MarketResolutionResult(region=region)
    
    # ==========================================
    # PHASE 1: Prepare market context
    # ==========================================
    
    # Get all available new vehicles in this region
    new_vehicles = get_available_new_vehicles(region)
    
    # Get all used car inventory
    used_cars = get_used_car_inventory(region)
    
    # Calculate segment benchmarks
    market_context = MarketContext(
        segment_benchmarks=calculate_segment_benchmarks(new_vehicles),
        avg_prices_by_segment=calculate_avg_prices(new_vehicles),
        region=region
    )
    
    # ==========================================
    # PHASE 2: Calculate demand by consumer bucket
    # ==========================================
    
    for bucket in region.consumer_buckets:
        # Determine how many in this bucket want to buy this turn
        base_purchase_intent = bucket.population * bucket.purchase_frequency_annual / 12
        
        # Economic modifiers
        economic_modifier = calculate_economic_modifier(
            region.gdp_growth_rate,
            region.unemployment_rate,
            region.consumer_confidence
        )
        
        # Calculate actual demand (with some randomness)
        demand_this_turn = int(
            base_purchase_intent 
            * economic_modifier 
            * random.uniform(0.85, 1.15)
        )
        
        bucket.current_demand = demand_this_turn
    
    # ==========================================
    # PHASE 3: Run purchase simulation
    # ==========================================
    
    # Process buckets in random order to avoid systematic bias
    bucket_order = random.shuffle(list(region.consumer_buckets))
    
    for bucket in bucket_order:
        buyers_remaining = bucket.current_demand
        
        while buyers_remaining > 0:
            # Sample a batch of buyers (for performance)
            batch_size = min(100, buyers_remaining)
            
            # Calculate utilities for all options
            options = []
            
            # New vehicles
            for vehicle in new_vehicles:
                inventory = get_inventory(vehicle, region)
                if inventory.quantity_new > 0:
                    utility = calculate_vehicle_utility(vehicle, bucket, market_context)
                    if utility >= bucket.min_utility_threshold:
                        options.append({
                            'type': 'NEW',
                            'item': vehicle,
                            'utility': utility,
                            'price': vehicle.msrp * (1 - inventory.current_discount)
                        })
            
            # Used vehicles
            for used_car in used_cars:
                if used_car.quantity > 0:
                    utility = calculate_used_car_utility(used_car, bucket, market_context)
                    if utility >= bucket.min_utility_threshold:
                        options.append({
                            'type': 'USED',
                            'item': used_car,
                            'utility': utility,
                            'price': used_car.avg_asking_price
                        })
            
            # Add "no purchase" option
            options.append({
                'type': 'NONE',
                'item': None,
                'utility': 0,
                'price': 0
            })
            
            # ==========================================
            # PHASE 3a: Multinomial logit choice model
            # ==========================================
            
            if len(options) <= 1:
                # No real options, all buyers walk
                result.add_unsatisfied_demand(bucket, buyers_remaining)
                break
            
            # Calculate choice probabilities
            choice_probs = multinomial_logit_probabilities(
                options,
                price_sensitivity=bucket.price_sensitivity,
                utility_scale=3.0  # Higher = more deterministic
            )
            
            # Simulate batch purchases
            purchases = multinomial_sample(choice_probs, batch_size)
            
            for choice_idx, count in purchases.items():
                option = options[choice_idx]
                
                if option['type'] == 'NEW':
                    # Record new car sale
                    actual_sales = min(count, get_inventory(option['item'], region).quantity_new)
                    result.add_new_sale(
                        vehicle=option['item'],
                        quantity=actual_sales,
                        price=option['price'],
                        buyer_bucket=bucket
                    )
                    # Decrease inventory
                    decrease_inventory(option['item'], region, actual_sales)
                    
                elif option['type'] == 'USED':
                    # Record used car sale
                    actual_sales = min(count, option['item'].quantity)
                    result.add_used_sale(
                        used_car=option['item'],
                        quantity=actual_sales,
                        price=option['price'],
                        buyer_bucket=bucket
                    )
                    # Decrease used inventory
                    option['item'].quantity -= actual_sales
                    
                else:  # NONE
                    # Record unsatisfied demand
                    result.add_unsatisfied_demand(bucket, count)
            
            buyers_remaining -= batch_size
    
    # ==========================================
    # PHASE 4: Post-resolution updates
    # ==========================================
    
    # Age used car inventory
    age_used_inventory(region)
    
    # Add newly registered cars that will become used next year
    # (These come from this turn's sales)
    queue_future_used_inventory(result.new_sales, region)
    
    # Calculate dealer incentives based on inventory age
    update_dealer_incentives(region, new_vehicles)
    
    # Update brand metrics based on sales performance
    update_brand_metrics(result)
    
    return result


def multinomial_logit_probabilities(
    options: List[Dict],
    price_sensitivity: float,
    utility_scale: float
) -> List[float]:
    """
    Calculate choice probabilities using multinomial logit model.
    
    P(i) = exp(V_i) / Σ exp(V_j)
    
    Where V_i = utility_scale * utility - price_sensitivity * log(price)
    """
    
    V = []
    for option in options:
        if option['type'] == 'NONE':
            # Base utility for "no purchase"
            v_i = 0.0
        else:
            v_i = (
                utility_scale * option['utility'] 
                - price_sensitivity * math.log(max(1, option['price']))
            )
        V.append(v_i)
    
    # Numerical stability: subtract max
    max_v = max(V)
    exp_v = [math.exp(v - max_v) for v in V]
    sum_exp = sum(exp_v)
    
    return [e / sum_exp for e in exp_v]


def calculate_economic_modifier(
    gdp_growth: float,
    unemployment: float,
    confidence: float
) -> float:
    """
    Calculate how economic conditions affect car buying.
    
    Returns modifier (0.5 to 1.5):
    - 1.0 = Normal conditions
    - < 1.0 = Reduced demand (recession)
    - > 1.0 = Increased demand (boom)
    """
    
    # GDP growth impact (baseline 2% growth = 1.0)
    gdp_factor = 1.0 + (gdp_growth - 0.02) * 5.0  # 1% extra growth = 5% more demand
    
    # Unemployment impact (baseline 5% = 1.0)
    unemployment_factor = 1.0 - (unemployment - 0.05) * 3.0  # 1% extra unemployment = 3% less demand
    
    # Consumer confidence (0-100, baseline 50 = 1.0)
    confidence_factor = 0.7 + (confidence / 100) * 0.6  # Range: 0.7 to 1.3
    
    # Combine factors
    modifier = gdp_factor * unemployment_factor * confidence_factor
    
    # Clamp to reasonable range
    return max(0.5, min(1.5, modifier))
```

### 6.3 AI CEO Decision Algorithm

```python
def ai_ceo_make_decisions(
    company: Company,
    game_state: GameState
) -> List[Decision]:
    """
    Main AI decision-making loop for a company CEO.
    
    Decisions are influenced by:
    - CEO personality matrix
    - Company financial state
    - Market conditions
    - Organizational inertia
    """
    
    ceo = company.ceo
    decisions = []
    
    # ==========================================
    # PHASE 1: Assess company situation
    # ==========================================
    
    situation = CompanySituation(
        cash_runway_months=company.cash_balance / company.monthly_burn_rate,
        market_share_trend=calculate_market_share_trend(company, game_state),
        profit_margin=company.last_quarter_margin,
        brand_health=calculate_brand_health(company),
        competitor_threats=identify_competitor_threats(company, game_state),
        market_opportunities=identify_market_opportunities(company, game_state)
    )
    
    # ==========================================
    # PHASE 2: Apply personality-based priorities
    # ==========================================
    
    # Aggression affects competitive response
    if situation.market_share_trend < 0 and ceo.aggression > 60:
        # Aggressive CEO responds to share loss with action
        decisions.append(Decision(
            type='PRICING',
            action='INCREASE_DISCOUNTS',
            intensity=ceo.aggression / 100 * 0.15  # Up to 15% discount
        ))
    
    # Innovation affects R&D allocation
    rd_budget_modifier = 0.8 + (ceo.innovation / 100) * 0.4  # 0.8x to 1.2x
    decisions.append(Decision(
        type='BUDGET',
        action='SET_RD_BUDGET',
        value=company.base_rd_budget * rd_budget_modifier
    ))
    
    # Risk tolerance affects expansion decisions
    if situation.cash_runway_months > 24:
        if ceo.risk_tolerance > 70:
            # High risk CEO invests aggressively
            if situation.market_opportunities:
                best_opportunity = max(
                    situation.market_opportunities, 
                    key=lambda x: x.expected_return
                )
                decisions.append(Decision(
                    type='EXPANSION',
                    action='PURSUE_OPPORTUNITY',
                    target=best_opportunity
                ))
    
    # Loyalty affects restructuring decisions
    if situation.profit_margin < 0.02:  # Less than 2% margin
        if ceo.loyalty < 40:
            # Low loyalty CEO cuts workforce quickly
            decisions.append(Decision(
                type='HR',
                action='REDUCE_WORKFORCE',
                target_reduction=0.1 * (1 - ceo.loyalty / 100)  # Up to 10%
            ))
        else:
            # High loyalty CEO tries other cost cuts first
            decisions.append(Decision(
                type='OPERATIONS',
                action='OPTIMIZE_COSTS',
                target_savings=0.05
            ))
    
    # ==========================================
    # PHASE 3: Strategic planning decisions
    # ==========================================
    
    # Product portfolio analysis
    portfolio_gaps = analyze_portfolio_gaps(company, game_state)
    
    for gap in portfolio_gaps:
        # Probability of filling gap based on innovation + resources
        fill_probability = (
            (ceo.innovation / 100) * 0.5 +
            (situation.cash_runway_months / 48) * 0.3 +
            gap.market_attractiveness * 0.2
        )
        
        if random.random() < fill_probability:
            decisions.append(Decision(
                type='PRODUCT',
                action='DEVELOP_NEW_MODEL',
                target_segment=gap.segment,
                target_region=gap.region,
                priority=gap.market_attractiveness
            ))
    
    # ==========================================
    # PHASE 4: Apply organizational inertia
    # ==========================================
    
    # Large companies can't execute all decisions immediately
    inertia_factor = company.organizational_inertia
    
    filtered_decisions = []
    for decision in decisions:
        # Some decisions get delayed or cancelled due to bureaucracy
        execution_probability = 1.0 - (inertia_factor * decision.complexity * 0.5)
        
        if random.random() < execution_probability:
            # Decision proceeds, but may be delayed
            delay_months = int(inertia_factor * decision.complexity * 6)
            decision.execution_delay = delay_months
            filtered_decisions.append(decision)
    
    # ==========================================
    # PHASE 5: Executive delegation
    # ==========================================
    
    for decision in filtered_decisions:
        # Assign to appropriate executive
        executive = find_best_executive(company, decision.type)
        if executive:
            decision.assigned_to = executive
            
            # Executive morale/competence affects execution quality
            quality_modifier = (
                executive.competence / 100 * 0.6 +
                executive.morale / 100 * 0.4
            )
            decision.expected_quality = quality_modifier
    
    return filtered_decisions


def calculate_organizational_inertia(company: Company) -> float:
    """
    Calculate how slow/fast a company can respond to changes.
    
    Returns 0-1 where:
    - 0 = Startup agility (instant decisions)
    - 1 = Maximum bureaucracy (very slow)
    """
    
    # Size factor (logarithmic scale)
    size_factor = min(1.0, math.log10(company.employee_count) / 5)  # Caps at 100k employees
    
    # Age factor (older companies are more set in their ways)
    age_years = game_state.current_year - company.founded_year
    age_factor = min(1.0, age_years / 50)  # Caps at 50 years
    
    # Bureaucracy culture
    culture_factor = company.bureaucracy_level
    
    # Calculate final inertia
    inertia = (
        size_factor * 0.4 +
        age_factor * 0.3 +
        culture_factor * 0.3
    )
    
    return min(1.0, max(0.0, inertia))
```

### 6.4 Technology Breakthrough Algorithm

```python
def process_research_turn(
    company: Company,
    game_state: GameState
) -> List[TechBreakthrough]:
    """
    Process R&D for a company, potentially unlocking new technologies.
    
    Uses a probabilistic model where:
    - Investment increases breakthrough probability
    - Genius moments (random) can accelerate progress
    - Dead ends (random) can waste investment
    """
    
    breakthroughs = []
    
    for research in company.active_research:
        tech = research.technology
        
        # ==========================================
        # Calculate breakthrough probability
        # ==========================================
        
        # Base probability from investment level
        optimal_monthly = tech.base_research_cost / tech.base_research_months
        investment_ratio = research.monthly_investment / optimal_monthly
        
        # Diminishing returns above optimal
        if investment_ratio <= 1.0:
            investment_factor = investment_ratio
        else:
            # Logarithmic returns above optimal
            investment_factor = 1.0 + math.log(investment_ratio) * 0.3
        
        # Base probability per month at optimal investment
        base_prob = 1.0 / tech.base_research_months
        
        # Engineer quality factor
        avg_engineer_quality = calculate_avg_engineer_quality(company, tech.category)
        quality_factor = 0.5 + avg_engineer_quality * 0.01  # 0.5x to 1.5x
        
        # Technology difficulty
        difficulty_factor = 1.0 / tech.difficulty  # Higher difficulty = lower chance
        
        # Random events
        random_factor = random.gauss(1.0, 0.2)  # Normal distribution around 1.0
        random_factor = max(0.3, min(2.0, random_factor))  # Clamp extremes
        
        # Final probability
        breakthrough_prob = (
            base_prob 
            * investment_factor 
            * quality_factor 
            * difficulty_factor 
            * random_factor
        )
        
        # ==========================================
        # Roll for breakthrough
        # ==========================================
        
        roll = random.random()
        
        if roll < breakthrough_prob:
            # SUCCESS!
            breakthroughs.append(TechBreakthrough(
                technology=tech,
                company=company,
                turn=game_state.turn_number,
                investment_total=research.research_invested
            ))
            
            research.status = 'COMPLETE'
            research.research_completed_turn = game_state.turn_number
            
            # Unlock dependent technologies
            unlock_dependent_techs(company, tech)
            
            # Unlock new parts
            for part_code in tech.unlocks_parts:
                unlock_part_for_company(company, part_code)
            
            # Generate news event
            generate_breakthrough_news(company, tech, game_state)
            
        elif roll > 0.95:
            # DEAD END - waste some progress
            wasted = research.research_invested * 0.1
            research.research_invested -= wasted
            
            generate_dead_end_event(company, tech, game_state)
        
        else:
            # Normal progress
            research.research_invested += research.monthly_investment
            research.breakthrough_attempts += 1
    
    return breakthroughs


def calculate_avg_engineer_quality(
    company: Company, 
    tech_category: str
) -> float:
    """
    Calculate the average quality of engineers working on a technology category.
    
    Returns 0-100 quality score.
    """
    
    # Get relevant executives
    cto = get_executive(company, 'CTO')
    
    if cto is None:
        base_quality = 40  # No CTO = below average
    else:
        base_quality = cto.competence
    
    # Modify by company's overall R&D reputation
    rd_reputation_modifier = company.brand_innovation / 100
    
    # Modify by salary competitiveness
    market_salary = get_market_salary(tech_category, company.region)
    company_salary = company.avg_engineer_salary
    salary_competitiveness = min(1.2, company_salary / market_salary)
    
    # Modify by morale
    morale_factor = company.avg_employee_morale / 100
    
    final_quality = (
        base_quality 
        * rd_reputation_modifier 
        * salary_competitiveness 
        * morale_factor
    )
    
    return min(100, max(0, final_quality))
```

### 6.5 Natural Language Directive Parser

```python
def parse_natural_language_directive(
    directive_text: str,
    company: Company,
    game_state: GameState
) -> ParsedDirective:
    """
    Parse a natural language directive into structured parameters.
    
    Examples:
    - "Build a cheap sports car for the Asian market"
    - "Cut costs by 15% without affecting quality"
    - "Develop an electric SUV platform"
    """
    
    # Normalize text
    text = directive_text.lower().strip()
    
    # ==========================================
    # Classify directive type
    # ==========================================
    
    directive_type = classify_directive_type(text)
    
    result = ParsedDirective(
        original_text=directive_text,
        directive_type=directive_type,
        confidence=0.0,
        parameters={}
    )
    
    if directive_type == 'VEHICLE_DESIGN':
        result = parse_vehicle_design_directive(text, game_state)
        
    elif directive_type == 'COST_REDUCTION':
        result = parse_cost_directive(text, company)
        
    elif directive_type == 'MARKET_EXPANSION':
        result = parse_expansion_directive(text, game_state)
        
    elif directive_type == 'TECHNOLOGY':
        result = parse_technology_directive(text, game_state)
        
    elif directive_type == 'HR':
        result = parse_hr_directive(text, company)
    
    return result


def parse_vehicle_design_directive(
    text: str,
    game_state: GameState
) -> ParsedDirective:
    """
    Parse vehicle design directives into structured specs.
    """
    
    params = {}
    confidence_scores = []
    
    # ==========================================
    # Extract body style
    # ==========================================
    
    body_style_keywords = {
        'sedan': 'SEDAN',
        'coupe': 'COUPE',
        'hatchback': 'HATCHBACK',
        'wagon': 'WAGON',
        'suv': 'SUV',
        'crossover': 'CROSSOVER',
        'truck': 'TRUCK',
        'pickup': 'TRUCK',
        'van': 'VAN',
        'minivan': 'MINIVAN',
        'convertible': 'CONVERTIBLE',
        'roadster': 'ROADSTER',
        'sports car': 'COUPE',
        'muscle car': 'COUPE'
    }
    
    for keyword, style in body_style_keywords.items():
        if keyword in text:
            params['body_style'] = style
            confidence_scores.append(0.9)
            break
    
    # ==========================================
    # Extract market position
    # ==========================================
    
    position_keywords = {
        'cheap': 'ECONOMY',
        'budget': 'ECONOMY',
        'affordable': 'ECONOMY',
        'economy': 'ECONOMY',
        'mainstream': 'MAINSTREAM',
        'mid-range': 'MAINSTREAM',
        'premium': 'PREMIUM',
        'upscale': 'PREMIUM',
        'luxury': 'LUXURY',
        'high-end': 'LUXURY',
        'exclusive': 'LUXURY'
    }
    
    for keyword, position in position_keywords.items():
        if keyword in text:
            params['market_position'] = position
            confidence_scores.append(0.85)
            break
    
    # ==========================================
    # Extract target region
    # ==========================================
    
    region_keywords = {
        'asia': ['ASI'],
        'asian': ['ASI'],
        'china': ['CHN'],
        'chinese': ['CHN'],
        'japan': ['JPN'],
        'japanese': ['JPN'],
        'europe': ['EUR'],
        'european': ['EUR'],
        'america': ['NAM'],
        'american': ['NAM'],
        'us': ['NAM'],
        'domestic': [game_state.player_company.headquarters_region.code],
        'global': ['NAM', 'EUR', 'ASI'],
        'worldwide': ['NAM', 'EUR', 'ASI']
    }
    
    for keyword, regions in region_keywords.items():
        if keyword in text:
            params['target_regions'] = regions
            confidence_scores.append(0.8)
            break
    
    # ==========================================
    # Extract priority attributes
    # ==========================================
    
    priority_keywords = {
        'fast': 'performance',
        'quick': 'performance',
        'powerful': 'performance',
        'sporty': 'performance',
        'performance': 'performance',
        'comfortable': 'comfort',
        'comfort': 'comfort',
        'spacious': 'comfort',
        'safe': 'safety',
        'safety': 'safety',
        'secure': 'safety',
        'efficient': 'efficiency',
        'fuel-efficient': 'efficiency',
        'economical': 'efficiency',
        'reliable': 'reliability',
        'dependable': 'reliability',
        'durable': 'reliability',
        'practical': 'practicality',
        'family': 'practicality',
        'utility': 'practicality'
    }
    
    priorities = []
    for keyword, priority in priority_keywords.items():
        if keyword in text:
            if priority not in priorities:
                priorities.append(priority)
                confidence_scores.append(0.75)
    
    params['priorities'] = priorities[:3]  # Max 3 priorities
    
    # ==========================================
    # Extract price constraints
    # ==========================================
    
    import re
    
    # Match patterns like "$15,000", "$15k", "15000 dollars"
    price_patterns = [
        r'\$(\d{1,3}(?:,\d{3})*(?:\.\d{2})?)',  # $15,000
        r'\$(\d+)k\b',  # $15k
        r'(\d{1,3}(?:,\d{3})*)\s*dollars?',  # 15000 dollars
        r'under\s*\$?(\d+)',  # under $15000
        r'below\s*\$?(\d+)',  # below 15000
    ]
    
    for pattern in price_patterns:
        match = re.search(pattern, text)
        if match:
            price_str = match.group(1).replace(',', '')
            if 'k' in text[match.start():match.end()].lower():
                price = float(price_str) * 1000
            else:
                price = float(price_str)
            
            if 'under' in text or 'below' in text:
                params['max_price'] = price
            else:
                params['target_price'] = price
            
            confidence_scores.append(0.9)
            break
    
    # ==========================================
    # Calculate overall confidence
    # ==========================================
    
    if confidence_scores:
        overall_confidence = sum(confidence_scores) / len(confidence_scores)
    else:
        overall_confidence = 0.3  # Low confidence if nothing matched
    
    return ParsedDirective(
        original_text=text,
        directive_type='VEHICLE_DESIGN',
        confidence=overall_confidence,
        parameters=params
    )


def classify_directive_type(text: str) -> str:
    """
    Classify the type of directive based on keywords.
    """
    
    type_keywords = {
        'VEHICLE_DESIGN': [
            'build', 'design', 'create', 'develop', 'make', 'car', 'vehicle',
            'model', 'sedan', 'suv', 'truck', 'coupe'
        ],
        'COST_REDUCTION': [
            'cut', 'reduce', 'save', 'cost', 'expense', 'budget', 'cheaper',
            'efficiency', 'streamline', 'optimize'
        ],
        'MARKET_EXPANSION': [
            'expand', 'enter', 'market', 'region', 'territory', 'growth',
            'presence', 'footprint'
        ],
        'TECHNOLOGY': [
            'research', 'develop', 'technology', 'tech', 'innovate',
            'r&d', 'engineering', 'platform', 'electric', 'hybrid'
        ],
        'HR': [
            'hire', 'fire', 'recruit', 'staff', 'employee', 'workforce',
            'executive', 'team', 'restructure'
        ]
    }
    
    scores = {}
    for directive_type, keywords in type_keywords.items():
        score = sum(1 for kw in keywords if kw in text)
        scores[directive_type] = score
    
    if max(scores.values()) == 0:
        return 'UNKNOWN'
    
    return max(scores, key=scores.get)
```

### 6.6 Supply Chain Price Fluctuation

```python
def update_commodity_prices(game_state: GameState) -> None:
    """
    Update raw material prices with realistic fluctuations.
    
    Implements:
    - Long-term trends (technology, scarcity)
    - Cyclical patterns (economic cycles)
    - Random shocks (supply disruptions, discoveries)
    """
    
    for commodity in game_state.commodities:
        # ==========================================
        # Long-term trend
        # ==========================================
        
        years_elapsed = game_state.current_year - game_state.start_year
        
        # Different commodities have different trends
        trend_rates = {
            'STEEL': 0.01,        # Slow increase due to demand
            'ALUMINUM': 0.015,    # Faster increase (lighter cars)
            'COPPER': 0.02,       # Increasing (electronics)
            'RARE_EARTH': 0.03,   # Fastest increase (EVs, tech)
            'RUBBER': 0.005,      # Slow, synthetic alternatives
            'OIL': 0.02,          # Volatile but trending up
            'LITHIUM': 0.04,      # EV battery demand
            'COBALT': 0.035       # EV battery demand
        }
        
        trend = trend_rates.get(commodity.code, 0.01)
        trend_factor = 1.0 + trend * years_elapsed
        
        # ==========================================
        # Economic cycle
        # ==========================================
        
        # Sine wave with ~10 year period
        cycle_phase = (game_state.turn_number % 120) / 120 * 2 * math.pi
        cycle_amplitude = 0.15  # ±15% swing
        cycle_factor = 1.0 + cycle_amplitude * math.sin(cycle_phase)
        
        # ==========================================
        # Random monthly fluctuation
        # ==========================================
        
        # Mean-reverting random walk
        target_price = commodity.base_price * trend_factor * cycle_factor
        current_price = commodity.current_price
        
        # Pull toward target with some randomness
        reversion_strength = 0.1
        random_shock = random.gauss(0, 0.03)  # ±3% random
        
        price_change = (
            reversion_strength * (target_price - current_price) +
            current_price * random_shock
        )
        
        new_price = current_price + price_change
        
        # ==========================================
        # Apply supply shocks
        # ==========================================
        
        # Check for active supply disruption events
        for event in game_state.active_events:
            if event.affects_commodity == commodity.code:
                new_price *= event.price_modifier
        
        # Floor and ceiling
        new_price = max(commodity.base_price * 0.3, new_price)  # Min 30% of base
        new_price = min(commodity.base_price * 5.0, new_price)  # Max 500% of base
        
        commodity.current_price = new_price
        commodity.price_history.append({
            'turn': game_state.turn_number,
            'price': new_price
        })
```

---

## 7. API Specification

### 7.1 API Overview

The FastAPI backend exposes RESTful endpoints organized by domain. All endpoints return JSON.

**Base URL:** `http://localhost:8000/api/v1`

**Authentication:** Session-based (single-player game, no auth needed for MVP)

**Standard Response Format:**
```json
{
    "success": true,
    "data": { ... },
    "message": "Operation completed",
    "timestamp": "2024-01-15T10:30:00Z"
}
```

**Error Response Format:**
```json
{
    "success": false,
    "error": {
        "code": "INSUFFICIENT_FUNDS",
        "message": "Cannot afford this purchase",
        "details": { "required": 1000000, "available": 500000 }
    },
    "timestamp": "2024-01-15T10:30:00Z"
}
```

### 7.2 Game Management Endpoints

```yaml
# ============================================================
# GAME LIFECYCLE
# ============================================================

POST /api/v1/game/new
  description: Create a new game
  request:
    body:
      save_name: string (required)
      start_year: integer (default: 1950)
      difficulty: enum[easy, normal, hard, brutal]
      simulation_speed: enum[weekly, monthly]
      player_company_name: string (required)
      starting_region: string (required)  # Region code
      random_seed: integer (optional)
  response:
    game_id: integer
    initial_state: GameStateSnapshot

GET /api/v1/game/{game_id}
  description: Get current game state
  response:
    game_state: GameStateSnapshot
    player_company: CompanySnapshot
    current_events: Event[]
    pending_decisions: Decision[]

POST /api/v1/game/{game_id}/save
  description: Save game to disk
  request:
    body:
      save_name: string (optional, uses existing if not provided)
  response:
    save_path: string
    save_size_bytes: integer

POST /api/v1/game/{game_id}/load
  description: Load a saved game
  request:
    body:
      save_path: string
  response:
    game_state: GameStateSnapshot

GET /api/v1/game/saves
  description: List all save files
  response:
    saves: SaveFileInfo[]

DELETE /api/v1/game/{game_id}
  description: Delete a game/save
  response:
    deleted: boolean
```

### 7.3 Turn Processing Endpoints

```yaml
# ============================================================
# TURN MANAGEMENT
# ============================================================

POST /api/v1/game/{game_id}/turn/advance
  description: Advance to the next turn (process all phases)
  request:
    body:
      player_decisions: Decision[] (optional)
  response:
    new_turn_number: integer
    turn_results: TurnResultsSummary
    events_generated: Event[]
    notifications: Notification[]

GET /api/v1/game/{game_id}/turn/preview
  description: Preview what will happen next turn (without committing)
  response:
    predicted_sales: SalesPrediction[]
    predicted_financials: FinancialPrediction
    ai_company_actions: AIActionPreview[]
    warnings: Warning[]

POST /api/v1/game/{game_id}/turn/simulate
  description: Run multiple turns in background (batch processing)
  request:
    body:
      turns_to_simulate: integer (max: 120)
      stop_on_event_severity: enum[minor, moderate, major, critical, never]
  response:
    job_id: string
    estimated_completion_seconds: integer

GET /api/v1/game/{game_id}/turn/simulate/{job_id}
  description: Check simulation job status
  response:
    status: enum[running, completed, stopped, failed]
    turns_completed: integer
    stop_reason: string (if stopped)
    results_summary: BatchSimulationResults
```

### 7.4 Company Management Endpoints

```yaml
# ============================================================
# COMPANY OPERATIONS
# ============================================================

GET /api/v1/game/{game_id}/company/{company_id}
  description: Get detailed company information
  response:
    company: CompanyDetail
    financials: FinancialSnapshot
    vehicles: VehicleModelSummary[]
    factories: FactorySummary[]
    executives: ExecutiveSummary[]
    research: ResearchSummary[]

GET /api/v1/game/{game_id}/company/{company_id}/financials
  description: Get financial statements and metrics
  query_params:
    period: enum[monthly, quarterly, yearly]
    start_turn: integer (optional)
    end_turn: integer (optional)
  response:
    income_statements: IncomeStatement[]
    balance_sheets: BalanceSheet[]
    cash_flow: CashFlowStatement[]
    key_metrics: FinancialMetrics

POST /api/v1/game/{game_id}/company/{company_id}/directive
  description: Issue a new directive
  request:
    body:
      directive_type: enum[philosophy, kpi, natural_language, specific]
      category: string (optional)
      content: DirectiveContent
      assigned_executive_id: integer (optional)
      deadline_turn: integer (optional)
  response:
    directive_id: integer
    parsed_interpretation: ParsedDirective (for NL directives)
    assigned_to: ExecutiveSummary

GET /api/v1/game/{game_id}/company/{company_id}/directives
  description: List all company directives
  query_params:
    status: enum[active, completed, failed, cancelled, all]
  response:
    directives: DirectiveDetail[]

# ============================================================
# EXECUTIVE MANAGEMENT
# ============================================================

GET /api/v1/game/{game_id}/executives/available
  description: List executives available for hire
  query_params:
    role: enum[CEO, CTO, CFO, COO, CMO] (optional)
    min_competence: integer (optional)
  response:
    executives: ExecutiveProfile[]

POST /api/v1/game/{game_id}/company/{company_id}/executives/hire
  description: Hire an executive
  request:
    body:
      executive_id: integer
      role: string
      salary: number
      contract_length_months: integer
  response:
    hired: boolean
    executive: ExecutiveDetail
    contract: ContractDetails

POST /api/v1/game/{game_id}/company/{company_id}/executives/{exec_id}/fire
  description: Fire an executive
  request:
    body:
      severance_multiplier: number (default: 1.0)
  response:
    fired: boolean
    severance_paid: number
    morale_impact: number

PUT /api/v1/game/{game_id}/company/{company_id}/executives/{exec_id}
  description: Update executive (salary, role, etc.)
  request:
    body:
      salary: number (optional)
      role: string (optional)
  response:
    updated: ExecutiveDetail
```

### 7.5 Vehicle Design Endpoints

```yaml
# ============================================================
# VEHICLE DESIGN
# ============================================================

POST /api/v1/game/{game_id}/company/{company_id}/vehicles/design
  description: Start designing a new vehicle
  request:
    body:
      design_method: enum[directive, sliders, detailed]
      
      # For directive method
      directive_text: string
      
      # For sliders method
      sliders:
        performance: number (0-100)
        comfort: number (0-100)
        safety: number (0-100)
        efficiency: number (0-100)
        prestige: number (0-100)
      target_price_range: [number, number]
      body_style: string
      segment: string
      
      # For detailed method
      platform_id: integer
      specifications: DetailedVehicleSpec
      
  response:
    vehicle_id: integer
    estimated_cost: number
    estimated_months: integer
    design_preview: VehicleDesignPreview
    warnings: Warning[]

GET /api/v1/game/{game_id}/company/{company_id}/vehicles/{vehicle_id}
  description: Get vehicle details
  response:
    vehicle: VehicleModelDetail
    trims: VehicleTrimDetail[]
    sales_history: SalesHistoryEntry[]
    competitor_comparison: CompetitorComparison[]

PUT /api/v1/game/{game_id}/company/{company_id}/vehicles/{vehicle_id}
  description: Update vehicle (pricing, production targets, etc.)
  request:
    body:
      updates: VehicleUpdateRequest
  response:
    updated: VehicleModelDetail

POST /api/v1/game/{game_id}/company/{company_id}/vehicles/{vehicle_id}/trims
  description: Add a new trim level
  request:
    body:
      trim_name: string
      engine_id: integer
      transmission_id: integer
      features: integer[]  # Part IDs
      msrp: number
  response:
    trim_id: integer
    trim: VehicleTrimDetail

GET /api/v1/game/{game_id}/parts
  description: List available parts
  query_params:
    category: string (optional)
    company_id: integer (optional)  # Include company proprietary parts
    min_quality: integer (optional)
  response:
    parts: PartDetail[]

# ============================================================
# REVERSE ENGINEERING
# ============================================================

POST /api/v1/game/{game_id}/company/{company_id}/reverse-engineer
  description: Start reverse engineering a competitor vehicle
  request:
    body:
      target_vehicle_id: integer
      focus_areas: string[]  # ['ENGINE', 'SUSPENSION', 'ELECTRONICS']
  response:
    project_id: integer
    acquisition_cost: number
    estimated_months: integer
    expected_learnings: TechLearningPreview[]

GET /api/v1/game/{game_id}/company/{company_id}/reverse-engineer/{project_id}
  description: Get reverse engineering project status
  response:
    status: enum[in_progress, completed, cancelled]
    progress_percent: number
    learnings_unlocked: TechLearning[]
```

### 7.6 Market Data Endpoints

```yaml
# ============================================================
# MARKET INTELLIGENCE
# ============================================================

GET /api/v1/game/{game_id}/market/overview
  description: Get global market overview
  response:
    total_sales_ytd: number
    total_market_size: number
    growth_rate: number
    top_selling_vehicles: VehicleSalesSummary[]
    market_share_by_company: MarketShareEntry[]

GET /api/v1/game/{game_id}/market/region/{region_code}
  description: Get regional market data
  response:
    region: RegionDetail
    consumer_segments: ConsumerBucketSummary[]
    demand_by_segment: DemandBreakdown
    competitive_landscape: CompetitorPresence[]
    trending_preferences: TrendingPreference[]

GET /api/v1/game/{game_id}/market/segment/{segment}
  description: Get segment analysis
  query_params:
    region: string (optional)
  response:
    segment_size: number
    growth_rate: number
    avg_price: number
    top_vehicles: VehicleRanking[]
    unmet_demand: UnmetDemandAnalysis

GET /api/v1/game/{game_id}/market/used-cars
  description: Get used car market data
  query_params:
    region: string (optional)
  response:
    total_inventory: number
    avg_age: number
    price_trends: PriceTrend[]
    volume_by_age: VolumeByAge[]
    competition_with_new: CompetitionAnalysis

GET /api/v1/game/{game_id}/market/forecast
  description: Get market forecasts
  query_params:
    horizon_months: integer (default: 12)
    region: string (optional)
  response:
    gdp_forecast: number[]
    demand_forecast: DemandForecast[]
    price_trend_forecast: PriceForecast[]
    technology_adoption: TechAdoptionForecast[]
```

### 7.7 Production Endpoints

```yaml
# ============================================================
# FACTORY MANAGEMENT
# ============================================================

GET /api/v1/game/{game_id}/company/{company_id}/factories
  description: List all factories
  response:
    factories: FactoryDetail[]

POST /api/v1/game/{game_id}/company/{company_id}/factories
  description: Build a new factory
  request:
    body:
      region_id: integer
      factory_type: enum[assembly, engine, stamping, full]
      capacity: integer
      automation_level: number (0-1)
  response:
    factory_id: integer
    construction_cost: number
    completion_turn: integer

PUT /api/v1/game/{game_id}/company/{company_id}/factories/{factory_id}
  description: Update factory settings
  request:
    body:
      production_targets: ProductionTarget[]
      worker_count: integer (optional)
      upgrade_automation: boolean (optional)
  response:
    updated: FactoryDetail

GET /api/v1/game/{game_id}/company/{company_id}/supply-chain
  description: Get supply chain overview
  response:
    suppliers: SupplierRelation[]
    commodity_costs: CommodityCost[]
    bottlenecks: SupplyBottleneck[]
    recommendations: SupplyChainRecommendation[]

POST /api/v1/game/{game_id}/company/{company_id}/supply-chain/contract
  description: Negotiate supplier contract
  request:
    body:
      supplier_id: integer
      volume_commitment: integer
      contract_months: integer
  response:
    contract_id: integer
    negotiated_price: number
    discount_percent: number
```

### 7.8 Research Endpoints

```yaml
# ============================================================
# R&D MANAGEMENT
# ============================================================

GET /api/v1/game/{game_id}/technology/tree
  description: Get full technology tree
  query_params:
    company_id: integer (optional)  # Include company-specific status
  response:
    technologies: TechnologyNode[]
    relationships: TechRelationship[]

GET /api/v1/game/{game_id}/company/{company_id}/research
  description: Get company research status
  response:
    active_projects: ResearchProject[]
    completed_technologies: Technology[]
    available_technologies: Technology[]
    total_rd_budget: number
    rd_efficiency: number

POST /api/v1/game/{game_id}/company/{company_id}/research/start
  description: Start researching a technology
  request:
    body:
      technology_id: integer
      monthly_budget: number
      assigned_engineers: integer
  response:
    project_id: integer
    estimated_months: integer
    breakthrough_probability: number

PUT /api/v1/game/{game_id}/company/{company_id}/research/{project_id}
  description: Adjust research project
  request:
    body:
      monthly_budget: number (optional)
      assigned_engineers: integer (optional)
      cancel: boolean (optional)
  response:
    updated: ResearchProject
```

### 7.9 WebSocket Events (Real-time Updates)

```yaml
# ============================================================
# WEBSOCKET ENDPOINT
# ============================================================

WS /api/v1/game/{game_id}/ws
  description: Real-time game updates

# Server -> Client Events:

event: turn_started
  data:
    turn_number: integer
    phase: string

event: turn_completed
  data:
    turn_number: integer
    summary: TurnSummary

event: notification
  data:
    type: enum[info, warning, success, error]
    title: string
    message: string
    related_entity: EntityReference (optional)

event: market_update
  data:
    region: string
    sales_data: SalesUpdate

event: breakthrough
  data:
    technology: TechnologySummary
    company_id: integer

event: ceo_change
  data:
    company_id: integer
    old_ceo: ExecutiveSummary
    new_ceo: ExecutiveSummary
    reason: string

# Client -> Server Commands:

command: pause_simulation
command: resume_simulation
command: request_update
  data:
    entity_type: string
    entity_id: integer
```

### 7.10 TypeScript Types (Frontend)

```typescript
// ============================================================
// SHARED TYPES (frontend/src/api/types.ts)
// ============================================================

// Game State
interface GameState {
  id: number;
  saveName: string;
  currentYear: number;
  currentMonth: number;
  currentWeek: number;
  turnNumber: number;
  difficulty: 'easy' | 'normal' | 'hard' | 'brutal';
  simulationSpeed: 'weekly' | 'monthly';
}

// Company
interface Company {
  id: number;
  name: string;
  shortName: string;
  foundedYear: number;
  isPlayerControlled: boolean;
  cashBalance: number;
  totalDebt: number;
  creditRating: string;
  brandPrestige: number;
  brandReliability: number;
  brandInnovation: number;
  employeeCount: number;
  avgEmployeeMorale: number;
}

// Executive
interface Executive {
  id: number;
  firstName: string;
  lastName: string;
  role: 'CEO' | 'CTO' | 'CFO' | 'COO' | 'CMO';
  // Personality Matrix
  aggression: number;
  innovation: number;
  riskTolerance: number;
  loyalty: number;
  // Performance
  competence: number;
  morale: number;
  currentLoyalty: number;
  salary: number;
}

// Vehicle
interface VehicleModel {
  id: number;
  name: string;
  modelCode: string;
  generation: number;
  bodyStyle: BodyStyle;
  segment: Segment;
  marketPosition: MarketPosition;
  isActive: boolean;
  overallQualityScore: number;
  developmentCostTotal: number;
}

interface VehicleTrim {
  id: number;
  modelId: number;
  name: string;
  trimCode: string;
  // Powertrain
  horsepower: number;
  torqueNm: number;
  zeroToSixty: number;
  topSpeedKph: number;
  fuelEconomyL100km: number;
  // Scores
  performanceScore: number;
  comfortScore: number;
  safetyScore: number;
  technologyScore: number;
  prestigeScore: number;
  reliabilityScore: number;
  // Pricing
  manufacturingCost: number;
  msrp: number;
  isInProduction: boolean;
}

// Region
interface Region {
  id: number;
  code: string;
  name: string;
  population: number;
  gdpPerCapita: number;
  gdpGrowthRate: number;
  purchasingPowerIndex: number;
  infrastructureQuality: number;
  fuelPrice: number;
  importTariffRate: number;
  emissionStandard: string;
  corporateTaxRate: number;
}

// Market
interface ConsumerBucket {
  id: number;
  regionId: number;
  name: string;
  populationCount: number;
  avgIncome: number;
  purchaseFrequencyYears: number;
  priceSensitivity: number;
  brandLoyalty: number;
  currentDemand: number;
  satisfiedDemand: number;
  utilityWeights: UtilityWeights;
}

interface UtilityWeights {
  price: number;
  performance: number;
  comfort: number;
  reliability: number;
  safety: number;
  prestige: number;
  efficiency: number;
  practicality: number;
}

// Directive
interface Directive {
  id: number;
  directiveType: 'philosophy' | 'kpi' | 'natural_language' | 'specific';
  category?: string;
  originalText?: string;
  parsedParameters?: Record<string, any>;
  status: 'active' | 'completed' | 'failed' | 'cancelled';
  progressPercent: number;
  assignedExecutiveId?: number;
}

// Technology
interface Technology {
  id: number;
  techCode: string;
  name: string;
  category: string;
  description: string;
  prerequisiteTechs: string[];
  minYear: number;
  baseResearchCost: number;
  baseResearchMonths: number;
  difficulty: number;
}

interface ResearchProject {
  id: number;
  technologyId: number;
  status: 'locked' | 'available' | 'researching' | 'complete';
  researchInvested: number;
  monthlyInvestment: number;
  breakthroughProgress: number;
  assignedEngineers: number;
}

// Factory
interface Factory {
  id: number;
  name: string;
  regionId: number;
  factoryType: 'assembly' | 'engine' | 'stamping' | 'full';
  maxMonthlyCapacity: number;
  currentUtilization: number;
  workerCount: number;
  workerSkillLevel: number;
  automationLevel: number;
  qualityRating: number;
  efficiencyRating: number;
  isOperational: boolean;
}

// Events
interface GameEvent {
  id: number;
  turnNumber: number;
  eventType: 'economic' | 'company' | 'technology' | 'scandal';
  severity: 'minor' | 'moderate' | 'major' | 'critical';
  headline: string;
  description: string;
  isAcknowledged: boolean;
}

// Enums
type BodyStyle = 
  | 'SEDAN' | 'COUPE' | 'HATCHBACK' | 'WAGON' 
  | 'SUV' | 'CROSSOVER' | 'TRUCK' | 'VAN' 
  | 'MINIVAN' | 'CONVERTIBLE' | 'ROADSTER';

type Segment = 
  | 'SUBCOMPACT' | 'COMPACT' | 'MIDSIZE' 
  | 'FULLSIZE' | 'LUXURY';

type MarketPosition = 
  | 'ECONOMY' | 'MAINSTREAM' | 'PREMIUM' | 'LUXURY';
```

---

## 8. Data Structures for 3D Readiness

### 8.1 Design Philosophy

The data architecture is designed to seamlessly support future 3D visualization without requiring database schema changes. All visual parameters are stored as normalized values that can be interpreted by any rendering system.

### 8.2 Vehicle Geometry System

```python
@dataclass
class VehicleGeometry:
    """
    Normalized vehicle geometry for procedural 3D generation.
    All values are ratios (0-1) relative to overall dimensions.
    """
    
    # Overall bounding box (in mm, for scale reference)
    length: int
    width: int  
    height: int
    wheelbase: int
    
    # Longitudinal proportions (must sum to ~1.0)
    front_overhang_ratio: float    # 0.10 - 0.20 typical
    hood_length_ratio: float       # 0.15 - 0.30 typical
    cabin_length_ratio: float      # 0.35 - 0.55 typical
    trunk_length_ratio: float      # 0.10 - 0.25 typical
    rear_overhang_ratio: float     # 0.08 - 0.18 typical
    
    # Vertical proportions
    ground_clearance_ratio: float  # Relative to height
    beltline_height_ratio: float   # Window sill height / total height
    greenhouse_height_ratio: float # Greenhouse / total height
    roof_peak_position: float      # 0=front, 1=rear (where roof is highest)
    
    # Width proportions
    track_width_ratio: float       # Track width / overall width
    wheel_well_width_ratio: float  # Wheel arch width
    
    # Profile curves (control points for bezier curves)
    hood_profile: List[Tuple[float, float]]      # [(x, y), ...]
    roof_profile: List[Tuple[float, float]]
    rear_profile: List[Tuple[float, float]]
    side_profile: List[Tuple[float, float]]
    
    # Cross-section templates
    front_section_type: str   # 'ROUNDED', 'ANGULAR', 'BOXY', 'WEDGE'
    rear_section_type: str
    cabin_section_type: str


@dataclass
class VehicleStyling:
    """
    Styling parameters for visual appearance.
    """
    
    # Front fascia
    grille_style: str           # 'HORIZONTAL_SLATS', 'MESH', 'SOLID', 'SPLIT'
    grille_size: float          # 0-1, relative to front area
    grille_shape: str           # 'RECTANGULAR', 'TRAPEZOIDAL', 'OVAL', 'HEXAGONAL'
    
    headlight_style: str        # 'ROUND', 'RECTANGULAR', 'SWEPT', 'SPLIT', 'INTEGRATED'
    headlight_position: str     # 'HIGH', 'LOW', 'CORNER', 'INTEGRATED'
    headlight_angle: float      # Degrees, for swept look
    
    bumper_style: str           # 'INTEGRATED', 'SEPARATE', 'PROMINENT'
    front_air_dam: bool
    
    # Side profile
    character_line_style: str   # 'STRAIGHT', 'RISING', 'FALLING', 'SCULPTED'
    character_line_height: float # 0-1, relative to door height
    wheel_arch_style: str       # 'ROUND', 'SQUARED', 'FLARED', 'INTEGRATED'
    door_handle_style: str      # 'VISIBLE', 'FLUSH', 'HIDDEN'
    
    # Rear fascia
    taillight_style: str        # 'HORIZONTAL', 'VERTICAL', 'WRAPAROUND', 'SPLIT'
    taillight_span: float       # 0-1, how much of rear width they cover
    exhaust_style: str          # 'HIDDEN', 'SINGLE', 'DUAL', 'QUAD', 'INTEGRATED'
    spoiler_type: str           # 'NONE', 'LIP', 'WING', 'INTEGRATED'
    
    # Roof and greenhouse
    roof_style: str             # 'STANDARD', 'FLOATING', 'FASTBACK', 'CHOPPED'
    pillar_style: str           # 'VISIBLE', 'BLACKED_OUT', 'HIDDEN'
    window_trim: str            # 'CHROME', 'BLACKED_OUT', 'BODY_COLOR'


@dataclass
class VehicleColors:
    """
    Color and material definitions.
    Uses standard color spaces for rendering compatibility.
    """
    
    # Primary body color
    exterior_color_hex: str
    exterior_finish: str        # 'SOLID', 'METALLIC', 'PEARL', 'MATTE'
    exterior_clearcoat: float   # 0-1 glossiness
    
    # Accent colors
    roof_color_hex: Optional[str]
    trim_color: str             # 'CHROME', 'BLACK', 'BODY_COLOR', 'CONTRAST'
    wheel_color: str            # 'SILVER', 'BLACK', 'MACHINED', 'BODY_COLOR'
    
    # Interior
    interior_primary_color: str
    interior_secondary_color: str
    interior_material: str      # 'CLOTH', 'LEATHER', 'SYNTHETIC', 'ALCANTARA'
    interior_trim: str          # 'PLASTIC', 'WOOD', 'ALUMINUM', 'CARBON'


@dataclass 
class VehicleWheels:
    """
    Wheel and tire specifications for rendering.
    """
    
    # Dimensions
    wheel_diameter_inches: int
    tire_aspect_ratio: int
    tire_width_mm: int
    
    # Style
    wheel_style: str            # 'ALLOY', 'STEEL', 'FORGED'
    spoke_count: int
    spoke_style: str            # 'STRAIGHT', 'CURVED', 'SPLIT', 'MESH'
    spoke_thickness: float      # 0-1
    dish_depth: float           # 0-1, how concave
    
    # Brake visibility
    visible_brakes: bool
    brake_caliper_color: Optional[str]
```

### 8.3 Part Geometry System

```python
@dataclass
class EngineGeometry:
    """
    Engine geometry for cutaway views and engine bay rendering.
    """
    
    # Envelope
    length_mm: float
    width_mm: float
    height_mm: float
    
    # Configuration
    cylinder_arrangement: str   # 'INLINE', 'V', 'FLAT', 'W'
    cylinder_count: int
    bank_angle: float           # Degrees, for V/W engines
    
    # Component positions (relative to engine center)
    intake_position: str        # 'FRONT', 'TOP', 'SIDE'
    exhaust_position: str
    turbo_position: Optional[str]
    
    # Visual details
    valve_cover_style: str
    intake_manifold_style: str
    accessory_belt_visible: bool
    

@dataclass
class ComponentMounting:
    """
    Generic component mounting information for assembly visualization.
    """
    
    component_id: int
    
    # Mounting points (relative to vehicle origin)
    mount_points: List[Dict]    # [{x, y, z, type}, ...]
    
    # Clearance requirements
    min_clearance_mm: float
    preferred_orientation: str  # For service access
    
    # Dependencies
    requires_removal_of: List[int]  # Component IDs
    connects_to: List[int]
```

### 8.4 Factory Visualization Data

```python
@dataclass
class FactoryLayout:
    """
    Factory floor layout for top-down visualization.
    """
    
    factory_id: int
    
    # Dimensions
    floor_area_sqm: float
    length_m: float
    width_m: float
    
    # Zones (relative positions 0-1)
    zones: List[Dict]
    # [
    #     {
    #         "id": "stamping",
    #         "x": 0.0, "y": 0.0,
    #         "width": 0.3, "height": 0.5,
    #         "type": "STAMPING"
    #     },
    #     ...
    # ]
    
    # Production lines
    lines: List[Dict]
    # [
    #     {
    #         "id": "line_1",
    #         "path": [[0.1, 0.2], [0.5, 0.2], [0.5, 0.8]],
    #         "stations": 12,
    #         "type": "ASSEMBLY"
    #     },
    #     ...
    # ]
    
    # Material flow
    material_routes: List[Dict]
    storage_areas: List[Dict]


@dataclass
class ProductionLineVisual:
    """
    Visual state of a production line for animation.
    """
    
    line_id: int
    
    # Current state
    vehicles_in_progress: int
    station_occupancy: List[bool]  # Which stations have a vehicle
    
    # Animation data
    cycle_time_seconds: float
    current_cycle_progress: float  # 0-1
    
    # Status indicators
    status: str                    # 'RUNNING', 'PAUSED', 'CHANGEOVER', 'MAINTENANCE'
    bottleneck_station: Optional[int]
```

---

## 9. Performance Considerations

### 9.1 Computational Bottlenecks

The simulation has several computationally intensive operations:

| Operation | Complexity | Frequency | Mitigation |
|-----------|------------|-----------|------------|
| Market Resolution | O(buckets × vehicles) | Every turn | Consumer bucketing, batch processing |
| AI CEO Decisions | O(companies × decisions) | Every turn | Parallel processing, decision caching |
| Utility Calculations | O(attributes) | Per vehicle-buyer pair | Vectorization, NumPy |
| Used Car Aging | O(cohorts × regions) | Every turn | Batch SQL updates |
| Tech Tree Updates | O(technologies) | Every turn | Dependency graph caching |

### 9.2 Memory Management

```python
# Configuration for different system profiles
PERFORMANCE_PROFILES = {
    'low': {
        'max_consumer_buckets_per_region': 10,
        'used_car_age_limit': 10,
        'sales_history_months': 60,
        'ai_decision_depth': 2,
        'market_simulation_batches': 50
    },
    'medium': {
        'max_consumer_buckets_per_region': 25,
        'used_car_age_limit': 15,
        'sales_history_months': 120,
        'ai_decision_depth': 4,
        'market_simulation_batches': 100
    },
    'high': {
        'max_consumer_buckets_per_region': 50,
        'used_car_age_limit': 20,
        'sales_history_months': 240,
        'ai_decision_depth': 6,
        'market_simulation_batches': 200
    }
}
```

### 9.3 Database Optimization

```sql
-- Materialized view for frequently accessed market data
CREATE VIEW v_market_snapshot AS
SELECT 
    r.id AS region_id,
    r.name AS region_name,
    COUNT(DISTINCT vt.id) AS available_models,
    SUM(vi.quantity_new) AS total_new_inventory,
    SUM(uci.quantity) AS total_used_inventory,
    AVG(vt.msrp) AS avg_new_price,
    AVG(uci.avg_asking_price) AS avg_used_price
FROM regions r
LEFT JOIN vehicle_inventory vi ON vi.region_id = r.id
LEFT JOIN vehicle_trims vt ON vt.id = vi.vehicle_trim_id
LEFT JOIN used_car_inventory uci ON uci.region_id = r.id
GROUP BY r.id, r.name;

-- Partition sales history by year for faster queries
-- (SQLite doesn't support partitioning, but structure allows migration)

-- Index for common query patterns
CREATE INDEX idx_sales_company_turn ON sales_history(
    (SELECT company_id FROM vehicle_trims vt 
     JOIN vehicle_models vm ON vt.model_id = vm.id 
     WHERE vt.id = vehicle_trim_id),
    turn_number
);
```

### 9.4 Caching Strategy

```python
from functools import lru_cache
from cachetools import TTLCache

# Static data cache (tech tree, part definitions)
STATIC_CACHE = {}

# Turn-based cache (cleared each turn)
TURN_CACHE = TTLCache(maxsize=10000, ttl=3600)

# Computation cache
@lru_cache(maxsize=1000)
def get_segment_benchmarks(segment: str, turn: int) -> Dict:
    """Cache segment benchmarks per turn."""
    pass

# Invalidation strategy
def on_turn_advance():
    """Clear turn-dependent caches."""
    TURN_CACHE.clear()
    get_segment_benchmarks.cache_clear()
```

### 9.5 Parallel Processing

```python
from concurrent.futures import ThreadPoolExecutor, ProcessPoolExecutor
import asyncio

async def process_turn_parallel(game_state: GameState):
    """
    Process turn with parallelization where possible.
    """
    
    # Phase 1: World update (single-threaded, fast)
    update_world_economy(game_state)
    
    # Phase 2: AI companies (parallel by company)
    with ProcessPoolExecutor(max_workers=4) as executor:
        ai_companies = [c for c in game_state.companies if not c.is_player_controlled]
        futures = [
            executor.submit(process_ai_company_turn, company, game_state)
            for company in ai_companies
        ]
        ai_results = [f.result() for f in futures]
    
    # Phase 3: Market resolution (parallel by region)
    with ProcessPoolExecutor(max_workers=4) as executor:
        futures = [
            executor.submit(resolve_market_turn, region, game_state)
            for region in game_state.regions
        ]
        market_results = [f.result() for f in futures]
    
    # Phase 4: Financial resolution (parallel by company)
    with ThreadPoolExecutor(max_workers=8) as executor:
        futures = [
            executor.submit(resolve_company_finances, company, market_results)
            for company in game_state.companies
        ]
        [f.result() for f in futures]
    
    # Phase 5: Event generation (single-threaded)
    generate_turn_events(game_state, market_results)
```

### 9.6 Frontend Performance

```typescript
// React performance optimizations

// 1. Memoized selectors for store
import { create } from 'zustand';
import { createSelector } from 'reselect';

const selectActiveVehicles = createSelector(
  (state: GameStore) => state.vehicles,
  (state: GameStore) => state.playerCompanyId,
  (vehicles, companyId) => 
    vehicles.filter(v => v.companyId === companyId && v.isActive)
);

// 2. Virtual scrolling for large lists
import { FixedSizeList } from 'react-window';

const VehicleList: React.FC<{ vehicles: Vehicle[] }> = ({ vehicles }) => (
  <FixedSizeList
    height={600}
    itemCount={vehicles.length}
    itemSize={80}
    width="100%"
  >
    {({ index, style }) => (
      <VehicleRow vehicle={vehicles[index]} style={style} />
    )}
  </FixedSizeList>
);

// 3. Debounced API calls
import { useDebouncedCallback } from 'use-debounce';

const useSearch = () => {
  const debouncedSearch = useDebouncedCallback(
    (query: string) => api.search(query),
    300
  );
  return debouncedSearch;
};

// 4. Web Workers for heavy calculations
const calculationWorker = new Worker(
  new URL('./workers/calculation.worker.ts', import.meta.url)
);

const calculateUtilitiesAsync = (vehicles: Vehicle[], bucket: ConsumerBucket) => {
  return new Promise((resolve) => {
    calculationWorker.postMessage({ vehicles, bucket });
    calculationWorker.onmessage = (e) => resolve(e.data);
  });
};
```

### 9.7 Benchmark Targets

| Metric | Target | Acceptable |
|--------|--------|------------|
| Turn processing time | < 2 seconds | < 5 seconds |
| API response time (simple) | < 50ms | < 200ms |
| API response time (complex) | < 500ms | < 2 seconds |
| Memory usage (100 years) | < 500MB | < 1GB |
| Save file size (100 years) | < 50MB | < 100MB |
| UI frame rate | 60 FPS | 30 FPS |
| Initial load time | < 3 seconds | < 8 seconds |

---

## 10. Appendix

### 10.1 Sample Initial World Configuration

```json
{
  "regions": [
    {
      "code": "NAM",
      "name": "North America",
      "population": 200000000,
      "gdp_per_capita": 15000,
      "gdp_growth_rate": 0.035,
      "infrastructure_quality": 0.85,
      "fuel_price": 0.30,
      "corporate_tax_rate": 0.35,
      "preferences": {
        "size_large": 0.45,
        "size_medium": 0.35,
        "size_small": 0.20,
        "fuel_efficiency_priority": 0.3,
        "power_priority": 0.5
      }
    },
    {
      "code": "EUR",
      "name": "Europe",
      "population": 350000000,
      "gdp_per_capita": 8000,
      "gdp_growth_rate": 0.03,
      "infrastructure_quality": 0.75,
      "fuel_price": 0.50,
      "corporate_tax_rate": 0.40,
      "preferences": {
        "size_large": 0.15,
        "size_medium": 0.40,
        "size_small": 0.45,
        "fuel_efficiency_priority": 0.6,
        "power_priority": 0.3
      }
    },
    {
      "code": "ASI",
      "name": "Asia-Pacific",
      "population": 800000000,
      "gdp_per_capita": 2000,
      "gdp_growth_rate": 0.06,
      "infrastructure_quality": 0.45,
      "fuel_price": 0.35,
      "corporate_tax_rate": 0.25,
      "preferences": {
        "size_large": 0.10,
        "size_medium": 0.30,
        "size_small": 0.60,
        "fuel_efficiency_priority": 0.7,
        "power_priority": 0.2
      }
    }
  ],
  "starting_year": 1950,
  "initial_technologies": [
    "BASIC_ICE",
    "MANUAL_TRANSMISSION",
    "DRUM_BRAKES",
    "LEAF_SPRING_SUSPENSION"
  ]
}
```

### 10.2 Event Template Examples

```json
{
  "events": [
    {
      "code": "OIL_CRISIS",
      "type": "ECONOMIC",
      "severity": "MAJOR",
      "probability_per_decade": 0.3,
      "min_year": 1970,
      "headline_template": "Oil Crisis Rocks Global Markets",
      "description_template": "A major disruption in oil supply has caused fuel prices to spike by {price_increase}%.",
      "effects": {
        "fuel_price_modifier": [1.5, 3.0],
        "demand_modifier_large_vehicles": [0.5, 0.7],
        "demand_modifier_efficient_vehicles": [1.3, 1.6]
      },
      "duration_months": [12, 36]
    },
    {
      "code": "SAFETY_SCANDAL",
      "type": "COMPANY",
      "severity": "CRITICAL",
      "probability_per_year_per_company": 0.02,
      "headline_template": "{company_name} Faces Safety Investigation",
      "description_template": "{company_name}'s {vehicle_name} is under investigation for potential safety defects affecting {affected_units} vehicles.",
      "effects": {
        "company_brand_reliability": [-20, -40],
        "company_sales_modifier": [0.6, 0.8],
        "recall_cost": [10000000, 500000000]
      },
      "duration_months": [6, 24]
    },
    {
      "code": "TECH_BREAKTHROUGH_EXTERNAL",
      "type": "TECHNOLOGY",
      "severity": "MODERATE",
      "probability_per_year": 0.1,
      "min_year": 1960,
      "headline_template": "University Researchers Announce {technology_name} Breakthrough",
      "description_template": "Academic researchers have published findings that could accelerate development of {technology_name}.",
      "effects": {
        "technology_research_cost_modifier": [0.7, 0.9],
        "technology_available_earlier_months": [6, 24]
      }
    }
  ]
}
```

### 10.3 CEO Name Generation Data

```json
{
  "first_names": {
    "NAM": ["James", "William", "Robert", "Charles", "George", "Thomas", "Henry", "Edward"],
    "EUR": ["Hans", "Friedrich", "Pierre", "Jean", "Giovanni", "Antonio", "Erik", "Sven"],
    "ASI": ["Hiroshi", "Takeshi", "Kenji", "Wei", "Chen", "Jun", "Min", "Sung"]
  },
  "last_names": {
    "NAM": ["Smith", "Johnson", "Williams", "Brown", "Jones", "Miller", "Davis", "Wilson"],
    "EUR": ["Mueller", "Schmidt", "Dubois", "Martin", "Rossi", "Ferrari", "Andersson", "Berg"],
    "ASI": ["Tanaka", "Yamamoto", "Suzuki", "Wang", "Li", "Kim", "Park", "Nguyen"]
  },
  "personality_archetypes": [
    {
      "name": "The Visionary",
      "aggression": [40, 60],
      "innovation": [75, 95],
      "risk_tolerance": [60, 80],
      "loyalty": [30, 50]
    },
    {
      "name": "The Cost Cutter",
      "aggression": [60, 80],
      "innovation": [20, 40],
      "risk_tolerance": [30, 50],
      "loyalty": [20, 40]
    },
    {
      "name": "The Builder",
      "aggression": [30, 50],
      "innovation": [50, 70],
      "risk_tolerance": [40, 60],
      "loyalty": [70, 90]
    }
  ]
}
```

---

## 11. Game Meta-Systems

### 11.1 Financial System

#### 11.1.1 Company Finance Model

Every company tracks comprehensive financial metrics:

- **Cash Flow**: Current cash reserves, operating cash flow
- **Debt Management**: Total debt, individual loans with varying terms
- **Credit Rating**: AAA to D scale based on:
  - Debt-to-asset ratio (30% weight)
  - Profitability margins (25% weight)
  - Cash reserves (20% weight)
  - Market performance (15% weight)
  - Prestige score (10% weight)

#### 11.1.2 Loan System

**Loan Types:**
- Bank Short-Term (1-2 years, 5% base rate)
- Bank Long-Term (5-10 years, 6% base rate)
- Corporate Bonds (7% base rate)
- Government Subsidy (2% base rate, requires eligibility)
- Private Equity (15% base rate, high risk)

**Interest Rate Calculation:**
```
Final Rate = Base Rate + Credit Adjustment
```

Credit adjustments range from -1.5% (AAA) to +10% (D rating).

**Loan Mechanics:**
- Equal payment schedule (amortization)
- Automatic payment on due turns
- Default consequences: Credit score penalty -10, potential bankruptcy
- Early repayment: 0-2% penalty depending on terms

#### 11.1.3 Taxation System

**Tax Components:**
- Corporate Income Tax: Regional rates (15-40%)
- Payroll Tax: Based on employee count
- Property Tax: Based on factory assets
- R&D Tax Credit: Offsets for research spending
- Import/Export Duties: Region-specific

**Tax Schedule:** Quarterly (every 12 turns)

### 11.2 Legal & Regulatory System

#### 11.2.1 Regulation Timeline

Historical regulations are seeded from `backend/data/seed_regulations.json`:

**Key Regulations:**
- 1970: US Clean Air Act (emission standards)
- 1975: Catalytic converter mandate (NAM)
- 1978: CAFE Standards (fuel economy, NAM)
- 1990: California ZEV Mandate (zero-emission vehicles)
- 1993: Euro 1 Standard (EUR)
- 1998: FMVSS 208 - Airbag Mandate (NAM)
- 2000: Euro 3 Standard (OBD required)
- 2018: China National V Standard (ASI)

Each regulation defines:
- `requirements`: JSON of technical requirements
- `fine_per_violation`: Monetary penalty
- `can_ban_sales`: Whether non-compliant vehicles are banned
- `grace_period_months`: Time to comply

#### 11.2.2 Vehicle Compliance

Every car must undergo compliance testing per region:
- Emission testing
- Safety crash testing
- Fuel economy certification

**Compliance Status:**
- COMPLIANT: Can sell in region
- NON_COMPLIANT: Fines + sales ban (if regulation allows)
- PENDING_REVIEW: Awaiting certification
- EXEMPTED: Special exemptions (rare)

#### 11.2.3 Recall System

Recalls triggered by:
- Skipped/insufficient testing (high probability)
- Low reliability scores + high production volume
- Random quality control failures

**Recall Impact:**
- Direct cost: `affected_vehicles * compensation_per_vehicle`
- Reputation damage: -10 to -40 points
- Sales impact: -20% to -50% for 6-24 months

### 11.3 Prototyping & Testing System

#### 11.3.1 Testing Pipeline

Before mass production, vehicles should undergo testing:

**Testing Phases:**
1. Prototype Build (8 turns)
2. Lab Testing (12 turns)
3. Track Testing (16 turns)
4. Durability Testing (20 turns)
5. Crash Testing (8 turns)
6. Emissions Testing (6 turns)

**Testing Intensity:** 0.5x to 2.0x multiplier
- Low intensity (0.5x): Faster, cheaper, misses issues
- Normal (1.0x): Balanced
- High intensity (2.0x): Thorough, expensive, reliable

#### 11.3.2 Issue Discovery

During testing, issues are discovered probabilistically:
- Critical issues: 5% base rate (e.g., engine fires)
- Major issues: 15% base rate (e.g., transmission failures)
- Minor issues: 30% base rate (e.g., trim quality)

Discovery rate scales with testing intensity.

**Issue Resolution:**
- Must fix critical issues before launch (or face massive recalls)
- Major issues recommended to fix
- Minor issues: quality-of-life improvements

#### 11.3.3 Testing Facilities

Special unlockable facilities boost testing:
- **Wind Tunnel**: +10% aerodynamics accuracy
- **Proving Ground**: +15% testing efficiency
- **Crash Lab**: +20% safety testing accuracy
- **Emissions Lab**: +10% emissions testing speed

**Construction Costs:** 50-200M credits
**Operating Costs:** 2-10M/year

#### 11.3.4 Skip Testing (Risky!)

Players can skip testing to rush to market:
- **Consequence**: Recall risk = 95%
- Reliability penalty: -15 points
- Potential for catastrophic brand damage

### 11.4 Prestige & Progression System

#### 11.4.1 Prestige Tiers

Global company prestige unlocks capabilities:

| Tier | Min Score | Bonuses | Unlocks |
|------|-----------|---------|---------|
| **Unknown** | 0 | None | Basic operations |
| **Local** | 20 | +5% brand power | Regional expansion |
| **National** | 40 | +10% brand power, +5% pricing | National campaigns |
| **International** | 70 | +15% brand power, +10% pricing | F1 Team, Heritage Center |
| **Legendary** | 100+ | +20% brand power, +15% pricing | Design Studio, Racing Division |

**Prestige Earned By:**
- Winning races (+5-20 points)
- Sales volume milestones (+1-10 points)
- Technology breakthroughs (+5-15 points)
- Industry awards (+10-30 points)

#### 11.4.2 Special Facilities

Prestige unlocks:
- **F1 Team**: +20% brand power, +10% innovation reputation
- **Wind Tunnel**: Testing efficiency boost
- **Proving Ground**: Full vehicle testing capability
- **Heritage Center**: Passive prestige growth +0.5/turn
- **Design Studio**: Aesthetic scoring bonus +15%

### 11.5 Event System

#### 11.5.1 Event Types

- **NEWS**: Industry announcements, competitor launches
- **CRISIS**: Oil shocks, labor strikes, supplier bankruptcies
- **OPPORTUNITY**: Government contracts, technology breakthroughs
- **TUTORIAL**: First-time action hints
- **MILESTONE**: Company achievements
- **RANDOM_EVENT**: Procedural events from templates

#### 11.5.2 Event Effects

Events can modify:
- Company cash, reputation, prestige
- Regional GDP, unemployment, demand
- Technology costs, research time
- Material prices, labor costs

**Example Event:**
```json
{
  "type": "CRISIS",
  "title": "Oil Embargo Hits {region}",
  "effects": {
    "fuel_price_multiplier": 2.5,
    "large_vehicle_demand": -40%,
    "efficient_vehicle_demand": +60%
  },
  "duration_turns": 48
}
```

#### 11.5.3 Player Choices

Some events offer choices:
```json
{
  "event": "Union Strike Threat",
  "choices": [
    {
      "id": "negotiate",
      "label": "Negotiate (Cost: 10M)",
      "effects": {"cash": -10, "employee_morale": +0.2}
    },
    {
      "id": "resist",
      "label": "Resist (Risk: Production Loss)",
      "effects": {"employee_morale": -0.3, "strike_probability": 0.8}
    }
  ]
}
```

### 11.6 Scenario & Difficulty System

#### 11.6.1 Scenario Types

- **SANDBOX**: Free play, no constraints
- **HISTORICAL**: Start in specific year (1950, 1970, 1990, 2010)
- **CHALLENGE**: Specific goals (Reach 10% market share in 20 years)
- **CRISIS**: Start bankrupt, debt-ridden, must survive

**Scenario Configuration:**
- Starting year, cash, debt
- Starting tech level (1-10)
- Starting region & facilities
- Victory conditions
- Time limits

#### 11.6.2 Difficulty Modifiers

| Modifier | Easy | Normal | Hard | Brutal |
|----------|------|--------|------|--------|
| Starting Cash | 1.5x | 1.0x | 0.7x | 0.5x |
| Revenue | 1.2x | 1.0x | 0.9x | 0.8x |
| Costs | 0.8x | 1.0x | 1.2x | 1.5x |
| AI Aggression | 0.7x | 1.0x | 1.3x | 1.7x |
| Random Events | 0.5x | 1.0x | 1.5x | 2.0x |
| Recall Probability | 0.5x | 1.0x | 1.5x | 2.5x |

### 11.7 Save/Load System

#### 11.7.1 Save System Architecture

**Dynamic Data Exported:**
- Game state, regions
- Companies (all financial/prestige data)
- Engines, chassis, car trims
- Factories, inventories, materials
- Loans, taxes, compliance records
- Prototype projects, events

**Static Data NOT Exported:**
- Regulations (loaded from seed file)
- Event templates
- Prestige level definitions
- Difficulty modifiers

**Save Format:** JSON with metadata
```json
{
  "version": "1.0.0",
  "save_name": "My Game - Turn 234",
  "saved_at": "2024-12-27T10:30:00Z",
  "metadata": {
    "current_year": 1975,
    "turn_number": 234,
    "difficulty": "hard"
  },
  "data": {
    "game_state": [...],
    "companies": [...],
    ...
  }
}
```

#### 11.7.2 Save Manager API

```python
from backend.utils.save_system import SaveLoadManager

manager = SaveLoadManager(db)

# Save game
result = manager.save_game(
    game_id=1,
    save_path="data/saves/game_001.json",
    save_name="Industrial Empire - 1975"
)

# Load game
result = manager.load_game(
    save_path="data/saves/game_001.json",
    clear_existing=True  # WARNING: Clears current DB
)

# List saves
saves = manager.list_saves("data/saves")
```

### 11.8 Game Loop Architecture

#### 11.8.1 Turn Phases

Each turn executes 8 phases sequentially:

1. **World Update**: GDP growth, resource prices, unemployment
2. **AI Decisions**: AI companies make strategic moves
3. **Production**: Factories produce, inventories update
4. **Market**: Sales resolution, market share calculation
5. **Financial**: Loan payments, taxes, bankruptcy checks
6. **Testing**: Advance prototype projects
7. **Events**: Check/trigger random events
8. **Cleanup**: Expire old data, update statistics

#### 11.8.2 Turn Execution Time

Target: < 500ms per turn for 20 companies, 5 regions

**Optimization Strategies:**
- Batch database queries
- Cache frequently accessed data
- Asynchronous AI processing (future)
- Incremental market simulation

#### 11.8.3 Game Loop API

```python
from backend.core.management.game_loop import GameLoopManager

loop_mgr = GameLoopManager(db)

# Advance one turn
result = loop_mgr.advance_turn(game_id=1)

# Result includes:
# - Execution time
# - Phase summaries
# - New turn number/date
# - Critical events (bankruptcies, recalls, etc.)
```

---

### 11.9 Diplomacy & Competitive Warfare System (v1.4)

**Core Philosophy: Corporate Espionage, Dirty Tricks, and Cutthroat Competition**

Beyond market competition, companies can engage in direct hostile actions against rivals, including executive poaching, public relations attacks, and (future) industrial espionage.

#### 11.9.1 Competitor Relations System

**Relation Score: -100 (Mortal Enemies) to +100 (Allies)**

Every pair of companies maintains a bidirectional relationship score:

```sql
CREATE TABLE competitor_relations (
    id INTEGER PRIMARY KEY,
    company_id INTEGER,           -- Company A
    target_company_id INTEGER,    -- Company B
    relation_score REAL,          -- -100 to +100
    
    -- History
    last_interaction_turn INTEGER,
    total_positive_actions INTEGER,
    total_negative_actions INTEGER,
    
    -- Special States
    is_embargo BOOLEAN,           -- TRUE if relation <= -80 (refuses B2B trade)
    is_alliance BOOLEAN           -- TRUE if relation >= +70 (cooperation benefits)
);
```

**Relation Impact:**

| Score Range | Status | Effects |
|-------------|--------|---------|
| +70 to +100 | **Alliance** | B2B component discounts (-10%), Joint R&D opportunities, Technology sharing |
| +20 to +69 | **Friendly** | Normal B2B trade, Positive market perception |
| -19 to +19 | **Neutral** | Standard business relations |
| -20 to -79 | **Hostile** | B2B premium (+20%), Increased vulnerability to dirty tricks |
| -80 to -100 | **Embargo** | B2B trade refused, Automatic PR attacks, Aggressive AI behavior |

#### 11.9.2 Dirty Trick #1: Executive Poaching

**Mechanic: Steal competitor's talent**

Players can attempt to lure away competitor's executives with higher salaries.

**Success Formula:**
```
Success Chance = (Salary Offer / Current Salary) × (1 / Loyalty) × Morale Factor × Random(0.7-1.3)

Where:
- Loyalty Factor = 1.0 / (Executive Loyalty / 100)  // 0.2x to 2.0x
- Morale Factor = 1.5 - (Executive Morale / 100)    // 0.5x to 1.5x (低士气更易被挖)
- Base multiplier = 0.15
- Max Success Chance = 80% (even with extreme offers)
```

**Consequences:**

- **Success:**
  - Executive joins poaching company
  - Executive salary = offer amount
  - Executive loyalty reset to 50 (neutral, just switched)
  - Executive morale = 75 (happy with new job)
  - **Relation penalty: -25**
  - Cost: Annual salary × 12
  - Event generated: "Executive Poached" (PUBLIC)

- **Failure:**
  - Executive remains at original company
  - Executive loyalty +10 (more loyal after refusing)
  - **Relation penalty: -10**
  - Cost: $50,000 (negotiation expenses)
  - Event generated: "Poaching Attempt Failed" (HIDDEN from public)

**Database Schema:**

```sql
CREATE TABLE diplomatic_actions (
    id INTEGER PRIMARY KEY,
    actor_company_id INTEGER,
    target_company_id INTEGER,
    action_type VARCHAR(30),  -- "POACH_EXECUTIVE", "PR_ATTACK", etc.
    
    action_details TEXT,      -- JSON: {"executive_id": ..., "salary_offer": ...}
    success BOOLEAN,
    outcome_description TEXT,
    
    cost_paid REAL,
    value_gained REAL,
    relation_change REAL,
    
    executed_turn INTEGER,
    resolved_turn INTEGER,
    
    is_public BOOLEAN,        -- Is action visible to all?
    discovered_by_target BOOLEAN
);
```

**Usage Example:**

```python
from backend.core.management.diplomacy import DiplomacyManager

mgr = DiplomacyManager(db)

# Attempt to poach competitor's CTO
success, message, details = mgr.attempt_poach_executive(
    poaching_company_id=1,        # Your company
    target_executive_id=42,       # Competitor's star CTO
    salary_offer=500_000,         # $500k/year (double their current)
    game_id=1,
    current_turn=120
)

# Result (if successful):
# {
#     "success": True,
#     "message": "✓ Successfully poached John Smith (CTO) from Company 5!",
#     "executive_id": 42,
#     "executive_name": "John Smith",
#     "new_salary": 500000,
#     "relation_impact": -25
# }
```

#### 11.9.3 Dirty Trick #2: PR Attack / Smear Campaign

**Mechanic: Damage competitor's brand reputation**

Players can spend money on covert public relations attacks to damage a rival's brand perception.

**Effect Formula:**
```
Brand Damage = (Budget / $1,000,000) × 5.0

Example:
- $500k budget → 2.5 brand prestige damage
- $2M budget → 10 brand prestige damage
- $5M budget → 25 brand prestige damage
```

**Backfire Risk:**
```
Backfire Probability = 10% (fixed)

If backfire:
  Self Damage = Intended Damage × 0.5
  Attacker's brand prestige reduced instead
  Campaign exposed publicly → Scandal event
  Relation penalty: -5 (light, since it failed)
```

**Consequences:**

- **Success:**
  - Target company's `brand_prestige` reduced by damage amount
  - **Relation penalty: -15**
  - Cost: Budget amount
  - Event: "Brand Reputation Damaged" (HIDDEN source)
  - Discovery: Target may NOT know who attacked

- **Backfire:**
  - Attacker's `brand_prestige` reduced by 50% of intended damage
  - **Relation penalty: -5**
  - Cost: Budget amount (wasted)
  - Event: "PR Scandal Exposed" (PUBLIC, attacker identified)
  - Discovery: Everyone knows attacker's dirty tactics

**Database Fields:**

```sql
-- In diplomatic_actions table
action_details: {
    "budget": 2000000,
    "target_region_id": 3,   -- Optional: regional campaign
    "damage_dealt": 10.5,    -- Actual damage
    "backfired": false
}
```

**Usage Example:**

```python
# Launch $2M smear campaign against rival
success, message, details = mgr.launch_smear_campaign(
    attacker_company_id=1,
    target_company_id=5,
    budget=2_000_000,
    target_region_id=None,  # Global attack
    game_id=1,
    current_turn=120
)

# Result (if successful):
# {
#     "success": True,
#     "damage_dealt": 10.8,
#     "target_new_prestige": 54.2,  // Was 65.0
#     "cost": 2000000,
#     "relation_impact": -15
# }

# Result (if backfired):
# {
#     "success": False,
#     "backfired": True,
#     "self_damage": 5.4,
#     "budget_wasted": 2000000,
#     "relation_impact": -5
# }
```

#### 11.9.4 Patent System (Interface Only - v1.4)

**Status: Database schema implemented, logic deferred to future versions**

The patent system stores intellectual property rights but does not yet enforce them:

```sql
CREATE TABLE patents (
    id INTEGER PRIMARY KEY,
    owner_company_id INTEGER,
    tech_node_id INTEGER,          -- Linked technology
    
    patent_name VARCHAR(200),
    patent_description TEXT,
    protection_scope TEXT,         -- JSON: what is protected
    
    filed_turn INTEGER,
    granted_turn INTEGER,
    expiry_turn INTEGER,
    
    status VARCHAR(20),            -- PENDING/GRANTED/EXPIRED/INVALIDATED
    
    estimated_value REAL,
    total_licensing_revenue REAL
);
```

**Future Features (Not Yet Implemented):**

1. **Technology Protection:**
   - Companies owning a patent can charge licensing fees to others using the technology
   - Unlicensed use triggers patent lawsuit events

2. **Patent Lawsuits:**
   - Sue competitors for infringement
   - Court ruling determines damages ($1M - $500M)
   - Relation penalty: -30

3. **Patent Licensing:**
   - Passive income from other companies using your tech
   - Revenue: $100k - $5M per year depending on tech importance

**Current Implementation:**

- Patents can be created and stored
- `is_active(current_turn)` method checks if patent is in force
- No enforcement or revenue generation yet
- Intended for future expansion

#### 11.9.5 Relation Tracking & History

Every diplomatic action is logged:

```python
# Query all hostile actions taken by a company
actions = db.query(DiplomaticAction).filter(
    DiplomaticAction.actor_company_id == 1,
    DiplomaticAction.action_type.in_(["POACH_EXECUTIVE", "PR_ATTACK"])
).all()

# Calculate reputation
hostile_actions_count = len(actions)
if hostile_actions_count > 10:
    # Company gains "Ruthless" reputation
    # AI companies become more cautious
    # Players may face retaliation
```

**AI Retaliation Logic (Future):**

When AI companies detect hostile actions:

1. **Relation <= -50:** 50% chance to retaliate next turn
2. **Relation <= -70:** 80% chance to retaliate + escalate
3. **Relation <= -90:** Guaranteed retaliation + aggressive market behavior

**Implementation Status:**

- ✅ **CompetitorRelation model** (relation scores, embargo/alliance flags)
- ✅ **DiplomaticAction model** (action logging, outcomes)
- ✅ **Patent model** (interface only, no logic)
- ✅ **DiplomacyManager** (poaching, PR attack logic)
- ✅ **Event generation** (automatic news events for actions)
- ❌ **AI retaliation logic** (future)
- ❌ **Patent enforcement** (future)
- ❌ **Industrial espionage** (future)

**Key Files:**

- `backend/models/diplomacy.py`: Data models
- `backend/core/management/diplomacy.py`: Business logic
- `backend/api/routes/company.py`: API endpoints (to be added)

---

## Document History

| Version | Date | Author | Changes |
|---------|------|--------|---------|
| 1.0 | 2024-01-15 | Lead Architect | Initial design document |
| 1.1 | 2024-12-27 | System Architect | Added Chapter 11: Game Meta-Systems (Finance, Legal, Testing, Prestige, Events, Scenarios, Save/Load, Game Loop) |
| 1.2 | 2024-12-28 | System Architect | **COMPLETED**: Tech Tree System, Executive Management System, Natural Directive System, Platform Engineering |
| 1.3 | 2024-12-28 | System Architect | **BACKEND COMPLETE**: Game Loop Integration, Full API Layer, Event Logging System, Debug Tools |
| 1.4 | 2024-12-28 | System Architect | **FINAL FEATURES**: Procedural Vehicle Physics System, Diplomacy & Dirty Tricks (Poaching, PR Warfare) |

---

## Implementation Status (as of v1.3)

### ✅ 完成的后端系统

#### 核心架构
- ✅ **FastAPI应用** - 完整的REST API服务器
- ✅ **数据库模型** - 40+ SQLAlchemy模型，涵盖游戏所有方面
- ✅ **游戏循环管理器** - 8阶段回合处理系统
- ✅ **事件日志系统** - FM风格ticker事件记录

#### API路由 (v1.3)
- ✅ **游戏管理 API** (`/api/v1/game`)
  - 游戏状态查询
  - 回合推进（单回合/批量）
  - 事件日志查询
- ✅ **工程设计 API** (`/api/v1/engineering`)
  - 发动机设计与物理计算
  - 底盘/平台设计
  - 车辆组装与兼容性检查
- ✅ **公司管理 API** (`/api/v1/company`)
  - 公司信息查询
  - 财务管理
  - 员工招聘/解雇
  - 贷款申请/还款
- ✅ **调试/上帝模式 API** (`/api/v1/debug`)
  - 全局信息查看
  - 作弊功能
  - 事件手动触发

#### 管理与R&D层 (v1.2)
- ✅ 技术树系统
- ✅ 员工/高管管理系统
- ✅ 自然语言指令解析
- ✅ 平台工程增强

#### 工程层
- ✅ 基于物理的发动机设计
- ✅ 底盘/平台约束系统
- ✅ 车辆组装与兼容性检查
- ✅ 性能计算（0-100、极速、油耗等）

#### 生产层
- ✅ 工厂管理
- ✅ 材料采购与供应链
- ✅ B2B组件交易
- ✅ 生产调度

#### 市场与财务层
- ✅ 区域市场模拟
- ✅ 消费者分桶需求系统
- ✅ 经销网络
- ✅ 品牌认知追踪
- ✅ 贷款系统（含信用评级）
- ✅ 税务系统

#### 法律与测试层
- ✅ 监管合规系统
- ✅ 碰撞测试与原型阶段
- ✅ 召回事件管理

#### 游戏系统
- ✅ 声望与里程碑系统
- ✅ 游戏事件生成
- ✅ 多场景支持
- ✅ 存档/读档系统
- ✅ 回合处理管道

---

### 🚧 待完成项

**前端开发**
- 🔄 React UI - 技术树可视化
- 🔄 高管管理仪表板
- 🔄 自然语言指令输入界面
- 🔄 平台工程设计器
- 🔄 FM风格事件ticker

**AI系统**
- 🔄 AI CEO决策与新管理层整合
- 🔄 AI高管行为模拟
- 🔄 竞争对手技术发展策略

**集成与优化**
- 🔄 将指令连接到实际的生产/设计/市场系统
- 🔄 高管效能对公司运营的影响
- 🔄 技术解锁对可用零件/功能的影响
- 🔄 性能优化（批量查询、缓存）

---

**1. Technology Tree System (`backend/models/technology.py`, `backend/core/engineering/tech_tree.py`)**
- ✅ `TechNode` model: DAG-based tech tree with prerequisites, costs, difficulty ratings
- ✅ `CompanyTechnology` model: Per-company research progress tracking
- ✅ Research progression logic: investment-based progress with breakthrough probability
- ✅ Tech unlock effects: automatic application of stat modifiers to companies
- ✅ Dependency management: automatic unlocking of dependent techs
- ✅ Initial tech tree data: 15 starter technologies from basic manufacturing to hybrid powertrains (`backend/data/tech_tree_initial.json`)

**2. Executive/Staff Management System (`backend/models/staff.py`, `backend/core/management/hr.py`)**
- ✅ `Staff` model: Comprehensive executive/employee representation with skills, traits, morale, loyalty
- ✅ C-suite positions: CEO, CTO, CFO, CMO, COO with position-specific skill weighting
- ✅ Dynamic attributes: morale, loyalty, fatigue tracking with impact on effectiveness
- ✅ Compensation system: market value calculation, salary satisfaction, bonus percentage
- ✅ HR operations: hire, fire with severance calculations
- ✅ Turnover risk: probabilistic resignation based on morale/loyalty/salary
- ✅ Retirement system: age-based retirement probability
- ✅ Staff generation: randomized name, skills, traits, experience generation
- ✅ Effectiveness calculation: combined skill/morale/fatigue impact on work quality

**3. Natural Language Directive System (`backend/models/directive.py`, `backend/core/management/directive_parser.py`)**
- ✅ `Directive` model: Multi-type directive system (PHILOSOPHY/KPI/NATURAL_LANGUAGE/SPECIFIC)
- ✅ NLP parser: Keyword-based natural language understanding for design, production, marketing, R&D, HR, finance directives
- ✅ Directive execution tracking: progress, quality, estimated completion, feedback logs
- ✅ Staff assignment: directives can be assigned to specific executives
- ✅ Directive dependencies: support for prerequisite directives
- ✅ Budget approval: cost estimation and approval workflow
- ✅ Outcome metrics: post-execution success rating and metrics

**4. Platform Engineering Enhancement (`backend/models/engineering.py`)**
- ✅ Platform sharing fields: `is_platform`, `platform_family`, `derived_from_chassis_id`
- ✅ Flexible wheelbase: `min_wheelbase_mm` / `max_wheelbase_mm` for platform variants
- ✅ Body style support: JSON array of supported body styles per platform
- ✅ Economies of scale: `models_using_count` tracking with automatic cost factor calculation (0.6-1.0)
- ✅ Tooling cost management: `base_tooling_cost` and amortization tracking
- ✅ Platform generation: multi-generation platform evolution support
- ✅ Helper methods: `supports_body_style()`, `supports_wheelbase()`, `calculate_economies_of_scale()`, `get_effective_manufacturing_cost()`

#### Engineering Layer (Previously Completed)
- ✅ Physics-based engine design system
- ✅ Chassis/platform constraints
- ✅ CarTrim assembly with compatibility checking
- ✅ Performance calculation (0-100, top speed, fuel economy, etc.)

#### Production Layer (Previously Completed)
- ✅ Factory management
- ✅ Material procurement and supply chain
- ✅ B2B component trading
- ✅ Production scheduling

#### Market & Finance Layer (Previously Completed)
- ✅ Regional market simulation
- ✅ Consumer bucket demand system
- ✅ Distribution networks
- ✅ Brand perception tracking
- ✅ Loan system with credit ratings
- ✅ Tax system

#### Legal & Testing Layer (Previously Completed)
- ✅ Regulatory compliance system
- ✅ Crash testing and prototype phases
- ✅ Recall event management

#### Game Systems (Previously Completed)
- ✅ Prestige and milestone system
- ✅ Game event generation
- ✅ Multiple scenarios support
- ✅ Save/load system
- ✅ Turn processing pipeline

---

### 🚧 In Progress / Planned

**Frontend Development**
- 🔄 React UI for tech tree visualization
- 🔄 Executive management dashboard
- 🔄 Natural language directive input interface
- 🔄 Platform engineering designer

**AI Systems**
- 🔄 AI CEO decision-making integration with new management layer
- 🔄 AI executive behavior simulation
- 🔄 Competitor tech development strategies

**Integration**
- 🔄 Connect directives to actual production/design/marketing systems
- 🔄 Executive effectiveness impact on company operations
- 🔄 Tech unlock effects on available parts/features

---

*This document serves as the foundational blueprint for AutoMogul development. All implementation should reference this document, and any deviations should be documented and justified.*