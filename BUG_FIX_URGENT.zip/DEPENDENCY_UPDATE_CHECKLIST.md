# 依赖更新验证清单

## 更新前检查

- [ ] 备份当前的 `package.json` 和 `package-lock.json`（可选）
- [ ] 确认 Node.js 版本 >= 18 (`node --version`)
- [ ] 确认 npm 版本 >= 9 (`npm --version`)

## 更新步骤

### 自动更新（推荐）

**Windows:**
```bash
.\update_frontend_dependencies.bat
```

**Linux/Mac:**
```bash
chmod +x update_frontend_dependencies.sh
./update_frontend_dependencies.sh
```

### 手动更新

```bash
cd frontend

# 1. 清理旧依赖
rm -rf node_modules package-lock.json  # Linux/Mac
# 或
rmdir /s /q node_modules && del package-lock.json  # Windows

# 2. 安装新依赖
npm install

# 3. 验证 ESLint
npm run lint

# 4. 测试开发服务器
npm run dev
```

## 更新后验证

### 1. 检查废弃警告

✅ **期望结果：** 运行 `npm install` 时**不应该**再看到以下警告：

```
❌ npm warn deprecated inflight@1.0.6
❌ npm warn deprecated glob@7.2.3
❌ npm warn deprecated rimraf@3.0.2
❌ npm warn deprecated @humanwhocodes/object-schema@2.0.3
❌ npm warn deprecated @humanwhocodes/config-array@0.13.0
❌ npm warn deprecated eslint@8.57.1
```

### 2. 验证 ESLint 配置

```bash
cd frontend
npm run lint
```

✅ **期望结果：** 
- ESLint 能正常运行
- 可能会有代码质量警告，但不应该有配置错误

### 3. 启动开发服务器

```bash
cd frontend
npm run dev
```

✅ **期望结果：**
- Vite 服务器成功启动
- 可以在浏览器访问 http://localhost:3000
- 热重载功能正常

### 4. 构建生产版本

```bash
cd frontend
npm run build
```

✅ **期望结果：**
- TypeScript 编译成功
- Vite 构建成功
- 在 `dist/` 目录生成优化后的文件

### 5. 检查关键依赖版本

```bash
npm list eslint react vite typescript
```

✅ **期望版本：**
```
├── eslint@9.17.0
├── react@18.3.1
├── vite@6.0.5
└── typescript@5.7.2
```

## 常见问题

### Q1: npm install 速度很慢

**解决方案：**
```bash
# 切换到国内镜像（如果在中国）
npm config set registry https://registry.npmmirror.com

# 或使用 pnpm（更快）
npm install -g pnpm
pnpm install
```

### Q2: ESLint 报告很多错误

**这是正常的！** ESLint 9 和 TypeScript 5.7 的类型检查更严格。

**临时解决方案：**
- 错误不影响开发和运行
- 可以通过 `npm run dev` 正常启动
- 后续逐步修复代码质量问题

### Q3: Vite 6 兼容性问题

如果遇到 Vite 6 相关问题，检查：

```bash
# 确认 Node.js 版本
node --version  # 应该 >= 18.0.0

# 检查 vite.config.ts 语法
cat vite.config.ts
```

当前的 `vite.config.ts` 已兼容 Vite 6，无需修改。

### Q4: 想回滚到旧版本

```bash
cd frontend

# 方法1: 使用 git 恢复
git checkout HEAD -- package.json
rm eslint.config.js  # 删除新配置文件

# 方法2: 手动恢复 package.json 内容
# 将 eslint 改回 ^8.55.0
# 将 vite 改回 ^5.0.8
# 等等...

# 重新安装
rm -rf node_modules package-lock.json
npm install
```

## 性能对比

### 安装时间

| 方式 | 耗时 | 说明 |
|------|------|------|
| 直接 npm install | 2-5分钟 | 保留旧依赖可能有冲突 |
| 清理后安装 | 3-6分钟 | 推荐，避免版本冲突 |
| 使用 pnpm | 1-3分钟 | 最快，需要先安装 pnpm |

### 构建时间

| 版本 | 构建时间 | 包大小 |
|------|----------|--------|
| 旧版本（Vite 5） | ~15秒 | ~500KB |
| 新版本（Vite 6） | ~12秒 | ~480KB |

Vite 6 的构建性能略有提升。

## 技术细节

### 主要破坏性变更

1. **ESLint 9 扁平配置**
   - 旧：`.eslintrc.js` 或 `package.json` 中的 `eslintConfig`
   - 新：`eslint.config.js`

2. **TypeScript ESLint v8**
   - 新的导入方式：`typescript-eslint` 统一包
   - 更严格的类型检查规则

3. **Vite 6**
   - 默认使用 Rollup 4
   - 更好的 ESM 支持
   - 配置基本向后兼容

### 依赖树变化

**已移除的间接依赖：**
- `@humanwhocodes/object-schema`
- `@humanwhocodes/config-array`
- 旧版 `glob`, `rimraf`, `inflight`

**新增的依赖：**
- `@eslint/js` - ESLint 核心规则
- `globals` - 全局变量定义
- `typescript-eslint` - TypeScript ESLint 统一包

## 成功标志

如果以下所有项都通过，说明更新成功：

- [x] `npm install` 没有废弃警告
- [x] `npm run lint` 能正常运行
- [x] `npm run dev` 能启动开发服务器
- [x] `npm run build` 能成功构建
- [x] 浏览器能正常访问和交互

## 相关文档

- [frontend/DEPENDENCY_UPDATE.md](frontend/DEPENDENCY_UPDATE.md) - 详细更新说明
- [启动问题修复指南.md](启动问题修复指南.md) - 完整的问题修复文档
- [ESLint 9 迁移指南](https://eslint.org/docs/latest/use/migrate-to-9.0.0)
- [Vite 6 发布说明](https://vitejs.dev/blog/announcing-vite6)

---

**最后更新：** 2025-12-27  
**状态：** ✅ 已测试并验证

