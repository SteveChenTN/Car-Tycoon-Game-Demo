# 🏗️ AutoMogul 完整项目结构

```
Car-tycoon-game/
│
├── 📂 backend/                           # Python 后端 (FastAPI)
│   ├── 📂 api/                           # API 路由层
│   │   ├── 📂 routes/
│   │   │   ├── company.py                # 公司管理端点
│   │   │   ├── debug.py                  # 调试端点
│   │   │   ├── engineering.py            # 工程设计端点
│   │   │   ├── game.py                   # 游戏管理端点
│   │   │   ├── history.py                # 历史数据端点
│   │   │   └── websocket.py              # WebSocket 端点
│   │   └── 📂 schemas/                   # Pydantic 模式
│   │
│   ├── 📂 core/                          # 核心游戏逻辑
│   │   ├── 📂 ai/                        # AI 系统
│   │   │   ├── ai_procurement.py         # AI 采购策略
│   │   │   └── ai_strategy.py            # AI 战略决策
│   │   │
│   │   ├── 📂 economics/                 # 经济模型
│   │   │   ├── commodity_pricing.py      # 商品定价
│   │   │   ├── espionage.py              # 间谍系统
│   │   │   ├── market_math.py            # 市场数学
│   │   │   ├── market_simulation.py      # 市场模拟
│   │   │   └── used_market.py            # 二手车市场
│   │   │
│   │   ├── 📂 engineering/               # 工程物理
│   │   │   ├── chassis_math.py           # 底盘计算
│   │   │   ├── physics.py                # 物理公式
│   │   │   └── tech_tree.py              # 技术树
│   │   │
│   │   ├── 📂 management/                # 管理系统
│   │   │   ├── diplomacy.py              # 外交系统
│   │   │   ├── directive_parser.py       # 指令解析
│   │   │   ├── events.py                 # 事件系统
│   │   │   ├── finance.py                # 财务管理
│   │   │   ├── game_loop.py              # 游戏循环
│   │   │   ├── game_loop_async.py        # 异步游戏循环
│   │   │   ├── hr.py                     # 人力资源
│   │   │   └── testing.py                # 测试系统
│   │   │
│   │   ├── 📂 production/                # 生产系统
│   │   │   └── production_manager.py     # 生产管理器
│   │   │
│   │   └── loader.py                     # 数据加载器
│   │
│   ├── 📂 models/                        # 数据模型 (SQLAlchemy)
│   │   ├── b2b.py                        # B2B 市场模型
│   │   ├── base.py                       # 基础模型
│   │   ├── company.py                    # 公司模型
│   │   ├── diplomacy.py                  # 外交模型
│   │   ├── directive.py                  # 指令模型
│   │   ├── engineering.py                # 工程模型
│   │   ├── events.py                     # 事件模型
│   │   ├── finance.py                    # 财务模型
│   │   ├── game_manager.py               # 游戏管理器
│   │   ├── game_state.py                 # 游戏状态
│   │   ├── history.py                    # 历史记录
│   │   ├── inventory.py                  # 库存模型
│   │   ├── legal.py                      # 法规模型
│   │   ├── market.py                     # 市场模型
│   │   ├── production.py                 # 生产模型
│   │   ├── region.py                     # 地区模型
│   │   ├── staff.py                      # 员工模型
│   │   ├── supply.py                     # 供应模型
│   │   ├── technology.py                 # 技术模型
│   │   ├── testing.py                    # 测试模型
│   │   └── vehicle.py                    # 车辆模型
│   │
│   ├── 📂 services/                      # 业务逻辑层
│   │   └── engineering_service.py        # 工程服务
│   │
│   ├── 📂 utils/                         # 工具函数
│   │   ├── logger.py                     # 日志系统
│   │   └── save_system.py                # 存档系统
│   │
│   ├── 📂 scripts/                       # 脚本工具
│   │   ├── compare_v8_evolution.py       # V8 引擎对比
│   │   ├── demo_engineering.py           # 工程演示
│   │   ├── demo_production.py            # 生产演示
│   │   ├── init_world.py                 # 世界初始化 ⭐
│   │   ├── migrate_*.py                  # 数据迁移脚本
│   │   └── turn_simulation.py            # 回合模拟
│   │
│   ├── 📂 test_scripts/                  # 测试脚本
│   │   ├── test_patch_1_4.py
│   │   ├── test_production_flow.py
│   │   └── test_v1_4_features.py
│   │
│   ├── 📂 data/                          # 静态数据
│   │   ├── seed_regulations.json
│   │   └── tech_tree_initial.json
│   │
│   ├── config.py                         # 配置文件
│   ├── database.py                       # 数据库连接
│   ├── main.py                           # FastAPI 入口 ⭐
│   └── requirements.txt                  # Python 依赖
│
├── 📂 frontend/                          # React 前端 (Vite) ✨
│   ├── 📂 src/
│   │   ├── 📂 components/                # UI 组件
│   │   │   ├── 📂 layout/                # 布局组件
│   │   │   │   ├── AppShell.tsx          # 主容器 (18:9) ⭐
│   │   │   │   ├── Sidebar.tsx           # 侧边导航 ⭐
│   │   │   │   ├── StatusBar.tsx         # 顶部状态栏 ⭐
│   │   │   │   └── GlobalTicker.tsx      # 事件滚动条
│   │   │   └── 📂 ui/                    # 通用 UI 组件 (空)
│   │   │
│   │   ├── 📂 contexts/                  # React Context
│   │   │   └── GameContext.tsx           # WebSocket 上下文 ⭐
│   │   │
│   │   ├── 📂 pages/                     # 页面组件
│   │   │   └── Dashboard.tsx             # 仪表盘 ⭐
│   │   │
│   │   ├── 📂 types/                     # TypeScript 类型
│   │   │   └── index.ts                  # 类型定义 ⭐
│   │   │
│   │   ├── 📂 utils/                     # 工具函数
│   │   │   └── formatters.ts             # 格式化工具 ⭐
│   │   │
│   │   ├── 📂 lib/                       # 库函数
│   │   │   └── utils.ts                  # 通用工具 ⭐
│   │   │
│   │   ├── App.tsx                       # 根组件 ⭐
│   │   ├── main.tsx                      # React 入口 ⭐
│   │   ├── index.css                     # 全局样式 (Cyan-Tech) ⭐
│   │   └── vite-env.d.ts                 # Vite 类型
│   │
│   ├── index.html                        # HTML 入口
│   ├── package.json                      # Node 依赖 ⭐
│   ├── vite.config.ts                    # Vite 配置 ⭐
│   ├── tsconfig.json                     # TypeScript 配置 ⭐
│   ├── tailwind.config.js                # Tailwind 配置 ⭐
│   ├── postcss.config.js                 # PostCSS 配置
│   ├── .gitignore
│   └── README.md                         # 前端文档 ⭐
│
├── 📂 assets/                            # 游戏资源
│   └── 📂 data/                          # 数据驱动配置
│       ├── component_stats.json          # 组件统计
│       ├── events.json                   # 事件数据
│       ├── physics_constants.json        # 物理常量
│       ├── tech_tree.json                # 技术树
│       ├── MODDING_GUIDE.md              # MOD 指南
│       └── 📂 mods/                      # MOD 目录
│           └── mod_super_materials.json
│
├── 📂 data/                              # 运行时数据
│   └── automogul.db                      # SQLite 数据库 ⭐
│
├── 📂 logs/                              # 日志文件
│   └── automogul_YYYYMMDD.log
│
├── 📄 启动脚本                            # 快速启动
│   ├── start_server.bat                  # 后端启动 (Windows)
│   ├── start_server.sh                   # 后端启动 (Linux/Mac)
│   ├── start_frontend.bat                # 前端启动 (Windows) ⭐
│   ├── start_frontend.sh                 # 前端启动 (Linux/Mac) ⭐
│   ├── start_fullstack.bat               # 全栈启动 (Windows) ⭐
│   ├── start_fullstack.sh                # 全栈启动 (Linux/Mac) ⭐
│   └── start_server.py                   # Python 启动脚本
│
├── 📄 核心文档                            # 项目文档
│   ├── README.md                         # 项目总览 (已更新) ⭐
│   ├── design_doc.md                     # 完整设计文档
│   ├── QUICKSTART.md                     # 快速入门
│   ├── INITIALIZATION_SUMMARY.md         # 初始化总结
│   ├── QUICK_REFERENCE.md                # 快速参考 ⭐
│   │
│   ├── 📄 后端文档
│   │   ├── BACKEND_COMPLETE.md           # 后端完成文档
│   │   ├── BACKEND_PATCH_1.4_SUMMARY.md  # 补丁 1.4
│   │   ├── IMPLEMENTATION_GUIDE_1.4.md   # 实现指南
│   │   ├── PATCH_1_4_SUMMARY.md          # 补丁总结
│   │   ├── PRODUCTION_IMPLEMENTATION_SUMMARY.md # 生产系统
│   │   ├── DATA_DRIVEN_*.md              # 数据驱动文档
│   │   └── DATA_DRIVEN_ARCHITECTURE.txt
│   │
│   └── 📄 前端文档 ✨
│       ├── FRONTEND_INIT_COMPLETE.md     # 前端架构文档 ⭐
│       ├── FRONTEND_VISUAL_GUIDE.md      # 视觉设计指南 ⭐
│       └── FRONTEND_SETUP_COMPLETE.md    # 设置完成总结 ⭐
│
└── Car-tycoon-game.code-workspace        # VS Code 工作区

⭐ = 本次创建/更新的文件
✨ = 新功能模块
```

---

## 📊 统计信息

### 文件数量
- **后端**: 60+ Python 文件
- **前端**: 25+ TypeScript/TSX 文件
- **文档**: 20+ Markdown 文件
- **配置**: 15+ 配置文件

### 代码行数
- **后端**: ~6,500 行 Python
- **前端**: ~1,200 行 TypeScript/TSX
- **样式**: ~200 行 CSS/Tailwind
- **文档**: ~5,000 行 Markdown

### 依赖包
- **Python**: 15+ 包 (FastAPI, SQLAlchemy, NumPy, etc.)
- **Node.js**: 20+ 包 (React, Vite, TailwindCSS, etc.)

---

## 🎯 核心架构

### 后端 (FastAPI)
```
HTTP/REST API (端口 8000)
    ↓
API Routes (/api/v1/*)
    ↓
Services (业务逻辑)
    ↓
Core Logic (游戏引擎)
    ↓
Models (SQLAlchemy ORM)
    ↓
Database (SQLite)
```

### 前端 (React)
```
Browser (端口 3000)
    ↓
App.tsx (根组件)
    ↓
GameContext (WebSocket)
    ↓
AppShell (18:9 容器)
    ↓
Sidebar + StatusBar + Pages
    ↓
Components + Utils
```

### 通信流程
```
Frontend                    Backend
   │                           │
   ├─── WebSocket ─────────────►│  实时状态
   │    ws://localhost:8000/ws │
   │                           │
   ├─── REST API ──────────────►│  数据操作
   │    http://localhost:8000  │
   │                           │
   ◄──── JSON Response ────────┤
```

---

## 🔑 关键入口点

### 启动
- **全栈**: `start_fullstack.bat` / `.sh`
- **后端**: `backend/main.py`
- **前端**: `frontend/src/main.tsx`

### 配置
- **后端**: `backend/config.py`
- **前端**: `frontend/vite.config.ts`
- **样式**: `frontend/tailwind.config.js`

### 数据
- **数据库**: `data/automogul.db`
- **初始化**: `backend/scripts/init_world.py`

---

## 📦 模块依赖关系

```
GameContext (前端)
    ↓
WebSocket API (后端)
    ↓
Game Loop Manager
    ↓
┌─────────────┬─────────────┬─────────────┐
│  Economics  │ Engineering │  Production │
├─────────────┼─────────────┼─────────────┤
│   Market    │   Physics   │   Factory   │
│   Finance   │   Design    │   Supply    │
│   AI CEO    │   Tech Tree │   B2B       │
└─────────────┴─────────────┴─────────────┘
    ↓           ↓           ↓
    └───────────┴───────────┘
              ↓
         SQLAlchemy ORM
              ↓
         SQLite Database
```

---

## 🎨 设计系统层级

```
全局样式 (index.css)
    ↓
TailwindCSS 配置
    ↓
Cyan-Tech 设计系统
    ↓
┌─────────────┬─────────────┬─────────────┐
│   Colors    │   Layout    │  Typography │
├─────────────┼─────────────┼─────────────┤
│ cyan-400    │ 18:9 ratio  │  font-mono  │
│ slate-950   │ glass-panel │  text-sm    │
│ emerald-400 │ sidebar 80  │  h-10 rows  │
└─────────────┴─────────────┴─────────────┘
    ↓
组件样式类
    ↓
实际组件
```

---

**完整的全栈游戏开发环境已就绪！** 🚀

