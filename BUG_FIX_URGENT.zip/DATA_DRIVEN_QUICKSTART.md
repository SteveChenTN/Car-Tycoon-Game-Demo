# 数据驱动架构 - 快速开始

## 🚀 启动服务器

服务器会自动加载游戏数据。如果数据文件有问题，服务器会拒绝启动并显示错误信息。

### 方法 1: 使用启动脚本（推荐）

**Windows:**
```bash
start_server.bat
```

**Linux/Mac:**
```bash
./start_server.sh
```

### 方法 2: 直接运行

```bash
cd backend
python main.py
```

---

## ✅ 验证数据加载

运行测试脚本验证数据驱动架构是否正常工作：

```bash
cd backend
python test_data_driven.py
```

**预期输出**:
```
============================================================
测试总结
============================================================
通过: 7/7

✓ 所有测试通过！数据驱动架构工作正常。
```

---

## 📦 数据文件位置

所有游戏数据存储在外部JSON文件中：

```
assets/data/
├── component_stats.json      # 材料、燃料、组件
├── physics_constants.json    # 物理常数
├── tech_tree.json            # 技术树
├── events.json               # 事件模板
└── mods/                     # 模组目录
    └── mod_*.json            # 模组文件
```

---

## 🔧 修改游戏数据

1. 编辑对应的JSON文件
2. 重启服务器
3. 数据会在启动时重新加载

**注意**: 如果JSON格式错误，服务器会拒绝启动并显示详细错误。

---

## 🎮 创建模组

1. 在 `assets/data/mods/` 目录下创建 `mod_your_name.json`
2. 参考 `mod_super_materials.json` 示例
3. 重启服务器，模组会自动加载

详细指南：[assets/data/MODDING_GUIDE.md](assets/data/MODDING_GUIDE.md)

---

## 📖 完整文档

- **实施总结**: [DATA_DRIVEN_IMPLEMENTATION.md](DATA_DRIVEN_IMPLEMENTATION.md)
- **模组指南**: [assets/data/MODDING_GUIDE.md](assets/data/MODDING_GUIDE.md)
- **设计文档**: [design_doc.md](design_doc.md)

---

## ❓ 常见问题

### Q: 服务器启动时显示 "数据加载失败"

**A**: 检查以下内容：
1. `assets/data/` 目录是否存在
2. 所有JSON文件是否存在
3. JSON格式是否正确（使用JSON验证器）
4. 查看错误信息中的具体提示

### Q: 修改JSON后没有生效

**A**: 数据只在启动时加载一次，修改后需要重启服务器。

### Q: 模组没有加载

**A**: 确保：
1. 模组文件放在 `assets/data/mods/` 目录
2. 文件名以 `mod_` 开头
3. JSON格式正确
4. 重启服务器

---

## 🎉 数据驱动架构优势

- ✅ **易于调整**: 直接编辑JSON，无需编程
- ✅ **支持模组**: 玩家可以创建自定义内容
- ✅ **Fail Fast**: 数据错误时立即发现，不会运行时崩溃
- ✅ **社区友好**: JSON格式易于理解和分享

---

**Happy Gaming! 🚗💨**

