# 🔌 快速集成工程模块到现有应用

## 方式 1: 作为独立路由（推荐）

### 步骤 1: 修改 App.tsx

```tsx
import { useState } from 'react';
import { GameProvider } from './contexts/GameContext';
import { AppShell } from './components/layout/AppShell';
import { Dashboard } from './pages/Dashboard';
import { EngineeringHub } from './pages/engineering'; // 新增

function App() {
  const [currentView, setCurrentView] = useState<'dashboard' | 'engineering'>('dashboard');

  return (
    <GameProvider>
      <AppShell>
        {currentView === 'dashboard' && <Dashboard />}
        {currentView === 'engineering' && <EngineeringHub />}
        
        {/* 临时导航按钮（可以集成到Sidebar中） */}
        <div className="fixed bottom-4 left-4 flex gap-2 z-50">
          <button
            onClick={() => setCurrentView('dashboard')}
            className="bg-cyan-600 px-4 py-2 rounded font-mono text-sm"
          >
            Dashboard
          </button>
          <button
            onClick={() => setCurrentView('engineering')}
            className="bg-purple-600 px-4 py-2 rounded font-mono text-sm"
          >
            Engineering
          </button>
        </div>
      </AppShell>
    </GameProvider>
  );
}

export default App;
```

---

## 方式 2: 集成到 Sidebar 导航

### 步骤 1: 更新 Sidebar.tsx

在 `frontend/src/components/layout/Sidebar.tsx` 中添加：

```tsx
import { Wrench } from 'lucide-react';

// 在导航项数组中添加
const navItems = [
  { id: 'dashboard', label: 'Dashboard', icon: BarChart3 },
  { id: 'engineering', label: 'Engineering', icon: Wrench }, // 新增
  { id: 'factory', label: 'Factory', icon: Factory },
  // ...
];
```

### 步骤 2: 更新路由逻辑

在你的主组件中根据 `activeModule` 渲染：

```tsx
{activeModule === 'dashboard' && <Dashboard />}
{activeModule === 'engineering' && <EngineeringHub />}
{activeModule === 'factory' && <FactoryPage />}
```

---

## 方式 3: 作为 Dashboard 的卡片入口

### 在 Dashboard.tsx 中添加：

```tsx
import { Wrench, Car } from 'lucide-react';

// 在你的卡片网格中添加
<div className="grid grid-cols-3 gap-4">
  {/* 现有卡片 */}
  
  {/* 工程模块入口卡片 */}
  <div 
    onClick={() => navigateToEngineering()}
    className="bg-slate-900 border border-cyan-500/30 rounded p-6 cursor-pointer hover:border-cyan-500 transition-all"
  >
    <div className="flex items-center gap-3 mb-3">
      <Wrench className="w-8 h-8 text-cyan-400" />
      <h3 className="font-mono text-lg font-bold text-cyan-400">工程设计</h3>
    </div>
    <p className="text-slate-400 text-sm font-mono">
      设计引擎和车辆
    </p>
    <div className="mt-4 grid grid-cols-2 gap-2 text-xs font-mono">
      <div className="bg-slate-800 p-2 rounded">
        <span className="text-slate-500">已保存引擎:</span>
        <span className="text-cyan-400 ml-2 font-bold">{savedEnginesCount}</span>
      </div>
      <div className="bg-slate-800 p-2 rounded">
        <span className="text-slate-500">车辆设计:</span>
        <span className="text-purple-400 ml-2 font-bold">{vehicleCount}</span>
      </div>
    </div>
  </div>
</div>
```

---

## 完整示例: 最简单的测试集成

创建 `frontend/src/TestEngineering.tsx`:

```tsx
import React from 'react';
import { EngineeringHub } from './pages/engineering';

function TestEngineering() {
  return (
    <div className="w-screen h-screen bg-slate-950">
      <EngineeringHub />
    </div>
  );
}

export default TestEngineering;
```

然后在 `main.tsx` 中临时替换：

```tsx
import TestEngineering from './TestEngineering';

ReactDOM.createRoot(document.getElementById('root')!).render(
  <React.StrictMode>
    <TestEngineering />
  </React.StrictMode>,
);
```

---

## 🎯 测试清单

启动后应该看到：

- [x] 顶部有两个标签页（动力实验室 / 车辆工作室）
- [x] 动力实验室：左侧滑块、中央图表、右侧统计
- [x] 调整滑块时图表实时更新
- [x] 右侧有AI助手侧边栏
- [x] 车辆工作室：左侧引擎选择器、中央蓝图、右侧车身设置
- [x] 选择引擎后蓝图显示适配性

---

## 🔧 配置后端连接

如果后端运行在不同端口或地址，修改：

`frontend/src/services/engineeringService.ts`:

```typescript
const API_BASE = 'http://localhost:8000'; // 修改为你的后端地址
```

或使用环境变量：

```typescript
const API_BASE = import.meta.env.VITE_API_BASE_URL || 'http://localhost:8000';
```

在 `.env` 中配置：

```env
VITE_API_BASE_URL=http://your-backend:8000
```

---

## 🚨 常见问题

### Q: 看不到任何引擎？
A: 首先在动力实验室设计并保存一个引擎，然后切换到车辆工作室。

### Q: 图表不显示？
A: 检查浏览器控制台是否有 recharts 相关错误，确保依赖已安装。

### Q: AI助手没有消息？
A: 调整引擎参数到极端值（如可靠性<30），或在车辆工作室选择一个不适配的引擎。

### Q: 保存按钮没反应？
A: 当前是临时实现，会在控制台打印数据。检查浏览器控制台输出。

---

## 📦 最小化测试代码

如果只想测试单个组件：

```tsx
// TestDyno.tsx
import { DynoGraph } from './components/engineering/DynoGraph';

const testData = [
  { rpm: 1000, torque: 200, power: 40 },
  { rpm: 2000, torque: 250, power: 95 },
  { rpm: 3000, torque: 280, power: 160 },
  { rpm: 4000, torque: 290, power: 220 },
  { rpm: 5000, torque: 285, power: 270 },
  { rpm: 6000, torque: 270, power: 310 },
];

export default function TestDyno() {
  return (
    <div className="w-screen h-screen bg-slate-950 p-8">
      <DynoGraph data={testData} />
    </div>
  );
}
```

---

快速开始命令：

```bash
# 1. 确保在项目根目录
cd frontend

# 2. 安装依赖（如果还没安装）
npm install

# 3. 启动开发服务器
npm run dev

# 4. 打开浏览器访问
# http://localhost:5173
```

🎉 完成！你现在应该能看到完整的工程模块UI了。

