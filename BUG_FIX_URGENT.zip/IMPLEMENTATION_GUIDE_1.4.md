# Backend Patch 1.4 实施指南

## 快速开始

### 1. 立即验证新功能
```bash
cd backend
python test_scripts/test_patch_1_4.py
```

这将测试：
- ✅ Multinomial Logit 模型
- ✅ 二手车效用计算
- ✅ 供应商合约逻辑
- ✅ 数据库模型创建

### 2. 启动服务器（验证API）
```bash
python start_server.py
```

访问 http://localhost:8000/docs 查看新端点：
- `GET /api/v1/history/sales` - 销售历史
- `GET /api/v1/history/financial` - 财务历史
- `GET /api/v1/history/used-cars` - 二手车列表
- `GET /api/v1/history/sales/summary` - 销售汇总
- `GET /api/v1/history/financial/summary` - 财务汇总

---

## 已完成功能 ✅

### 核心系统
1. **二手车生态系统**
   - 统计桶库存模型
   - 月度折旧逻辑
   - 地区间转移（带政策检查）
   - 效用惩罚计算

2. **供应链合约**
   - 固定价格合约 vs 现货市场
   - 月度自动执行
   - 违约处理（罚金+信用评分）
   - 价格对比分析

3. **高级市场数学**
   - Multinomial Logit 离散选择模型
   - NumPy加速支持
   - 价格弹性计算
   - 批量市场份额计算

4. **历史快照系统**
   - 销售历史记录（按回合/地区/车型）
   - 财务历史快照（损益表+资产负债表）
   - 高效索引查询

5. **游戏循环扩展**
   - 阶段5.5: 合约执行
   - 阶段7: 二手车市场更新
   - 阶段9: 历史快照记录

### API层
- 完整的RESTful端点
- Pydantic验证
- 分页和筛选支持
- 汇总统计端点

### 3D就绪
- Engine/Chassis/CarTrim 添加 `visual_specs` (JSON)
- 为未来前端3D渲染预留数据结构

---

## 待集成功能 🔄

### 优先级 1：市场模拟集成（关键）
**文件：** `backend/core/economics/market_simulation.py`

**步骤：**
```python
# 1. 导入新模块
from backend.core.economics.market_math import MultinomialLogitModel, UsedCarUtilityCalculator
from backend.core.economics.used_market import UsedCarMarket
from backend.models.history import SalesHistory

# 2. 在市场解算方法中：
def simulate_weekly_sales(self, game_id: int):
    logit = MultinomialLogitModel(price_sensitivity=-0.8)
    used_market = UsedCarMarket(self.db)
    
    # 3. 收集所有选项（新车+二手车）
    new_cars = [...]  # 从数据库获取
    used_cars = used_market.get_used_car_listings(game_id, region_id)
    
    # 4. 计算效用和概率
    all_options = new_cars + used_cars
    utilities = [logit.calculate_utility(...) for opt in all_options]
    probs = logit.calculate_choice_probabilities(utilities)
    
    # 5. 模拟选择
    choices = logit.simulate_choices(utilities, n_consumers=demand)
    
    # 6. 执行销售并创建历史记录
    for choice_idx, count in Counter(choices).items():
        if choice_idx < len(new_cars):
            # 新车销售
            vehicle = new_cars[choice_idx]
            # ... 扣减库存 ...
            
            # 创建销售历史
            sales_record = SalesHistory(
                game_id=game_id,
                turn_number=current_turn,
                region_id=region_id,
                trim_id=vehicle.id,
                company_id=vehicle.company_id,
                units_sold=count,
                revenue_total=count * vehicle.msrp,
                # ...
            )
            self.db.add(sales_record)
            
            # 加入二手车池
            used_market.add_newly_sold_cars_to_pool(
                game_id, region_id, vehicle.id, count, vehicle.msrp
            )
        else:
            # 二手车销售
            # ... 处理二手车逻辑 ...
```

### 优先级 2：Company模型扩展
**文件：** `backend/models/company.py`

**添加字段：**
```python
class Company(Base):
    # ... 现有字段 ...
    
    # 月度累计指标（每回合重置）
    monthly_revenue = Column(Float, nullable=False, default=0.0)
    monthly_cost_manufacturing = Column(Float, nullable=False, default=0.0)
    monthly_cost_materials = Column(Float, nullable=False, default=0.0)
    monthly_cost_labor = Column(Float, nullable=False, default=0.0)
    monthly_cost_rd = Column(Float, nullable=False, default=0.0)
    monthly_cost_marketing = Column(Float, nullable=False, default=0.0)
    monthly_cost_admin = Column(Float, nullable=False, default=0.0)
    monthly_interest = Column(Float, nullable=False, default=0.0)
    monthly_profit = Column(Float, nullable=False, default=0.0)
    monthly_units_sold = Column(Integer, nullable=False, default=0)
    monthly_units_produced = Column(Integer, nullable=False, default=0)
    
    def reset_monthly_stats(self):
        """每回合开始时调用"""
        self.monthly_revenue = 0.0
        self.monthly_cost_manufacturing = 0.0
        # ... 重置所有monthly_*字段 ...
```

**在game_loop中调用：**
```python
def _phase_world_update(self, game_id, current_turn):
    # ... 现有逻辑 ...
    
    # 重置所有公司的月度统计
    companies = self.db.query(Company).filter(Company.game_id == game_id).all()
    for company in companies:
        company.reset_monthly_stats()
```

### 优先级 3：Region模型扩展
**文件：** `backend/models/region.py`

**添加字段：**
```python
class Region(Base):
    # ... 现有字段 ...
    
    # 二手车交易政策
    allow_used_export = Column(
        Boolean, nullable=False, default=True,
        comment="允许二手车出口"
    )
    allow_used_import = Column(
        Boolean, nullable=False, default=True,
        comment="允许二手车进口"
    )
```

### 优先级 4：生产库存集成
**文件：** `backend/core/production/production_manager.py`

**添加方法：**
```python
class ProductionManager:
    def add_materials_to_inventory(
        self,
        factory_id: int,
        material_type: str,
        quantity: int
    ):
        """从合约交付添加材料到工厂库存"""
        factory = self.db.query(Factory).filter(Factory.id == factory_id).first()
        inventory = self.db.query(Inventory).filter(
            Inventory.factory_id == factory_id
        ).first()
        
        if not inventory:
            # 创建新库存记录
            inventory = Inventory(factory_id=factory_id, raw_materials={})
            self.db.add(inventory)
        
        # 更新原材料库存（JSON字段）
        materials = json.loads(inventory.raw_materials) if inventory.raw_materials else {}
        materials[material_type] = materials.get(material_type, 0) + quantity
        inventory.raw_materials = json.dumps(materials)
        
        self.db.commit()
```

**在game_loop中调用：**
```python
def _phase_contract_execution(self, game_id, current_turn):
    # ... 合约执行逻辑 ...
    
    if delivery_result.get("success"):
        # 扣除款项
        company.cash_balance -= payment_amount
        
        # **新增：添加材料到库存**
        # 找到公司的主要工厂（简化版，实际应由玩家指定）
        factory = self.db.query(Factory).filter(
            Factory.company_id == company.id
        ).first()
        
        if factory:
            self.production_mgr.add_materials_to_inventory(
                factory_id=factory.id,
                material_type=contract.material_type,
                quantity=contract.monthly_quantity
            )
```

---

## 数据库迁移

### 自动迁移（推荐）
如果使用Alembic：
```bash
cd backend
alembic revision --autogenerate -m "Patch 1.4: History, Supply, UsedCars"
alembic upgrade head
```

### 手动迁移（SQLite）
如果直接使用SQLite：
```python
# 运行一次
from backend.database import init_db
init_db()  # 自动创建所有表
```

### 验证表创建
```bash
sqlite3 data/automogul.db

.tables
# 应看到新表：
# sales_history
# financial_history
# used_car_inventory
# supplier_contracts
# material_markets (supply版本)
```

---

## 测试计划

### 单元测试
```bash
# 运行验证脚本
python backend/test_scripts/test_patch_1_4.py

# 预期输出：
# ✓ Logit模型测试通过
# ✓ 二手车效用计算测试通过
# ✓ 合约逻辑测试通过
# ✓ 数据库模型测试通过
```

### 集成测试（手动）
1. **启动服务器**
   ```bash
   python start_server.py
   ```

2. **测试历史API**
   ```bash
   # 销售历史
   curl "http://localhost:8000/api/v1/history/sales?game_id=1&company_id=1&limit=10"
   
   # 财务历史
   curl "http://localhost:8000/api/v1/history/financial?game_id=1&company_id=1&limit=10"
   
   # 二手车列表
   curl "http://localhost:8000/api/v1/history/used-cars?game_id=1&region_id=1"
   ```

3. **测试游戏循环**
   ```bash
   # 使用debug API推进回合
   curl -X POST "http://localhost:8000/api/v1/game/1/advance-turn"
   
   # 检查日志查看新阶段执行
   tail -f logs/automogul_*.log
   ```

---

## 性能基准

### 目标指标
- **Logit计算：** < 50ms / 1000消费者 / 10选项（NumPy加速）
- **历史查询：** < 100ms / 1000条记录（带索引）
- **合约执行：** < 10ms / 合约（批量处理）
- **二手车老化：** < 200ms / 10000条记录

### 基准测试
```python
import time
from backend.core.economics.market_math import MultinomialLogitModel

logit = MultinomialLogitModel(use_numpy=True)

# 测试1000消费者选择10个选项
utilities = [0.5, 0.6, 0.7, 0.55, 0.65, 0.58, 0.62, 0.59, 0.61, 0.57]

start = time.time()
for _ in range(100):
    choices = logit.simulate_choices(utilities, n_consumers=1000)
elapsed = time.time() - start

print(f"1000消费者×10选项×100次: {elapsed:.3f}秒 ({elapsed*10:.1f}ms/次)")
```

---

## 故障排除

### 问题1：导入错误
**症状：** `ModuleNotFoundError: No module named 'backend.models.history'`

**解决：**
```bash
# 确保在项目根目录
cd /path/to/Car-tycoon-game

# 重启Python环境
```

### 问题2：数据库表不存在
**症状：** `sqlite3.OperationalError: no such table: sales_history`

**解决：**
```python
from backend.database import init_db
init_db()  # 强制重建所有表
```

### 问题3：NumPy未安装
**症状：** `ModuleNotFoundError: No module named 'numpy'`

**解决（可选）：**
```bash
pip install numpy

# 或者在代码中禁用NumPy加速：
logit = MultinomialLogitModel(use_numpy=False)
```

### 问题4：合约执行失败
**症状：** 公司现金变负数

**检查：**
1. 合约金额是否合理
2. `_phase_financial` 是否在 `_phase_contract_execution` 之前执行
3. 公司现金余额是否足够

---

## 下一步开发

### 立即行动（本周）
1. ✅ 运行验证测试
2. ✅ 启动服务器验证API
3. 🔄 完成优先级1-4的集成
4. 📝 编写单元测试
5. 📊 运行性能基准测试

### 短期目标（2周内）
1. 前端销售图表组件
2. 前端财务曲线图组件
3. 二手车市场UI
4. 合约管理界面

### 中期目标（1月内）
1. AI策略整合（自动签订合约）
2. 材料价格波动模拟
3. 地区政策事件（禁止二手车进口）
4. 高级合约类型（浮动价格、期权等）

---

## 文档与资源

- **设计文档：** `design_doc.md`
- **补丁总结：** `BACKEND_PATCH_1.4_SUMMARY.md`
- **API文档：** http://localhost:8000/docs （启动服务器后）
- **测试脚本：** `backend/test_scripts/test_patch_1_4.py`

---

## 贡献者注意

### 代码风格
- 严格类型提示（Python 3.10+）
- 完整文档字符串（Google风格）
- SQLAlchemy ORM（避免原生SQL）
- 错误处理+日志记录

### 提交规范
```
feat(history): 添加销售历史记录功能
fix(supply): 修复合约违约罚金计算
perf(logit): 使用NumPy加速概率计算
docs(patch): 更新1.4补丁文档
```

---

## 联系与支持

如有问题，请查阅：
1. `design_doc.md` - 原始设计
2. `BACKEND_PATCH_1.4_SUMMARY.md` - 实施摘要
3. API文档 - `/docs` 端点
4. 代码注释 - 每个函数都有详细文档

---

**祝开发顺利！** 🚗💨

