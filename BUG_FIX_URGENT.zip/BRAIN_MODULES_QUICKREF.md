# 大脑模块快速参考

## 🎯 三大模块概览

| 模块 | 图标 | 功能 | 文件路径 |
|------|------|------|----------|
| **研发中心** | 🔬 | 技术树、解锁新技术 | `pages/research/TechTree.tsx` |
| **高管套房** | 👔 | 董事会管理、外交关系 | `pages/executive/ExecutiveRoom.tsx` |
| **财务报表** | 📊 | P&L报表、图表分析 | `pages/reports/FinancialReports.tsx` |

---

## 🔬 研发中心 (TechTree)

### 核心功能
```typescript
// 节点状态
locked      // 🔒 灰色 - 前置未满足
available   // ⚡ 琥珀色 - 可点击研发
researching // 🔄 青色 - 研发中（带进度条）
completed   // ✅ 青色 - 已完成
```

### 快捷键操作
- **点击节点** → 显示详情
- **点击"开始研发"** → 扣款 + 启动计时

### 数据源
- `assets/data/tech_tree.json` (15个技术节点)
- 自动计算依赖关系

---

## 👔 高管套房 (ExecutiveRoom)

### 董事会标签页

| 角色 | 默认成员 | 核心技能 |
|------|----------|----------|
| **CEO** | 玩家 (You) | 全能型 |
| **CTO** | Dr. Hans Mueller | 工程 92 |
| **CFO** | Ms. Sarah Chen | 财务 95 |
| **COO** | Mr. Takeshi Yamada | 运营 88 |

**操作**:
- 🔥 **解雇**: 支付离职费 (1-2个月薪水)
- ➕ **招聘**: 即将推出

### 外交关系标签页

**关系状态**:
```
hostile   // 💀 敌对 (-100 to -50)
rival     // 🥊 竞争 (-50 to 0)
neutral   // 😐 中立 (0 to 30)
friendly  // 😊 友好 (30 to 60)
allied    // 🤝 同盟 (60 to 100)
```

**外交行动**:
- 💀 **侮辱** → 降低关系 (免费)
- 🤝 **结盟** → 提升关系 ($50,000)
- 👁️ **间谍** → 窃取机密 ($100,000)

---

## 📊 财务报表 (FinancialReports)

### 财务概览标签页

**4大指标卡片**:
```
💰 现金余额       🟦 青色
📈 本月收入       🟩 绿色
📉 本月支出       🟥 红色
💵 净利润        🟩/🟥 动态
```

**图表**:
- **左侧**: 现金流趋势 (Area Chart) - 12回合历史
- **右侧**: 全球市场份额 (Pie Chart) - 玩家 vs 竞争对手

### 损益表标签页

**标准P&L结构**:
```
营业收入
 - 销售成本 (COGS)
 = 毛利润 ✅

 - 研发费用
 - 市场营销
 - 管理费用
 = 营业利润 ✅

 - 利息支出
 - 所得税
 = 净利润 ✅✅
```

### 销售分析标签页

- **柱状图**: 收入 vs 净利润
- **Top 5**: 畅销车型排行榜

---

## 🎨 设计风格指南

### 配色方案
```css
Primary:   #06b6d4 (Cyan)    /* 强调色 */
Success:   #10b981 (Emerald) /* 正向指标 */
Warning:   #f59e0b (Amber)   /* 注意/可用 */
Danger:    #ef4444 (Rose)    /* 负向/危险 */
Neutral:   #64748b (Slate)   /* 中性文字 */
```

### 组件规范
```typescript
// 卡片
bg-slate-900 border border-slate-800 rounded-lg p-6

// 按钮 (主要)
bg-cyan-900/20 hover:bg-cyan-900/40 text-cyan-400

// 按钮 (危险)
bg-rose-900/20 hover:bg-rose-900/40 text-rose-400

// 进度条
h-2 bg-slate-800 rounded-full overflow-hidden
  └─ bg-emerald-500 (70%+)
  └─ bg-amber-500 (40-70%)
  └─ bg-rose-500 (<40%)

// 字体
font-mono text-sm (默认)
font-bold (强调)
```

---

## 🔌 后端集成清单

### 研发模块 API
```
GET  /api/v1/research/progress?company_id={id}
POST /api/v1/research/start
```

### 高管模块 API
```
GET  /api/v1/staff/list?company_id={id}
POST /api/v1/staff/fire
POST /api/v1/staff/hire
GET  /api/v1/diplomacy/relations?company_id={id}
POST /api/v1/diplomacy/action
```

### 财务模块 API
```
GET /api/v1/reports/financial?company_id={id}
GET /api/v1/reports/market_share?company_id={id}
GET /api/v1/reports/pl_statement?company_id={id}&year={year}
```

**当前状态**: 所有前端已完成，使用 Mock 数据降级。

---

## 🧪 快速测试命令

```bash
# 启动前端
cd frontend && npm run dev

# 访问路径
http://localhost:5173

# 导航到模块
点击顶部导航栏: Research / Executive / Reports
```

---

## 📌 常见问题

**Q: 为什么技术树没有连接线？**  
A: 当前使用简化网格布局。SVG 连接线可在下阶段添加。

**Q: 如何添加新技术节点？**  
A: 编辑 `assets/data/tech_tree.json`，添加新节点并设置 `unlock_requirements`。

**Q: 如何更改默认高管？**  
A: 修改 `services/executiveService.ts` 中的 `getMockStaff()` 函数。

**Q: 图表显示空白？**  
A: 检查 Recharts 是否正确安装：`npm list recharts`

---

**最后更新**: 2025-12-27  
**版本**: v1.0  
**作者**: AI Assistant

