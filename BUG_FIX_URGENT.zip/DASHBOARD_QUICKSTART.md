# Dashboard 快速启动指南

## 🎯 概述

这次更新实现了游戏的主仪表板界面，包括 5 个核心组件和完整的游戏控制层。所有组件都使用 **Mock 数据**，即使没有后端数据也能正常显示。

---

## ✅ 已完成的功能

### 1. **GlobalTicker（全局事件滚动条）**
- 固定在屏幕底部
- 自动滚动显示最新事件
- 根据事件严重程度显示不同颜色
- 平滑动画效果

### 2. **NextTurnButton（长按推进按钮）**
- 圆形设计，1 秒长按触发
- 进度环动画
- 完成时白色闪光效果
- 自动调用 `/api/game/next_turn` API

### 3. **NetworkTopology（网络拓扑图）**
- SVG 动态可视化
- 节点脉冲动画
- 连接线发光效果
- Blueprint 风格网格背景

### 4. **FinancialTerminal（财务终端）**
- 三个关键 KPI（现金、利润、市场份额）
- 现金流趋势图（Recharts）
- 自动格式化货币

### 5. **CompetitorRadar（竞争对手雷达）**
- 5 维度对比（技术、品牌、资金、质量、市场）
- 玩家 vs AI 可视化
- 优势/劣势统计

### 6. **Dashboard 页面**
- Bento Box 网格布局
- 整合所有组件
- 响应式设计

---

## 🚀 如何运行

### 前提条件
- Node.js 已安装
- 后端服务运行在 `localhost:8000`（可选，有 Mock 数据）

### 启动步骤

1. **进入前端目录**
   ```bash
   cd frontend
   ```

2. **安装依赖（如果还没安装）**
   ```bash
   npm install
   ```

3. **启动开发服务器**
   ```bash
   npm run dev
   ```

4. **打开浏览器**
   ```
   http://localhost:5173
   ```

---

## 📂 文件结构

```
frontend/src/
├── components/
│   ├── layout/
│   │   ├── GlobalTicker.tsx       ← 全局事件滚动条
│   │   ├── AppShell.tsx           ← 更新：集成 Ticker
│   │   └── index.ts
│   └── ui/
│       ├── NextTurnButton.tsx     ← 长按推进按钮
│       ├── NetworkTopology.tsx    ← 网络拓扑可视化
│       ├── FinancialTerminal.tsx  ← 财务终端
│       ├── CompetitorRadar.tsx    ← 竞争对手雷达
│       └── index.ts
├── pages/
│   ├── Dashboard.tsx              ← 主仪表板（完全重写）
│   └── ComponentPreview.tsx       ← 组件预览页面（测试用）
├── contexts/
│   └── GameContext.tsx            ← 更新：支持事件历史
├── types/
│   └── index.ts                   ← 更新：新增类型定义
├── utils/
│   └── formatters.ts              ← 新增：货币格式化工具
└── index.css                      ← 更新：新增动画
```

---

## 🎨 视觉风格

### Cyber-Industrial 美学
- **颜色：** Dark slate 背景 + Cyan 主色调
- **字体：** Monospace 用于数字
- **边框：** 细线条（1px）
- **动画：** 脉冲、发光、平滑过渡
- **网格：** Blueprint 风格

### 颜色代码
```css
Primary:   #06b6d4  (Cyan)
Success:   #10b981  (Emerald)
Warning:   #fbbf24  (Amber)
Error:     #f43f5e  (Rose)
Background: #020617 (Slate 950)
```

---

## 🧪 测试组件

### 方法 1：查看完整 Dashboard
访问主页，所有组件已集成在 Dashboard 页面中。

### 方法 2：使用预览页面
如果你想单独查看每个组件，可以创建一个路由到 `ComponentPreview` 页面：

在 `src/App.tsx` 中添加：
```tsx
import { ComponentPreview } from './pages/ComponentPreview';

// 然后在路由中添加
<Route path="/preview" element={<ComponentPreview />} />
```

访问 `http://localhost:5173/preview` 查看所有组件的独立展示。

---

## 🔌 后端集成

### WebSocket 连接

组件自动连接到：
```
ws://localhost:8000/ws/game
```

### 预期的 WebSocket 消息格式

**1. 游戏状态更新**
```json
{
  "type": "game_state",
  "payload": {
    "current_year": 2020,
    "current_month": 6,
    "current_week": 2,
    "turn_number": 24
  }
}
```

**2. 事件推送**
```json
{
  "type": "event",
  "payload": {
    "id": 123,
    "turn_number": 24,
    "event_type": "news",
    "title": "New factory opened",
    "description": "Your new factory in Europe is now operational",
    "severity": "info",
    "created_at": "2024-12-28T00:00:00Z"
  }
}
```

### API 端点

**推进回合**
```http
POST /api/game/next_turn
```

后端应该：
1. 处理回合逻辑
2. 通过 WebSocket 广播新的 `game_state`
3. 发送相关的 `event` 消息

---

## 🐛 故障排除

### 问题 1：组件不显示数据
**解决方案：** 所有组件都有 Mock 数据，应该能正常显示。检查浏览器控制台是否有错误。

### 问题 2：WebSocket 连接失败
**解决方案：** 
- 确保后端运行在 `localhost:8000`
- 检查后端是否实现了 WebSocket 端点 `/ws/game`
- 组件会自动重连，等待 3 秒后重试

### 问题 3：NextTurnButton 无响应
**解决方案：**
- 检查是否连接到后端（按钮在离线时会禁用）
- 确保后端实现了 `POST /api/game/next_turn` 端点
- 查看浏览器控制台的网络请求

### 问题 4：GlobalTicker 不滚动
**解决方案：**
- 确保有事件数据（Mock 数据应该自动显示）
- 检查 CSS 动画是否加载正确
- 确认 `animate-scroll` 类在 `index.css` 中定义

---

## 📊 Mock 数据说明

如果后端不可用，所有组件会自动使用 Mock 数据：

| 组件 | Mock 数据内容 |
|------|--------------|
| NetworkTopology | 6 个区域节点（NA, EU, AS, SA, AF, OC）+ 随机连接 |
| FinancialTerminal | 12 个月的财务历史数据 |
| CompetitorRadar | 随机的 5 维度对比数据 |
| Dashboard Stats | 随机的快速统计数字 |

---

## 🎯 下一步开发建议

### 短期（立即可做）
1. ✅ 测试所有组件的视觉效果
2. ✅ 验证 Mock 数据显示正常
3. ⬜ 测试长按按钮交互
4. ⬜ 确认 GlobalTicker 滚动动画

### 中期（需要后端配合）
1. ⬜ 实现 `/api/game/next_turn` 端点
2. ⬜ 设置 WebSocket 消息广播
3. ⬜ 从数据库获取真实的财务数据
4. ⬜ 获取竞争对手数据

### 长期（功能增强）
1. ⬜ 点击网络节点显示详情弹窗
2. ⬜ 图表可交互（缩放、筛选）
3. ⬜ 事件历史面板（展开查看所有事件）
4. ⬜ 自定义 Dashboard 布局（拖拽调整）

---

## 💡 使用提示

### 1. 长按按钮的正确使用
- **按住鼠标左键** 1 秒钟
- 看到进度环填满
- 等待白色闪光
- 按钮自动重置

### 2. 查看事件历史
- 底部 GlobalTicker 显示最新 20 条
- 使用 `useGameContext().eventHistory` 获取完整历史（最多 50 条）

### 3. 自定义组件数据
所有组件都支持传入自定义数据：
```tsx
<NetworkTopology nodes={customNodes} links={customLinks} />
<FinancialTerminal history={realData} currentCash={balance} />
<CompetitorRadar playerCompany={player} rivalCompany={rival} />
```

---

## 📝 代码质量

- ✅ **TypeScript：** 完整类型定义
- ✅ **Linter：** 无错误
- ✅ **性能：** useMemo 优化
- ✅ **动画：** Framer Motion 高性能
- ✅ **可维护性：** 模块化设计

---

## 📞 联系信息

如果你遇到问题或需要更多功能：
1. 查看 `DASHBOARD_COMPONENTS.md` 详细文档
2. 检查浏览器控制台错误
3. 查看 `ComponentPreview.tsx` 示例代码

---

## 🎉 开始体验

```bash
cd frontend
npm run dev
```

然后访问 **http://localhost:5173** 查看你的新 Dashboard！

所有组件都已就绪，即使没有后端也能看到完整的视觉效果！ 🚀

