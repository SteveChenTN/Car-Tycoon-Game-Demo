# 紧急 Bug 修复指南

## 🚨 当前问题

### 1. API 路径不匹配 - ✅ 已修复
- **问题**: 前端调用 `/api/game/new`，后端是 `/api/v1/game/new`
- **解决**: 已统一前端 API 基础路径为 `http://localhost:8000/api/v1`

### 2. WebSocket 403 错误 - ✅ 部分修复
- **问题**: WebSocket 需要 game_id 参数，前端没有提供
- **解决**: 添加了 `/ws/game` 端点（不需要 game_id）

### 3. 数据库模型错误 - ⚠️ 临时规避
- **问题**: `CompanySupplierRelation` 模型配置错误
- **临时方案**: WebSocket 端点暂时使用硬编码 `game_id = 1`

---

## 🔧 快速修复步骤

### 步骤 1: 重启后端
由于修改了后端代码，需要重启：

```bash
# 停止当前后端 (Ctrl+C)
# 重新启动
python start_server.py
```

### 步骤 2: 刷新前端
在浏览器中刷新页面 (F5 或 Ctrl+R)

### 步骤 3: 测试主菜单
1. 应该能看到中文主菜单（"汽车大亨"）
2. 不应该再有 HTTP 404 错误
3. WebSocket 应该连接成功（不再有 403）

---

## 📋 剩余问题需要修复

### 数据库模型问题（中优先级）

**错误信息**:
```
Mapper 'Mapper[Company(companies)]' has no property 'supplier_relations'
```

**原因**: `CompanySupplierRelation` 模型试图在 `Company` 模型上创建关系，但 `Company` 模型没有定义该属性。

**修复方案**:
1. 找到 `backend/models/supply.py` 或相关文件
2. 检查 `CompanySupplierRelation` 模型的关系定义
3. 在 `Company` 模型中添加对应的 `relationship`

**临时规避**: 目前 WebSocket 不查询数据库，使用硬编码 `game_id = 1`

---

## ✅ 验证清单

重启后端并刷新前端后，检查：

- [ ] 主菜单正常显示（中文："汽车大亨"）
- [ ] 浏览器控制台无 404 错误
- [ ] 浏览器控制台显示 "WebSocket connected"
- [ ] 后端日志无 403 错误
- [ ] 点击 "新游戏" 按钮有响应

---

## 🐛 如果还有问题

### 问题：点击"新游戏"后 404
**检查**:
```bash
# 后端日志应该显示：
POST /api/v1/game/new
```

如果显示的是 `/api/game/new`，说明前端代码未更新，需要：
1. 确认 `frontend/src/services/gameApi.ts` 已修改
2. 重新编译前端 (`npm run dev`)

### 问题：WebSocket 仍然 403
**检查**:
```bash
# 后端日志应该显示：
WebSocket /ws/game [accepted]
```

如果仍然 403，可能是路由注册问题。检查 `backend/main.py` 是否包含：
```python
from backend.api.routes import websocket
app.include_router(websocket.router)
```

### 问题：数据库相关错误
这是已知问题，暂时不影响主菜单和基本功能。等主要功能测试通过后再修复。

---

## 📝 后续修复计划

### 立即修复（P0）
- [x] API 路径统一
- [x] WebSocket 基本连接
- [ ] 测试"新游戏"功能

### 短期修复（P1）
- [ ] 修复数据库模型关系
- [ ] WebSocket 查询真实游戏状态
- [ ] 完善错误处理

### 长期优化（P2）
- [ ] WebSocket 重连机制
- [ ] 更好的错误提示
- [ ] 日志优化

---

## 🎯 当前目标

**首要目标**: 让主菜单能够正常显示并能创建新游戏

**测试步骤**:
1. 启动后端
2. 启动前端
3. 看到主菜单
4. 点击"新游戏"
5. 确认创建成功并进入游戏界面

**如果上述步骤都成功，说明核心功能已工作！**

