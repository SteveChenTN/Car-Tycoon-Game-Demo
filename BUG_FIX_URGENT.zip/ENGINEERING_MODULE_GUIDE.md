# 🔧 工程模块 UI 完整实现文档

## 📋 概述

这是一个完整的工程设计模块，包含两个独立的工作室：

1. **动力实验室 (Powertrain Lab)** - 设计和测试引擎
2. **车辆工作室 (Vehicle Studio)** - 组装底盘+引擎，验证适配性

所有界面都配有**AI总工程师助手**，实时监控设计并提供专业建议。

---

## 🎨 设计哲学

### 视觉风格
- **主题色**: 工业青色 (Cyan) + 紫色 (Purple) 双色调
- **布局**: 三栏式专业工具布局
- **字体**: 所有数值使用等宽字体 (`font-mono`)
- **动画**: 适配失败时的红色闪烁边框

### 交互设计
- **实时计算**: 所有滑块调整立即更新图表和统计数据
- **智能提示**: AI助手在关键时刻主动提供建议
- **视觉反馈**: 引擎不适配时整个引擎舱会闪烁红色

---

## 📁 文件结构

```
frontend/src/
├── contexts/
│   └── EngineeringContext.tsx          # 工程模块状态管理
├── components/
│   └── engineering/
│       ├── DynoGraph.tsx                # 动力曲线图表组件
│       ├── BlueprintSVG.tsx             # 底盘蓝图SVG组件
│       ├── ChiefEngineer.tsx            # AI助手侧边栏
│       └── index.ts
├── pages/
│   └── engineering/
│       ├── EngineDesigner.tsx           # 动力实验室页面
│       ├── VehicleDesigner.tsx          # 车辆工作室页面
│       ├── EngineeringHub.tsx           # 工程模块主入口
│       └── index.ts
├── services/
│   └── engineeringService.ts            # 后端API服务层
└── utils/
    └── engineeringCalc.ts               # 前端轻量级工程计算
```

---

## 🚀 快速开始

### 1. 集成到现有应用

在 `App.tsx` 或路由配置中添加：

```tsx
import { EngineeringHub } from './pages/engineering';

// 在你的路由或条件渲染中
<EngineeringHub />
```

### 2. 启动应用

```bash
# 确保后端服务运行
cd backend
python main.py

# 启动前端
cd frontend
npm run dev
```

---

## 🎮 用户流程

### 流程 A: 设计引擎

1. 打开 **动力实验室** 标签页
2. 调整滑块参数：
   - 缸径 (Bore)
   - 行程 (Stroke)
   - 缸数 (Cylinders)
   - 压缩比 (Compression Ratio)
   - 增压压力 (Boost Pressure)
   - 材料 (Material)
3. 实时观察：
   - 中央的动力曲线图表
   - 右侧的性能统计
   - AI助手的建议
4. 点击 **💾 保存引擎** 按钮

### 流程 B: 设计车辆

1. 打开 **车辆工作室** 标签页
2. 从左侧引擎库选择一个已保存的引擎
3. 调整底盘参数（特别是引擎舱尺寸）
4. 观察蓝图上的适配性检查：
   - ✅ 绿色 = 适配成功
   - ❌ 红色闪烁 = 不适配
5. 如果不适配，AI助手会告诉你如何修复
6. 调整车身参数（重量、风阻、座位数等）
7. 点击 **💾 保存车辆** 按钮

---

## 🧩 核心组件详解

### 1. EngineeringContext

**职责**: 管理整个工程模块的状态

**关键状态**:
```typescript
- engineDraft: 当前正在设计的引擎
- savedEngines: 已保存的引擎列表
- chassisDraft: 当前正在设计的底盘
- vehicleDraft: 当前正在设计的车辆
- fitmentStatus: 引擎-底盘适配性检查结果
- selectedEngine: 在车辆工作室选中的引擎
- aiMessages: AI助手的消息列表
```

### 2. DynoGraph (动力曲线图表)

**技术栈**: Recharts

**显示内容**:
- 扭矩曲线 (橙色线)
- 功率曲线 (紫色线)
- 双Y轴显示
- 悬停时显示详细数据

**特点**:
- 响应式布局
- 暗色工业风配色
- 等宽字体数值显示

### 3. BlueprintSVG (底盘蓝图)

**技术**: 原生SVG + 动态计算

**显示内容**:
- 车轮位置
- 轴距标注
- 引擎舱可视化矩形
- 适配性状态颜色编码

**关键特性**:
- 引擎不适配时闪烁红色边框
- 实时计算尺寸比例
- 网格背景（工程图纸风格）

### 4. ChiefEngineer (AI助手)

**UI形式**: 固定右侧边栏（可折叠）

**触发条件**:
- 可靠性 < 30 → 警告
- 高增压 + 高压缩比 → 爆震警告
- 引擎不适配 → 解决方案建议
- 引擎适配成功 → 确认消息

**消息类型**:
- ❌ 错误 (红色)
- ⚠️ 警告 (黄色)
- ✅ 成功 (绿色)
- ℹ️ 信息 (灰色)

---

## 🔌 API 集成

### 保存引擎

```typescript
import { createEngine } from '../services/engineeringService';

const response = await createEngine({
  company_id: 1,
  name: 'V8 Powerhouse',
  code: 'V8_001',
  bore_mm: 90,
  stroke_mm: 90,
  cylinder_count: 8,
  configuration: 'V',
  // ... 其他参数
});
```

### 加载引擎列表

```typescript
import { listEngines } from '../services/engineeringService';

const engines = await listEngines(companyId, true);
setSavedEngines(engines);
```

### 检查适配性

```typescript
import { checkCompatibility } from '../services/engineeringService';

const result = await checkCompatibility(engineId, chassisId);
// result.compatible: boolean
// result.message: string
// result.details: object
```

---

## 🎯 关键功能实现

### 实时动力曲线生成

引擎参数改变 → 前端计算 → 生成曲线点数组 → Recharts渲染

计算函数在 `utils/engineeringCalc.ts`:
```typescript
- calculateDisplacement()
- estimateHorsepower()
- estimateTorque()
- generatePowerCurve()
```

### 适配性检查逻辑

```typescript
function checkEngineFitment(
  engineLength, engineWidth, engineHeight,
  bayLength, bayWidth, bayHeight
) {
  // 检查每个维度
  const lengthFits = engineLength <= bayLength;
  const widthFits = engineWidth <= bayWidth;
  const heightFits = engineHeight <= bayHeight;
  
  // 计算体积
  const engineVolume = (L × W × H) / 1,000,000,000;
  const bayVolume = (BL × BW × BH) / 1,000,000,000;
  
  return {
    fits: lengthFits && widthFits && heightFits,
    message: ...,
    engineVolume,
    engineBayVolume
  };
}
```

### AI响应式提示系统

在 `EngineDesigner.tsx` 和 `VehicleDesigner.tsx` 的 `useEffect` 中：

```typescript
useEffect(() => {
  // 计算性能参数
  const reliability = estimateReliability(...);
  
  // 触发AI提示
  if (reliability < 30) {
    addAIMessage('⚠️ 可靠性太低！');
  }
}, [engineDraft]);
```

---

## 🎨 样式定制

### 主题色变量

**动力实验室**: Cyan系
- 主色: `cyan-500` (#06b6d4)
- 边框: `cyan-500/30`
- 文字: `cyan-400`

**车辆工作室**: Purple系
- 主色: `purple-500` (#a855f7)
- 边框: `purple-500/30`
- 文字: `purple-400`

### 自定义动画

已添加到 `index.css`:
```css
@keyframes fadeIn {
  from { opacity: 0; transform: translateY(-10px); }
  to { opacity: 1; transform: translateY(0); }
}

.animate-fadeIn {
  animation: fadeIn 0.3s ease-out;
}
```

---

## 📊 性能优化建议

1. **动力曲线生成**: 已使用节流（每500 RPM一个点）
2. **AI消息**: 使用 `useRef` 自动滚动到底部
3. **图表渲染**: Recharts自带优化，支持大数据集
4. **状态管理**: Context仅在子模块内部，不污染全局

---

## 🐛 已知限制 & 待完成

### 当前限制

1. **引擎列表API返回数据不完整**: 需要从详情API补充（见 `EngineeringHub.tsx` 的TODO注释）
2. **公司ID硬编码**: 需要从 `GameContext` 获取当前玩家公司
3. **3D模型占位符**: 当前只显示图标和文字

### 后续增强

- [ ] 添加引擎导出/导入功能
- [ ] 支持历史版本对比
- [ ] 添加更详细的成本分析图表
- [ ] 3D引擎模型集成（Three.js）
- [ ] 保存车辆时的性能模拟（0-100km/h）

---

## 🧪 测试场景

### 场景1: 设计一台V8性能引擎
1. 缸径: 100mm, 行程: 90mm
2. 配置: V型, 缸数: 8
3. 压缩比: 11.5
4. 增压: TURBO, 1.5 bar
5. 材料: ALUMINUM
6. 观察: 功率应该 > 400 HP

### 场景2: 引擎不适配测试
1. 设计一个V12引擎（长度 > 900mm）
2. 在车辆工作室选择该引擎
3. 保持引擎舱长度 < 800mm
4. 预期: 红色闪烁 + AI警告

### 场景3: AI助手响应测试
1. 增压压力设置为 2.5 bar
2. 压缩比设置为 12.0
3. 预期: AI提示爆震风险

---

## 📞 技术支持

如遇问题，请检查：

1. **后端是否运行**: `http://localhost:8000/docs`
2. **浏览器控制台**: 查看错误信息
3. **API响应格式**: 确保后端返回的字段名与前端匹配
4. **依赖安装**: 确保 `recharts` 已安装

---

## 🎉 特色亮点

✅ **真实物理公式**: 基于后端的硬核模拟
✅ **实时预览**: 无需保存即可看到性能变化
✅ **智能提示**: AI助手主动提供设计建议
✅ **视觉反馈**: 适配失败时的红色闪烁警告
✅ **工业设计**: 暗色主题 + 青色/紫色双色调
✅ **响应式布局**: 三栏布局自适应屏幕

---

**版本**: 1.0.0  
**创建日期**: 2025-12-27  
**作者**: AutoMogul 工程团队

