# AutoMogul 快速入门指南

## 项目已完成初始化 ✅

### 当前进度

1. ✅ **项目结构搭建完成**
   - 后端模块化文件夹结构
   - 配置文件和常量定义
   - 日志系统

2. ✅ **数据库系统**
   - SQLAlchemy ORM配置
   - GameState模型（时间系统）
   - Region模型（地区数据）
   - 数据库文件：`data/automogul.db`

3. ✅ **世界初始化**
   - 5个地区已创建：
     - NAM (北美) - 高收入，偏好大车
     - EUR (欧洲) - 中收入，偏好小车和燃效
     - ASI (亚太) - 低收入高增长，偏好经济型小车
     - LAM (拉美) - 中低收入，平衡偏好
     - MEA (中东非) - 新兴市场
   - 总人口：20亿
   - 总GDP：9.725万亿
   - 可触及市场：2110万辆/年

4. ✅ **FastAPI后端服务**
   - 健康检查: `/health`
   - 游戏状态: `/api/v1/game/state`
   - 地区数据: `/api/v1/game/regions`
   - 世界概况: `/api/v1/game/world-summary`
   - 推进回合: `/api/v1/game/advance`

---

## 如何运行

### 方式1：使用启动脚本（推荐）

**Windows:**
```cmd
start_server.bat
```

**Linux/Mac:**
```bash
chmod +x start_server.sh
./start_server.sh
```

### 方式2：直接运行Python

```bash
python start_server.py
```

### 方式3：使用uvicorn

```bash
cd backend
python -m uvicorn main:app --reload --port 8000
```

---

## 访问API

### API文档（Swagger UI）
打开浏览器访问：http://localhost:8000/docs

### 示例API调用

**1. 健康检查**
```bash
curl http://localhost:8000/health
```

**2. 获取游戏状态**
```bash
curl http://localhost:8000/api/v1/game/state
```

**3. 获取所有地区**
```bash
curl http://localhost:8000/api/v1/game/regions
```

**4. 获取特定地区**
```bash
curl http://localhost:8000/api/v1/game/regions/NAM
```

**5. 获取世界概况**
```bash
curl http://localhost:8000/api/v1/game/world-summary
```

**6. 推进游戏回合**
```bash
curl -X POST http://localhost:8000/api/v1/game/advance
```

---

## 项目结构

```
Car-tycoon-game/
├── backend/                    # Python后端
│   ├── models/                 # ORM数据模型
│   │   ├── game_state.py       # ✅ 游戏状态和时间
│   │   ├── region.py           # ✅ 地区数据
│   │   └── base.py             # 基类和Mixin
│   │
│   ├── core/                   # 核心游戏逻辑（待实现）
│   │   ├── simulation/         # 模拟引擎
│   │   ├── economics/          # 经济模型
│   │   ├── engineering/        # 工程设计
│   │   └── ai/                 # AI系统
│   │
│   ├── api/                    # API层
│   │   ├── routes/             # 路由（待扩展）
│   │   └── schemas/            # Pydantic模型
│   │
│   ├── services/               # 业务逻辑服务
│   ├── utils/                  # 工具函数
│   │   └── logger.py           # ✅ 日志系统
│   │
│   ├── scripts/                # 脚本
│   │   └── init_world.py       # ✅ 世界初始化
│   │
│   ├── config.py               # ✅ 配置和常量
│   ├── database.py             # ✅ 数据库连接
│   ├── main.py                 # ✅ FastAPI入口
│   └── requirements.txt        # ✅ 依赖列表
│
├── data/                       # 数据文件
│   └── automogul.db            # ✅ SQLite数据库
│
├── logs/                       # 日志文件
│   └── automogul_YYYYMMDD.log  # 按日期的日志
│
├── design_doc.md               # 设计文档
├── README.md                   # 项目说明
└── start_server.*              # 启动脚本

✅ = 已完成
```

---

## 核心功能说明

### 1. 时间系统 (Weekly-based)

游戏使用**周**作为基本时间单位：
- 每月 = 4周
- 每年 = 12月 = 48周
- 起始时间：1950年1月第1周

**时间推进：**
```python
# 通过API推进回合
POST /api/v1/game/advance
```

### 2. 地区系统

每个地区包含完整的经济和市场特征：

**经济指标：**
- 人口
- 人均GDP
- GDP增长率
- 购买力指数
- 通货膨胀率
- 失业率

**市场特征：**
- 汽车保有量
- 平均车龄
- 年度市场容量

**基础设施：**
- 基础设施质量
- 道路质量
- 燃油价格
- 电价

**政策法规：**
- 进口关税
- 排放标准
- 安全标准
- 企业税率
- 电动车补贴

**文化偏好：**
- 车型尺寸偏好（小/中/大）
- 车身类型偏好（轿车/SUV/掀背等）
- 燃效vs动力权重

---

## 日志系统

所有关键操作都有详细日志记录：

**查看日志：**
```bash
# 最新日志
cat logs/automogul_$(date +%Y%m%d).log

# Windows
type logs\automogul_<YYYYMMDD>.log
```

**日志级别：**
- DEBUG：详细调试信息
- INFO：常规信息（默认）
- WARNING：警告
- ERROR：错误
- CRITICAL：严重错误

**配置日志级别：**
修改 `backend/config.py` 中的 `LOG_LEVEL`

---

## 下一步开发

根据 `design_doc.md`，接下来需要实现：

### 短期目标：
1. **消费者系统** - Consumer Buckets（消费者分群）
2. **公司系统** - Company和Executive模型
3. **车辆设计** - Vehicle和Trim模型
4. **回合引擎** - Turn Processing Pipeline

### 中期目标：
1. **市场模拟** - 需求计算和销售解析
2. **AI系统** - AI公司决策
3. **经济循环** - GDP增长、经济周期
4. **事件系统** - 随机事件生成

### 长期目标：
1. **前端UI** - React + TailwindCSS
2. **Electron打包** - 桌面应用
3. **3D可视化** - 车辆展示
4. **完整游戏循环** - 多年模拟

---

## 开发规范

### 1. 遵循设计文档
- 所有功能实现前先查阅 `design_doc.md`
- 保持代码与文档一致

### 2. 模块化原则
- 每个功能独立模块
- 避免大文件（>500行）
- 清晰的职责分离

### 3. 类型提示
```python
def calculate_demand(region: Region, year: int) -> float:
    pass
```

### 4. 日志记录
```python
from backend.utils.logger import get_logger

logger = get_logger(__name__)
logger.info("Market calculation started")
```

### 5. 性能优化
- 使用NumPy进行批量计算
- 避免嵌套循环
- 记录执行时间

---

## 故障排除

### 问题：模块导入错误
```
ModuleNotFoundError: No module named 'xxx'
```

**解决：**
```bash
python -m pip install -r backend/requirements.txt
```

### 问题：数据库不存在
```
no such table: game_state
```

**解决：**
```bash
python backend/scripts/init_world.py
```

### 问题：端口被占用
```
Error: [Errno 10048] Address already in use
```

**解决：**
```bash
# 查找占用端口的进程
netstat -ano | findstr :8000

# 终止进程（Windows）
taskkill /PID <PID> /F

# 或使用不同端口
uvicorn backend.main:app --port 8001
```

---

## 技术栈

- **后端：** Python 3.13, FastAPI, SQLAlchemy
- **数据库：** SQLite
- **数据处理：** NumPy, Pandas
- **日志：** Python logging + colorlog
- **API文档：** Swagger UI (自动生成)
- **前端（待实现）：** React, Vite, TailwindCSS
- **桌面（待实现）：** Electron

---

## 许可证

查看项目根目录的 LICENSE 文件

---

## 联系方式

如有问题，请查阅 `design_doc.md` 或创建 Issue。

**祝开发顺利！🚗**

